<?php
include('header.php');



if(isset($_REQUEST['wid'])){
	$stores = mysql_escape_string($_REQUEST['wid']);

	$sql = "SELECT * FROM inv_outlets WHERE id = '$stores'";
	$result = mysql_query($sql) or die(mysql_error());
	$info = mysql_fetch_array($result);
		$sid=$info['id'];
		$outlet_name=$info['outlet_name'];
}

?>


        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="header">
							   New Record 
							   <h3>	
							   <?php print $outlet_name; ?>
							   </h3>
							  							   
							   <a href="outlets.php?pg=6">
										<button class="btn btn-info btn-fill btn-wd">Go Back</button>
							   </a>
										
								
							   <a href="outlet_quotation_sales_create.php?wid=<?php print $sid; ?>&pg=6&t=1">
							   <button type="submit" class="btn btn-danger btn-fill btn-wd">New Sales</button>
							   </a>
							   
							   <a href="outlet_quotation_sales.php?wid=<?php print $sid; ?>&pg=6&t=1">
							   <button type="submit" class="btn btn-success btn-fill btn-wd">Sales Reciepts</button>
							   </a>
							   
							   <a href="print_outlet_product_new.php?wid=<?php print $sid; ?>&pg=6&t=1&month=<?php print $_REQUEST['month']; ?>&year=<?php print $_REQUEST['year']; ?>">
							   <button type="submit" class="btn btn-info btn-fill btn-wd">Print</button>
							   </a>
							   
							    <a href="excel_outlet_product_new.php?wid=<?php print $sid; ?>&offset=<?php print $offset; ?>&t=1&month=<?php print $_REQUEST['month']; ?>&year=<?php print $_REQUEST['year']; ?>">
							   <button type="submit" class="btn btn-success btn-fill btn-wd">Download</button>
							   </a>
							
							   
							   <p>
							   
						<form method="POST" action="outlet_product_new.php">

							   <div class="col-md-1">
							   <label>Year:</label>
							   </div>	
							   
							   <div class="col-md-2">
							    <select name="year" class="form-control border-input">
									<?php 
									$curr_year = date('Y');
									for($y=2018;$y<=$curr_year;$y++){
										if((isset($_REQUEST['year']))&&($_REQUEST['year']==$y)){
											print "<option selected=\"selected\">$y</option>";
										}else{
											print "<option>$y</option>";
										}
									}
									?>
									
								</select>
							   </div>
							   
							   <div class="col-md-1">
							   <label>Month:</label>
							   </div>
							   
							   <div class="col-md-2">							  
							    <select name="month" class="form-control border-input">
									<?php 
									
									for($m=1;$m<=12;$m++){
										//print "<option>$m</option>";
										include("month_convert.php");
										//return $month_word
										
										if((isset($_REQUEST['month']))&&($_REQUEST['month']==$month_word)){
											print("<option selected=\"selected\">".$month_word."</option>");
										}else{
											print("<option>".$month_word."</option>");
										}
									}
									?>
								</select>
							   </div>
							   
							   <div class="col-md-2">
									<button type="submit" class="btn btn-danger btn-fill btn-wd">Load Record</button>
							   </div>

							   <input type="hidden" name="wid" value="<?php print $_REQUEST['wid']; ?>">
							   <input type="hidden" name="pg" value="<?php print $_REQUEST['pg']; ?>">
							   
							 </form>
							   
							  
							   </p>
							   
                            </div>
							
						
                            <div class="content table-responsive table-full-width">
							
								
							
                                <table class="table table-striped">
                                    <thead>
										<th>#</th>
										<th>Id</th>
										<th>Date</th>
										<th>Product</th>
										<th>Price</th>
										
										<th>B/F</th>
										<th>Supply</th>
										
										<th>Sales</th>
										<th>Out of Stock</th>
										
										<th>Balance</th>
										<th>Physical Stock</th>
										<th>Variance</th>
										
                                    </thead>
									
									
                                    <tbody>
									
									
<?php

$sel_month = $_REQUEST['month'];
$sel_year = $_REQUEST['year'];

$sql = "SELECT * FROM inv_product ORDER BY product_name ASC";
//$sql = "SELECT * FROM inv_product WHERE product_name = 'TT CTN 2 IN 1 SOOTHER'";

$result = mysql_query($sql) or die(mysql_error());

$counter = 1;

while($info = mysql_fetch_array($result)){ 
	$id=$info['id'];
	$product_name=$info['product_name'];
	$product_type=$info['product_type'];
	$sale_price=$info['sale_price'];
	$ean13_barcode=$info['ean13_barcode'];
	$int_ref=$info['int_ref'];
	$description=$info['description'];
	$date_created=$info['date_created'];
	
	
	
	// Get the pulled data from the NEW Table [inv_outlet_product] (New Record Only)
		$sql2 = "SELECT * FROM inv_outlet_product WHERE product='$id' AND store_id='$sid'";
		$result2 = mysql_query($sql2) or die(mysql_error());
		if (mysql_num_rows($result2) > 0) {
			
		  $data = mysql_fetch_array($result2);
			$o_id=$data['id'];
			$day=$data['day'];
			$month=$data['month'];
			$year=$data['year'];
			$product=$data['product'];
			//$bf=$data['bf'];
			
			$supply=$data['supply'];
			$sales=$data['sales'];
			$out_of_stock=$data['out_of_stock'];
			$balance=$data['balance'];
			$physical_stock=$data['physical_stock'];
		}		
			
			
			//Getting the BF/From the last month physical stock entry
			//Physical Stock
			
			//$query9  = "SELECT quantity FROM inv_outlet_extra_entry_adjustment WHERE entry_type='2' AND outlet_id='$sid' AND product_id='$id'";	


		$arr_month_concern = array('Jan', 'Feb', 'Mar', 'Apr','May');
		if((in_array($sel_month, $arr_month_concern, true))&&($sel_year=='2019')){
			$query9  = "SELECT quantity FROM inv_outlet_extra_entry_adjustment WHERE entry_type='2' AND outlet_id='$sid' AND product_id='$id' AND date_year='' ORDER BY id DESC";
		}else{
			
			include('month_return_last.php');
			$query9  = "SELECT quantity FROM inv_outlet_extra_entry_adjustment WHERE entry_type='2' AND outlet_id='$sid' AND product_id='$id' AND (date_month='$last_month' AND date_year='$sel_year') ORDER BY id DESC";
		}
		
		

		
			$result9 = mysql_query($query9) or die(mysql_error());
				
				//while($info9 = mysql_fetch_array($result9)){
				$info9 = mysql_fetch_array($result9);			
					$retrieved_ps=$info9['quantity'];
					
					if($retrieved_ps > 0){
						$bf = $retrieved_ps;
					}else{
						$bf = 0;
					}
			
			$quantity_supply = '0';
			// --------------------------------- Getting data for Supply -------------------------
			
			$query2  = "SELECT * FROM inv_transfer_create WHERE product='$id' AND destination_location='$sid'";		
				$result2 = mysql_query($query2) or die(mysql_error());
				
				
				while($info2 = mysql_fetch_array($result2)){
					    
					
						$quantity_supply=$info2['quantity'];
						$transfer_id=$info2['transfer_id'];
						
						$date=$info2['date'];
						
						
						
						//$date = "04/30/1973";
						list($date_day, $date_month, $date_year) = split('[-.-]', $date);
						
						
						if((strtolower($date_month)==strtolower($sel_month))&&($date_year==$sel_year)){
							$total_supply_for_product = $total_supply_for_product+$quantity_supply;
							
							//$total_supply_for_product = $quantity_supply;
						}else{
							$total_supply_for_product = 0;
							
						}
						
			
			    }
			//--------------------------------- Getting data for Sales ---------------------------- SUM(quantity) AS total_stock_in
					$sql3 = "SELECT SUM(quantity) AS total_sales_total FROM  inv_order_line_outlet WHERE product_id='$id' AND outlet_id='$sid' AND month='$sel_month' AND year='$sel_year'";
					$result3 = mysql_query($sql3) or die(mysql_error());
						
							  $data3 = mysql_fetch_array($result3);
								$sales=$data3['total_sales_total'];
								if($sales == ""){
									$sale_value = 0;
								}else{
									$sale_value = '<b>'.$sales.'</b>';
								}
	

			$selected_month = $_REQUEST['month'];
			$selected_year =$_REQUEST['year'];
			
			//Physical Stock
			$query6  = "SELECT quantity FROM inv_outlet_extra_entry_adjustment WHERE entry_type='2' AND outlet_id='$sid' AND product_id='$id' AND date_month = '$selected_month' AND date_year = '$selected_year' ORDER BY id DESC";
			$result6 = mysql_query($query6) or die(mysql_error());
			$info6 = mysql_fetch_array($result6);
			$quantity_physical_stock=$info6['quantity'];
			if(isset($quantity_physical_stock)){
				$ps = "<a href=\"outlet_extra_entries.php?wid=$stores&pg=6&type=2&prod=$id&cat=new&month=$selected_month&year=$selected_year\">$quantity_physical_stock</a>";
			}else{
				$ps = "<a href=\"outlet_extra_entries.php?wid=$stores&pg=6&type=2&prod=$id&cat=new&month=$selected_month&year=$selected_year\">0</a>";
			}
			
			
			
			//Out of Stock
			$query5  = "SELECT quantity FROM inv_outlet_extra_entry_adjustment WHERE entry_type='1' AND outlet_id='$sid' AND product_id='$id' AND date_month = '$selected_month' AND date_year = '$selected_year' ORDER BY id DESC";
			$result5 = mysql_query($query5) or die(mysql_error());
			$info5 = mysql_fetch_array($result5);
			$quantity_out_of_stock=$info5['quantity'];
			if($quantity_out_of_stock != ""){
				$oos = "<a href=\"outlet_extra_entries.php?wid=$stores&pg=6&type=1&prod=$id&cat=new&month=$selected_month&year=$selected_year\">$quantity_out_of_stock</a>";
			}else{
				$oos = "<a href=\"outlet_extra_entries.php?wid=$stores&pg=6&type=1&prod=$id&cat=new&month=$selected_month&year=$selected_year\">0</a>";
			}
			
			
			//-------------------- Balance & Varient -------------------------------------
				//Balance
				$stock_balance = (($bf + $total_supply_for_product) - ($sales + $quantity_out_of_stock));
				
				//Varient = [Balance]-[Physical Stock]	
				$variant = ($stock_balance-$quantity_physical_stock);
	
	
				
				if(($bf != 0)|| ($total_supply_for_product != 0)||($sale_value != 0)){
			
			
			
							print "
								<tr>
											<td>$counter</td>
											<td>$id</td>
											<td>$month/$year</td>
                                        	<td>$product_name</td>
											<td>$sale_price</td>
                                        	
											";
											
											
											
											print "
											<td><font color='blue'>$bf</font></td>
											<td><font color='blue'>$total_supply_for_product</font></td>	
													
											<td><font color='red'>$sale_value</font></td>
											<td>$oos</td>
											
											<td><font color='green'><b>$stock_balance</b></font></td>
											<td>$ps</td>
											<td><b>$variant</b></td>
											
								</tr>
								";
						$counter++;
				}
				
				
	
		//  } //end of if --------------- with a BIG problem
	
	
	
}

print '
      
                                    </tbody>
                                </table>
';

?>										
                                        
                                  

                            </div>
                        </div>
                    </div>



                </div>
            </div>
        </div>

        <?php include('footer.php') ?>


    </div>
</div>


</body>

    <!--   Core JS Files   -->
    <script src="assets/js/jquery.min.js" type="text/javascript"></script>
	<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>

	<!--  Checkbox, Radio & Switch Plugins -->
	<script src="assets/js/bootstrap-checkbox-radio.js"></script>

	<!--  Charts Plugin -->
	<script src="assets/js/chartist.min.js"></script>

    <!--  Notifications Plugin    -->
    <script src="assets/js/bootstrap-notify.js"></script>

    <!--  Google Maps Plugin    -->
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js"></script>

    <!-- Paper Dashboard Core javascript and methods for Demo purpose -->
	<script src="assets/js/paper-dashboard.js"></script>

	<!-- Paper Dashboard DEMO methods, don't include it in your project! -->
	<script src="assets/js/demo.js"></script>


</html>

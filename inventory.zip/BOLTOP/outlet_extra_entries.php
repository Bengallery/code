<?php
include('header.php');


if(isset($_REQUEST['post'])){
	
	if(is_numeric($_REQUEST['quantity'])){
		
		$product_id = mysql_escape_string($_REQUEST['product']);
		$stores_id = mysql_escape_string($_REQUEST['wid']);
		$quantity = mysql_escape_string($_REQUEST['quantity']);	
		
		$entry_month = mysql_escape_string($_REQUEST['month']);
		$entry_year = mysql_escape_string($_REQUEST['year']);
		
		$entry_type = mysql_escape_string($_REQUEST['type']);
		
		$sql="INSERT INTO inv_outlet_extra_entry_adjustment values ('','$product_id','$stores_id','$quantity','$entry_month','$entry_year','$entry_type','$_SESSION[id]')"; 
		mysql_query($sql,$dbc) or die(mysql_error());	
					
		$msg = "Record updated";
	}else{ //error
		$msg = "Please enter a valid number";
	}
}

if(isset($_REQUEST['wid'])){
	$stores = mysql_escape_string($_REQUEST['wid']);
	$sql = "SELECT * FROM inv_outlets WHERE id = '$stores'";
	$result = mysql_query($sql) or die(mysql_error());
	$info = mysql_fetch_array($result);
		$sid=$info['id'];
		$outlet_name=$info['outlet_name'];
		
	$prod_id = mysql_escape_string($_REQUEST['prod']);
	$sql2 = "SELECT * FROM inv_product WHERE id = '$prod_id'";
	$result2 = mysql_query($sql2) or die(mysql_error());
	$info2 = mysql_fetch_array($result2);
		$prod_name=$info2['product_name'];		
}



$cur_month = date('m');
$cur_year = date('Y');
?>


        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">

<form method="POST" action="outlet_extra_entries.php">	
                        <div class="card">
                            <div class="header">
							<h4 class="title">
								<?php
								if((isset($_REQUEST['type']))&&($_REQUEST['type']=='1')){
									print "Out of Stock";
									print "<input type='hidden' name='type' value='1'>";
								}elseif((isset($_REQUEST['type']))&&($_REQUEST['type']=='2')){
									print "Physical Stock";
									print "<input type='hidden' name='type' value='2'>";
								}
								?>
							</h4>
							
							<?php
							if($_REQUEST['cat']=='new'){
								$link = "outlet_product_new.php?wid=$sid&pg=6&month=$_REQUEST[month]&year=$_REQUEST[year]"; //New Link Back
								print "
										<input type=\"hidden\" name=\"cat\" value=\"new\">											
										<input type=\"hidden\" name=\"month\" value=\"$_REQUEST[month]\">
										<input type=\"hidden\" name=\"year\" value=\"$_REQUEST[year]\">
								";
							}else{
								$link = "outlet_product.php?wid=$sid&pg=6"; //Old Link Back
							}
							?>
                               <a href="<?php print $link; ?>">
								Back to View
							   </a>	
                            </div>
                            
<div class="content">		

							<?php
								if(isset($msg)){
									print "<font color='blue'>".$msg."</font>";
									
								}
							?>					
						
									<div class="text-left">
										<input type="hidden" name="pg" value="6">
										<input type="hidden" name="post" value="1">										
										<button type="submit" class="btn btn-info btn-fill btn-wd">Save</button>
                                    </div>								
                                
                                   

                                    <div class="row">
									
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Product</label>
													 <input type="text" class="form-control border-input" name="" value="<?php print $prod_name; ?>" readonly="readonly">
													<input type="hidden" name="product" value="<?php print $prod_id; ?>">
                                            </div>
                                        </div>
										
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Quantity</label>
                                                <input type="text" class="form-control border-input" name="quantity">
                                            </div>  
                                        </div>
                                    </div>
									
									
									<div class="row">
                                        <div class="col-md-6">
											   <div class="form-group">
                                                <label>Outlet/Shop</label>
                                                <input type="text" class="form-control border-input" name="" value="<?php print $outlet_name; ?>" readonly="readonly">
												<input type="hidden" name="wid" value="<?php print $sid; ?>">
                                            </div>                                       
                                        </div>
										
										
										
										
													   <div class="col-md-1">
													   <label>Month:</label>
													   </div>
													   <div class="col-md-2">							  
														<select name="month" class="form-control border-input">
															<?php 
															
															for($m=1;$m<=12;$m++){
																//print "<option>$m</option>";
																if($m == $cur_month){
																	print("<option selected=\"selected\">".date('M',strtotime('01.'.$m.'.2001'))."</option>");
																}else{
																	print("<option>".date('M',strtotime('01.'.$m.'.2001'))."</option>");
																}
															}
															?>
														</select>
													   </div>
													   
													   
													   
													   
													   <div class="col-md-1">
													   <label>Year:</label>
													   </div>	
													   
													   <div class="col-md-2">
														<select name="year" class="form-control border-input">
															<?php 
															$curr_year = date('Y')+1;
															for($y=2018;$y<=$curr_year;$y++){
																if($y==$cur_year){
																	print "<option selected=\"selected\">$y</option>";
																}else{
																	print "<option>$y</option>";
																}
															}
															?>
															
														</select>
												</div>
							   
							   
							   
                                    </div>
									
									
									

                                    
                                  
                                    <div class="clearfix"></div>
</div>                                </form>


									
                        </div>
                    </div>



                </div>
            </div>
        </div>

        <?php include('footer.php') ?>


    </div>
</div>


</body>

    <!--   Core JS Files   -->
    <script src="assets/js/jquery.min.js" type="text/javascript"></script>
	<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>

	<!--  Checkbox, Radio & Switch Plugins -->
	<script src="assets/js/bootstrap-checkbox-radio.js"></script>

	<!--  Charts Plugin -->
	<script src="assets/js/chartist.min.js"></script>

    <!--  Notifications Plugin    -->
    <script src="assets/js/bootstrap-notify.js"></script>

    <!--  Google Maps Plugin    -->
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js"></script>

    <!-- Paper Dashboard Core javascript and methods for Demo purpose -->
	<script src="assets/js/paper-dashboard.js"></script>

	<!-- Paper Dashboard DEMO methods, don't include it in your project! -->
	<script src="assets/js/demo.js"></script>


</html>

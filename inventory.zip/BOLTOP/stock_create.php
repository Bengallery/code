<?php
include('header.php');
	if(isset($_REQUEST['post'])){
	  if(isset($_REQUEST['product_name'])){
		$product_name = mysql_escape_string($_REQUEST['product_name']);
		$product_type = mysql_escape_string($_REQUEST['product_type']);
		$price = mysql_escape_string($_REQUEST['price']);
		$active = mysql_escape_string($_REQUEST['active']);		
		$barcode = mysql_escape_string($_REQUEST['barcode']);
		$ref = mysql_escape_string($_REQUEST['ref']);
		$description = mysql_escape_string($_REQUEST['description']);
		
		$sql="INSERT INTO inv_product values ('','$product_name','$product_type','$price','$barcode','$ref','$description',now(),'$active','$_SESSION[id]')"; 
		mysql_query($sql,$dbc) or die(mysql_error());	
		$msg="Record created";
	  }else{
		  $msg="Sorry, please enter value for Product Name field";
	  }
	}								
?>


        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="header">
							<h4 class="title">
								Create Stock
							</h4>
                               <a href="stock.php?pg=7">
								Back to View
							   </a>	
                            </div>
                            
<div class="content">		

							<?php
								if(isset($msg)){
									print "<font color='blue'>".$msg."</font>";
									
								}
							?>					
							
								
                                
<form method="POST" action="stock_create2.php">	                                  

                                    <div class="row">                                       
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Select Product you want to stock in</label>
												<select name="product" class="form-control border-input">
												<option></option>
												<?php
												
												$query1  = "SELECT * FROM inv_product ORDER BY product_name ASC";
												$result1 = mysql_query($query1) or die(mysql_error());
												while($info1 = mysql_fetch_array($result1))
												{
														 $product_id=$info1['id'];
														 $product_name=$info1['product_name'];
														
																print "<option value='$product_id'>$product_name</option>";
																
														
												}
												?>
												</select>
                                            </div>
                                        </div>
                                    </div>
									
									<div class="row">
                                        <div class="col-md-2">
											<div class="form-group">
                                                <label>Supply Day</label>
                                                <select name="day" class="form-control border-input">
													<?php
													$cur_day = date('d');
													for($d=1; $d <= 32; $d++){
														if($cur_day==$d){
															print "<option selected='selected'>".$d."</option>";
														}else{
															print "<option>".$d."</option>";
														}														
													}
													?>
												</select>
                                            </div>                                           
                                        </div>
										 <div class="col-md-2">
											<div class="form-group">
                                                <label>Supply Month</label>
                                                <select name="month" class="form-control border-input">
													<?php
													$cur_month = date('m');
													for($m=1; $m <= 12; $m++){
														if($cur_month==$m){
															print "<option selected='selected'>".$m."</option>";
														}else{
															print "<option>".$m."</option>";
														}														
													}
													?>
												</select>
                                            </div>                                           
                                        </div>
										 <div class="col-md-2">
											<div class="form-group">
                                                <label>Supply Year</label>
                                                <select name="year" class="form-control border-input">
													<?php
													$cur_yr = date('Y');													
													for($y=2017; $y <= 2050; $y++){
														if($cur_yr==$y){
															print "<option selected='selected'>".$y."</option>";
														}else{
															print "<option>".$y."</option>";	
														}															
													}
													?>
												</select>
                                            </div>                                           
                                        </div>
                                        <div class="col-md-3">
											 <div class="form-group">
                                                <label>Supplier</label><a href="supplier.php?pg=7"><i class="ti-pencil-alt"></i></a>
                                                <select name="supply_by" class="form-control border-input">
												<?php
												
												$query1  = "SELECT * FROM inv_supplier ORDER BY supply_product_id ASC";
												$result1 = mysql_query($query1) or die(mysql_error());
												while($info1 = mysql_fetch_array($result1))
												{
														 $supply_product_id=$info1['supply_product_id'];
														 $supplier_name=$info1['supplier_name'];
														
																print "<option value='$supply_product_id'>$supplier_name</option>";
																
														
												}
												?>
												</select>
                                            </div>
                                            
                                        </div>
										
										
										<div class="col-md-3">
											 <div class="form-group">
                                                <label>Warehouse</label><a href="warehouse.php?pg=7"><i class="ti-pencil-alt"></i></a>
                                                <select name="warehouse" class="form-control border-input">
												<?php
												
												$query1  = "SELECT * FROM  inv_warehouse ORDER BY id ASC";
												$result1 = mysql_query($query1) or die(mysql_error());
												while($info1 = mysql_fetch_array($result1))
												{
														 $warehouse_id=$info1['id'];
														 $warehouse_name=$info1['warehouse_name'];
														
																print "<option value='$warehouse_id'>$warehouse_name</option>";
																
														
												}
												?>
												</select>
                                            </div>
                                            
                                        </div>
										
                                    </div>

                                    <div class="row">
											
											
											<div class="col-md-1">
												<div class="form-group">
													<label>Exp Not applicable</label>
													<input type="checkbox" name="exp_not_applicable">
												</div> 
											</div>
											
											<div class="col-md-2">
												<div class="form-group">
													<label>Expiry Day</label>
													<select name="x_day" class="form-control border-input">
														<?php
														$cur_day = date('d');
														for($d=1; $d <= 32; $d++){
															if($cur_day==$d){
																print "<option selected='selected'>".$d."</option>";
															}else{
																print "<option>".$d."</option>";
															}														
														}
														?>
													</select>
												</div> 
											</div>
											
											<div class="col-md-2">
												<div class="form-group">
													<label>Expiry Month</label>
													<select name="x_month" class="form-control border-input">
														<?php
														$cur_month = date('m');
														for($m=1; $m <= 12; $m++){
															if($cur_month==$m){
																print "<option selected='selected'>".$m."</option>";
															}else{
																print "<option>".$m."</option>";
															}														
														}
														?>
													</select>
												</div>
											</div>											
											
											<div class="col-md-2">
												<div class="form-group">
													<label>Expiry Year</label>
													<select name="x_year" class="form-control border-input">
														<?php
														$cur_yr = date('Y');													
														for($y=2017; $y <= 2050; $y++){
															if($cur_yr==$y){
																print "<option selected='selected'>".$y."</option>";
															}else{
																print "<option>".$y."</option>";	
															}															
														}
														?>
													</select>
												</div>                                           
											</div>
											
											<div class="col-md-1">
												<div class="form-group">
													
												</div> 
											</div>
											
											<div class="col-md-2">
												<div class="form-group">
													<label>Quantity</label>
													<select name="quantity" class="form-control border-input">
														<?php
														for($q=1; $q <= 2000; $q++){
															print "<option>".$q."</option>";														
														}
														?>
													</select>
												</div> 
											</div>
                                        
											<div class="col-md-2">
												<div class="form-group">
													<label>Adjustment (optional)</label>
													<select name="adjustment" class="form-control border-input">
														<?php
														for($a=0; $a <= 100; $a++){
															print "<option>".$a."</option>";														
														}
														?>
													</select>
												</div> 
											</div>
										
                                    </div>
									
									
                                  
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Description</label>
                                                <textarea rows="5" class="form-control border-input" name="description"></textarea>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="text-center">
										<input type="hidden" name="pg" value="3">
										<input type="hidden" name="post" value="1">
												
										<?php
										if(isset($_REQUEST['edit'])){
											print '<button type="submit" class="btn btn-info btn-fill btn-wd">Update</button>';
										}else{
											print '<button type="submit" class="btn btn-info btn-fill btn-wd">Create</button>';
										}
										?>
								
                                        
										
										
                                    </div>
                                    <div class="clearfix"></div>
</div>                                </form>
									
                        </div>
                    </div>



                </div>
            </div>
        </div>

        <?php include('footer.php') ?>


    </div>
</div>


</body>

    <!--   Core JS Files   -->
    <script src="assets/js/jquery.min.js" type="text/javascript"></script>
	<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>

	<!--  Checkbox, Radio & Switch Plugins -->
	<script src="assets/js/bootstrap-checkbox-radio.js"></script>

	<!--  Charts Plugin -->
	<script src="assets/js/chartist.min.js"></script>

    <!--  Notifications Plugin    -->
    <script src="assets/js/bootstrap-notify.js"></script>

    <!--  Google Maps Plugin    -->
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js"></script>

    <!-- Paper Dashboard Core javascript and methods for Demo purpose -->
	<script src="assets/js/paper-dashboard.js"></script>

	<!-- Paper Dashboard DEMO methods, don't include it in your project! -->
	<script src="assets/js/demo.js"></script>


</html>

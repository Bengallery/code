<?php
include('header.php');
	if(isset($_REQUEST['post'])){
	  if(isset($_REQUEST['customer'])){
		$customer = mysql_escape_string($_REQUEST['customer']);
		$ref_desc = mysql_escape_string($_REQUEST['ref_desc']);
		$outlet = mysql_escape_string($_REQUEST['wid']);
		
		$day = mysql_escape_string($_REQUEST['day']);
		$month = mysql_escape_string($_REQUEST['month']);
		$year = mysql_escape_string($_REQUEST['year']);
		
		$date = "$day/$month/$year";
		
		
		//before inserting quotation, locate the saleperson quotation without orderline and delete. before inserting new. This is to remove duplications
		$query1  = "SELECT * FROM  inv_quotation_outlet WHERE status <> 'D' AND salesperson_id='$_SESSION[id]' ORDER BY id DESC";
		$result1 = mysql_query($query1) or die(mysql_error());
		$info1 = mysql_fetch_array($result1);
		$quotation_id=$info1['id'];	
		$customer_id=$info1['customer_id'];	
			
			$query2  = "SELECT * FROM  inv_order_line_outlet WHERE input_by='$_SESSION[id]' AND order_id='$quotation_id'";
			$result2 = mysql_query($query2) or die(mysql_error());
			if (mysql_num_rows($result2) == 0) {
				$del  = "DELETE FROM inv_quotation_outlet WHERE salesperson_id='$_SESSION[id]' AND id='$quotation_id'";
				mysql_query($del, $dbc) or die(mysql_error());	
				 //$msg="DEL";
			}
					$sql="INSERT INTO inv_quotation_outlet values ('','$customer','$date','$ref_desc','$outlet','$_SESSION[id]','1','',now())"; 
					mysql_query($sql,$dbc) or die(mysql_error());	
					$last_inserted_id = mysql_insert_id();
					//$msg="Record created";
					//$msg="INS";	
					
					
			
	  }   		
			
	}	
	
	
	
	if(isset($_REQUEST['post2'])){
	  if(isset($_REQUEST['product'])){
		  
		$query1  = "SELECT * FROM  inv_quotation_outlet WHERE status <> 'D' AND salesperson_id='$_SESSION[id]' ORDER BY id DESC";
		$result1 = mysql_query($query1) or die(mysql_error());
		$info1 = mysql_fetch_array($result1);
		$quotation_id=$info1['id'];		
		$outlet_id = $info1['outlet_id'];		
														 
		$product = mysql_escape_string($_REQUEST['product']);
		$quantity = mysql_escape_string($_REQUEST['quantity']);
		$unit_price = mysql_escape_string($_REQUEST['unit_price']);
		$discount = mysql_escape_string($_REQUEST['discount']);
		$tax = mysql_escape_string($_REQUEST['tax']);	
		$describe = mysql_escape_string($_REQUEST['describe']);	
		
		/*
		//Making diduction from stock, if you have enough product in the stock
		$query2  = "SELECT * FROM  inv_stock WHERE product ='$product' AND warehouse='$warehouse_id' AND stock_on_hand <> '0' ORDER BY id DESC";
		$result2 = mysql_query($query2) or die(mysql_error());
		$info2 = mysql_fetch_array($result2);
			$stock_id=$info2['id'];	
			$stock_on_hand=$info2['stock_on_hand'];	

		if($stock_on_hand > $quantity){	//we have enough in-stock
		*/		
		
		$day = mysql_escape_string($_REQUEST['day']);
		$month = mysql_escape_string($_REQUEST['month']);
		$year = mysql_escape_string($_REQUEST['year']);
		
		
			$sql="INSERT INTO inv_order_line_outlet values ('','$product','$quantity','$unit_price','$discount','$tax','$describe','$_SESSION[id]','$quotation_id','$outlet_id','$day','$month','$year')"; 
			mysql_query($sql,$dbc) or die(mysql_error());	
			$msg="Record created";
		/*	
			//Deduct from the stock
			$stock_on_hand_after_this_order = ($stock_on_hand - $quantity);
			$sql = "UPDATE inv_stock SET stock_on_hand = '$stock_on_hand_after_this_order' WHERE id = '$stock_id'";
			mysql_query($sql, $dbc) or die(mysql_error());
			
		}else{
			$msg = "We don't have enough of this item in stock, we only have <b>".$stock_on_hand."</b> in stock";
		}
		*/
	  }else{
		  $msg="Sorry, please enter value for Product Name field";
	  }
	}	


	
	//Adding new Item to existig quotation-------------------------------------
	if(isset($_REQUEST['qt'])){
		$qt = mysql_escape_string($_REQUEST['qt']);
		$quotation_id=$qt;	
	}
	
	if(isset($_REQUEST['post3'])){
	  if(isset($_REQUEST['product'])){
			$product = mysql_escape_string($_REQUEST['product']);
			$quantity = mysql_escape_string($_REQUEST['quantity']);
			$unit_price = mysql_escape_string($_REQUEST['unit_price']);
			$discount = mysql_escape_string($_REQUEST['discount']);
			$tax = mysql_escape_string($_REQUEST['tax']);	
			$describe = mysql_escape_string($_REQUEST['describe']);	
			$outlet_id = mysql_escape_string($_REQUEST['outlet_id']);
			
			
			$day = mysql_escape_string($_REQUEST['day']);
			$month = mysql_escape_string($_REQUEST['month']);
			$year = mysql_escape_string($_REQUEST['year']);
			
			$sql="INSERT INTO inv_order_line_outlet values ('','$product','$quantity','$unit_price','$discount','$tax','$describe','$_SESSION[id]','$quotation_id','$outlet_id','$day','$month','$year')"; 
			mysql_query($sql,$dbc) or die(mysql_error());	
			$msg="Record Added";
	  }else{
		  $msg="Sorry, please enter value for Product Name field";
	  }
	}	 


	
		
	//Editing orderlig DONE -----------------------------------------------------------------
	if(isset($_REQUEST['post4'])){
		if(isset($_REQUEST['product'])){
			
			$oid = mysql_escape_string($_REQUEST['oid']);
			$quotation_id = mysql_escape_string($_REQUEST['quotation_id']);
			
			$product = mysql_escape_string($_REQUEST['product']);
			$quantity = mysql_escape_string($_REQUEST['quantity']);
			$unit_price = mysql_escape_string($_REQUEST['unit_price']);
			$discount = mysql_escape_string($_REQUEST['discount']);
			$tax = mysql_escape_string($_REQUEST['tax']);	
			$describe = mysql_escape_string($_REQUEST['describe']);	
			
			$day = mysql_escape_string($_REQUEST['day']);
			$month = mysql_escape_string($_REQUEST['month']);
			$year = mysql_escape_string($_REQUEST['year']);
			
						
			$sql = "UPDATE inv_order_line_outlet SET product_id='$product', quantity='$quantity', unit_price='$unit_price', discount='$discount', tax='$tax', description='$describe', input_by='$_SESSION[id]', day='$day', month='$month', year='$year'  WHERE id = '$oid'";
			
			mysql_query($sql, $dbc) or die(mysql_error());
			
			$msg="Record Updated";
	  }else{
		  $msg="Sorry, please enter value for Product Name field";
	  }
		
	}
		

	//Editing orderling -----------------------------------------------------------------
	if(isset($_REQUEST['oid'])){
		
		$oid = mysql_escape_string($_REQUEST['oid']);
		$quotation_id = mysql_escape_string($_REQUEST['quotation_id']);
		
		$query  = "SELECT * FROM  inv_order_line_outlet WHERE id='$oid'";
		$result = mysql_query($query) or die(mysql_error());
		$info = mysql_fetch_array($result);
			$e_product_id=$info['product_id'];	
			$e_quantity=$info['quantity'];
			$e_unit_price=$info['unit_price'];
			$e_discount=$info['discount'];
			$e_tax=$info['tax'];
			$e_description=$info['description'];
			$sid=$info['order_id'];
	}
	
	
	
	
	if(isset($_REQUEST['wid'])){
	$stores = mysql_escape_string($_REQUEST['wid']);

	$sql = "SELECT * FROM inv_outlets WHERE id = '$stores'";
	$result = mysql_query($sql) or die(mysql_error());
	$info = mysql_fetch_array($result);
		$sid=$info['id'];
		$outlet_name=$info['outlet_name'];
	}
?>


        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="header">
							<h4 class="title">
								<?php print $outlet_name; ?>
							</h4>
							<?php if(isset($_REQUEST['qt'])){ ?>								 
										<a href="outlets.php?pg=6">
												<button class="btn btn-success btn-fill btn-wd">Go Back</button>
									    </a>
										 
							<?php }else {?>
                              	
										<a href="outlet_quotation_sales_create.php?wid=<?php print $sid; ?>&pg=6">
												<button class="btn btn-success btn-fill btn-wd">Go Back</button>
									    </a>
										
							<?php } ?>   
							  
                            </div>
                            
<div class="content">		

							<?php
							/*
							print 'warehouse_id '.$warehouse_id;
							print '<br/>product id'.$product;
							*/
							
								if(isset($msg)){
									print "<font color='blue'>".$msg."</font>";
									
								}
							?>					
<form method="POST" action="outlet_quotation_sales_create_order_line.php">							
									<div class="text-left">
										<input type="hidden" name="pg" value="6">
										<input type="hidden" name="wid" value="<?php print $sid; ?>">
										
										<?php
										
										if(isset($_REQUEST['oid'])){
											print '<input type="hidden" name="post4" value="1">';
											print '<input type="hidden" name="quotation_id" value="'.$quotation_id.'">';
											print '<input type="hidden" name="oid" value="'.$oid.'">';	
											print '<input type="hidden" name="outlet_id" value="'.$_REQUEST['outlet_id'].'">';											
											
											print '<input type="hidden" name="day" value="'.$_REQUEST['day'].'">';
											print '<input type="hidden" name="month" value="'.$_REQUEST['month'].'">';
											print '<input type="hidden" name="year" value="'.$_REQUEST['year'].'">';
											
											
											print '<button type="submit" class="btn btn-success btn-fill btn-wd">Update</button>';
										}else{
											if(isset($_REQUEST['qt'])){
												print '<input type="hidden" name="post3" value="1">';
												print '<input type="hidden" name="qt" value="'.$qt.'">';													
												print '<input type="hidden" name="outlet_id" value="'.$_REQUEST['outlet_id'].'">';
												
												
												print '<input type="hidden" name="day" value="'.$_REQUEST['day'].'">';
												print '<input type="hidden" name="month" value="'.$_REQUEST['month'].'">';
												print '<input type="hidden" name="year" value="'.$_REQUEST['year'].'">';
												
											
											
											}else{
												print '<input type="hidden" name="post2" value="1">';
												
												
												print '<input type="hidden" name="day" value="'.$_REQUEST['day'].'">';
												print '<input type="hidden" name="month" value="'.$_REQUEST['month'].'">';
												print '<input type="hidden" name="year" value="'.$_REQUEST['year'].'">';
												
											
											}
										
											print '<button type="submit" class="btn btn-info btn-fill btn-wd">Save / Add Item</button>';
										}
										?>		
										
                                    </div>								
                                
                                   

                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Product</label>
                                                <select name="product" class="form-control border-input" id="country">
												<option></option>
												<?php
												
												$query1  = "SELECT * FROM  inv_product WHERE status <> 'D' ORDER BY product_name ASC";
												$result1 = mysql_query($query1) or die(mysql_error());
												while($info1 = mysql_fetch_array($result1))
												{
														 $product_id=$info1['id'];
														 $product_name=$info1['product_name'];
														  $sale_price=$info1['sale_price'];
														
														 if((isset($e_product_id))&&($e_product_id==$product_id)){
															  print "<option value='$product_id' value2='$sale_price' selected='selected'>$product_name</option>";
														 }else{
															print "<option value='$product_id' value2='$sale_price'>$product_name</option>";
														 }
														
												}
												?>
													
												</select>    
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Quantity</label>
                                                <input type="text" class="form-control border-input" name="quantity" value="<?php print $e_quantity; ?>">
                                            </div>  
                                        </div>
                                    </div>
									
									
									
									<div class="row">
                                       <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Unit Price</label>
                                                <input type="text" class="form-control border-input" name="unit_price" id="unit_price" value="<?php print $e_unit_price; ?>">
                                            </div>  
                                        </div>
                                        
										 <div class="col-md-3">
                                            <div class="form-group">
                                                <label>Tax</label>
                                                <input type="text" class="form-control border-input" name="tax" value="<?php print $e_tax; ?>">
                                            </div>  
                                        </div>
										
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label>Discount (%)</label>
                                                <input type="text" class="form-control border-input" name="discount" value="<?php print $e_discount; ?>">
                                            </div>  
                                        </div>
                                    </div>
									
									
									
									<!-- ================================= Date here ======================================== -->
									
									<div class="row">
                                       <div class="col-md-4">
                                            <div class="form-group">
                                                <label>Day</label>
                                                <input type="text" class="form-control border-input" name="day" id="day" value="<?php print $_REQUEST['day']; ?>" readonly="true">
                                            </div>  
                                        </div>
                                        
										<div class="col-md-4">
                                            <div class="form-group">
                                                <label>Month</label>
                                                <input type="text" class="form-control border-input" name="month" value="<?php print $_REQUEST['month']; ?>" readonly="true">
                                            </div>  
                                        </div>
										
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label>Year</label>
                                                <input type="text" class="form-control border-input" name="year" value="<?php print $_REQUEST['year']; ?>" readonly="true">
                                            </div>  
                                        </div>
                                    </div>
									
									
									
									<div class="row">
                                        <div class="col-md-12">
											<div class="form-group">
                                                <label>Description</label>
												  <textarea class="form-control border-input" name="describe" rows="4"><?php print $e_description; ?></textarea>
                                            </div>                             
                                        </div>
                                        
                                    </div>
									
									
									

                                    
                                  
                                    <div class="clearfix"></div>
									

									

									
									
									</div>                                </form>


									
                        </div>
						
<?php
if(!isset($_REQUEST['quotation_id'])){
?>						
						<div class="card">

					
                            <div class="content table-responsive table-full-width">
							
					
							
							
                                <table class="table table-striped">
                                    <thead>
										<th>Product</th>
										<th>Date</th>
                                        <th>Description</th>
										<th>Quantity</th>
										<th>Unit Price</th>
										<th>Discount</th>
										<th>Subtotal</th>
                                    </thead>
									
									
                                    <tbody>
									
									
<?php
$rowsPerPage = 10;

// by default we show first page
$pageNum = 1;

// if $_GET['page'] defined, use it as page number
if(isset($_GET['page']))
{
	$pageNum = $_GET['page'];
}

// counting the offset
$offset = ($pageNum - 1) * $rowsPerPage;




if(isset($_REQUEST['post2'])){
	$sql = "SELECT * FROM inv_order_line_outlet WHERE order_id = '$quotation_id'";
}elseif(isset($_REQUEST['post'])){
	$sql = "SELECT * FROM inv_order_line_outlet WHERE order_id='$last_inserted_id'";
}elseif(isset($_REQUEST['qt'])){
	$qt = mysql_escape_string($_REQUEST['qt']);
	$sql = "SELECT * FROM inv_order_line_outlet WHERE order_id='$qt'";
}
$pagingQuery = "ORDER BY id DESC LIMIT $offset, $rowsPerPage";

$result = mysql_query($sql . $pagingQuery) or die(mysql_error());


while($info = mysql_fetch_array($result)){ 
	$id=$info['id'];
	$product_id=$info['product_id'];
	$quantity=$info['quantity'];
	$unit_price=$info['unit_price'];
	$discount=$info['discount'];
	$description=$info['description'];
	$input_by=$info['input_by'];
	$order_id=$info['order_id'];
	$day=$info['day'];
	$month=$info['month'];
	$year=$info['year'];
	
		//Get product name
		$query1  = "SELECT * FROM  inv_product WHERE id='$product_id' ORDER BY id DESC";
		$result1 = mysql_query($query1) or die(mysql_error());
		$info1 = mysql_fetch_array($result1);
			$product_id=$info1['id'];
			$product_name=$info1['product_name'];	
			
	
	
	print "
	<tr>
                                        	<td>$product_name</td>
											<td>$day/$month/$year</td>
											<td>$description</td>
											<td>$quantity</td>
                                        	<td>$unit_price</td>
											<td>$discount</td>
											<td></td>
											
    </tr>
	";
	
}

print '
      
                                    </tbody>
                                </table>
';


?>										
                                        
                                  

                            </div>
                        </div>
<?php
}
?>						
						
						
                    </div>



                </div>
            </div>
        </div>

        <?php include('footer.php') ?>


    </div>
</div>


<script>

$("#country").change(function () {
    var selectedValue = $(this).val	
	
	$("#unit_price").val($(this).find("option:selected").attr("value2"))	
});
    
</script>
</body>

    <!--   Core JS Files   -->
    <script src="assets/js/jquery.min.js" type="text/javascript"></script>
	<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>

	<!--  Checkbox, Radio & Switch Plugins -->
	<script src="assets/js/bootstrap-checkbox-radio.js"></script>

	<!--  Charts Plugin -->
	<script src="assets/js/chartist.min.js"></script>

    <!--  Notifications Plugin    -->
    <script src="assets/js/bootstrap-notify.js"></script>

    <!--  Google Maps Plugin    -->
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js"></script>

    <!-- Paper Dashboard Core javascript and methods for Demo purpose -->
	<script src="assets/js/paper-dashboard.js"></script>

	<!-- Paper Dashboard DEMO methods, don't include it in your project! -->
	<script src="assets/js/demo.js"></script>


</html>

<?php
include('header.php');

if(isset($_REQUEST['qt'])){

$qt = mysql_escape_string($_REQUEST['qt']);
$sql = "SELECT * FROM inv_transfer WHERE id='$qt'";
$result = mysql_query($sql) or die(mysql_error());


$info = mysql_fetch_array($result);
	$id=$info['id'];
	$warehouse=$info['warehouse'];
	$destination=$info['destination'];
	$parner=$info['parner'];
	$created_date=$info['created_date'];
	$source_doc=$info['source_doc'];	
	$back_order=$info['back_order'];
	$invoice=$info['invoice'];
	$status=$info['status'];
	
		
	
	//Warehouse
			$sql_1 = "SELECT * FROM  inv_warehouse WHERE id = '$warehouse'";
			$result_1 = mysql_query($sql_1) or die(mysql_error());
			$info_1 = mysql_fetch_array($result_1);
				$warehouse_name=$info_1['warehouse_name'];
	//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

			$sql_ = "SELECT * FROM  inv_transfer_create WHERE transfer_id = '$id'";
			$result_ = mysql_query($sql_) or die(mysql_error());
			$info_ = mysql_fetch_array($result_);
				$destination_location=$info_['destination_location'];

				//Get Location
				$query1  = "SELECT * FROM  inv_outlets WHERE id='$destination_location' ORDER BY id DESC";
				$result1 = mysql_query($query1) or die(mysql_error());
				$info1 = mysql_fetch_array($result1);
					$outlet_name=$info1['outlet_name'];	
					
	
}
?>


        <div class="content">
		
<?php
if(isset($_REQUEST['msg'])){
	print "<font color='blue'>".$_REQUEST['msg']."</font>";
}
?>	
		
		
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
						
								
                            <div class="header">
										<div class="text-left">
										<input type="hidden" name="pg" value="3">
										<input type="hidden" name="post" value="1">
										<!--		
										<button type="submit" class="btn btn-info btn-fill btn-wd">Send by Email</button>
										<button type="submit" class="btn btn-danger btn-fill btn-wd">Confirm Sale</button>
										-->
										
										<a href="warehouse_view.php?wid=<?php print $_REQUEST['wid']; ?>&pg=12">
										<button class="btn btn-info btn-fill btn-wd">Go Back</button>
										</a>
										<a href="transfer_cancel.php?pg=12&pid=<?php print $qt; ?>&wid=<?php print $_REQUEST['wid']; ?>"><button class="btn btn-danger btn-fill btn-wd">Reverse Transfer</button></a>
										<button class="btn btn-success btn-fill btn-wd">Print</button>
                                    </div>
									
								
						
                            </div>
                            
<div class="content">		

										
<form method="POST" action="#">							
									
                                   

                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Store/Outlet</label>   
												<?php print $outlet_name;?>	
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Warehouse</label>
                                                <?php
														 print $warehouse_name;
												?>
                                            </div>  
                                        </div>								
										
										
                                    </div>
									
									
									
									<div class="row">
                                        <div class="col-md-6">
											   <div class="form-group">
                                                <label>Source Document</label>
                                               
												<?php
												
														 print $source_doc;
																
												?>
                                            </div>                                       
                                        </div>
                                        <div class="col-md-6">
											<div class="form-group">
                                                <label>Creation Date</label>
												 <?php print $created_date; ?>
                                            </div> 
                                        </div>
										
                                    </div>
									
									
									
									<div class="row">
                                        <div class="col-md-6">
											<div class="form-group">
                                                <label>Transfer Id:</label>
												 <?php print $id; ?>
                                            </div> 
                                        </div>
                                        <div class="col-md-6">
											<div class="form-group">
                                                <label>Source Info</label>
												 <?php print $source_doc; ?>
                                            </div> 
                                        </div>
										
                                    </div>
									
									
									
									
									
									
									

                                    
                                  
                                    <div class="clearfix"></div>
</div>                                </form>


									
                        </div>
                    </div>
					
					
					<div class="card">
					
					
                           
                            <div class="content table-responsive table-full-width">
							
					<p align="center">
						<a href="warehouse_sales_create_order_line.php?pg=12&qt=<?php print $qt; ?>&wid=<?php print $_REQUEST['wid']; ?>&stores=<?php print $destination_location; ?>"><button class="btn btn-info btn-fill btn-wd">Add Another Item</button></a>
					</p>
							
							
 <table class="table table-striped">
                                    <thead>
										
										<th>Entry Id</th>
										<th>Product</th>
										<th>Quantity</th>
										<th>Destination Location</th>
										<th>Incoming Date</th>
										<th></th>
                                    </thead>
									
									
                                    <tbody>
									
									
<?php
/*
$rowsPerPage = 10;

// by default we show first page
$pageNum = 1;

// if $_GET['page'] defined, use it as page number
if(isset($_GET['page']))
{
	$pageNum = $_GET['page'];
}

// counting the offset
$offset = ($pageNum - 1) * $rowsPerPage;

*/


if(isset($_REQUEST['post2'])){
	$sql = "SELECT * FROM  inv_transfer_create WHERE transfer_id = '$transfer_id'";
}elseif(isset($_REQUEST['post'])){
	$sql = "SELECT * FROM inv_transfer_create WHERE transfer_id='$last_inserted_id'";
}elseif(isset($_REQUEST['qt'])){
	$qt = mysql_escape_string($_REQUEST['qt']);
	$sql = "SELECT * FROM inv_transfer_create WHERE transfer_id='$qt'";
}
$pagingQuery = "ORDER BY id DESC";

$result = mysql_query($sql . $pagingQuery) or die(mysql_error());


while($info = mysql_fetch_array($result)){ 
	$id=$info['id'];
	$product_id=$info['product'];
	$quantity=$info['quantity'];
	$invoice_control=$info['invoice_control'];
	$date=$info['date'];
	$expected_date=$info['expected_date'];
	$description=$info['description'];
	$source_location=$info['source_location'];
	$destination_location=$info['destination_location'];
	$posted_by=$info['posted_by'];
	$transfer_id=$info['transfer_id'];
	
		//Get product name
		$query1  = "SELECT * FROM  inv_product WHERE id='$product_id' ORDER BY id DESC";
		$result1 = mysql_query($query1) or die(mysql_error());
		$info1 = mysql_fetch_array($result1);
			$product_id=$info1['id'];
			$product_name=$info1['product_name'];	
			
			
		//Get Location
		$query1  = "SELECT * FROM  inv_outlets WHERE id='$destination_location' ORDER BY id DESC";
		$result1 = mysql_query($query1) or die(mysql_error());
		$info1 = mysql_fetch_array($result1);
			$loc_id=$info1['id'];
			$outlet_name=$info1['outlet_name'];	
			
	
	
	print "
	<tr>
                                        	
											<td>$id</td>
											<td>$product_name</td>
											<td>$quantity</td>
                                        	<td>$outlet_name</td>
											<td>$date</td>
											<td>
											<a href=\"transfer_cancel.php?oid=$id&qt=$qt&pg=12\">Delete</a>
											|
											<a href=\"warehouse_sales_create_order_line.php?oid=$id&qt=$qt&pg=12\">Edit</a>
											
											</td>
											
    </tr>
	";
	
}

print '
      
                                    </tbody>
                                </table>
';


?>                               
                                        
                                  

                            </div>
                        </div>



                </div>
            </div>
        </div>

        <?php include('footer.php') ?>


    </div>
</div>


</body>

    <!--   Core JS Files   -->
    <script src="assets/js/jquery.min.js" type="text/javascript"></script>
	<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>

	<!--  Checkbox, Radio & Switch Plugins -->
	<script src="assets/js/bootstrap-checkbox-radio.js"></script>

	<!--  Charts Plugin -->
	<script src="assets/js/chartist.min.js"></script>

    <!--  Notifications Plugin    -->
    <script src="assets/js/bootstrap-notify.js"></script>

    <!--  Google Maps Plugin    -->
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js"></script>

    <!-- Paper Dashboard Core javascript and methods for Demo purpose -->
	<script src="assets/js/paper-dashboard.js"></script>

	<!-- Paper Dashboard DEMO methods, don't include it in your project! -->
	<script src="assets/js/demo.js"></script>


</html>

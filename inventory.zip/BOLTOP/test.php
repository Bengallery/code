<?php
//create and issue query
include("conn.php");

$phone = mysql_escape_string($_POST['phone']);
$password = mysql_escape_string($_POST['password']);

$sql = "SELECT * FROM inv_user WHERE (phone='$phone' OR email='$phone') AND password='$password'";
$result = mysql_query($sql, $dbc) or die(mysql_error());

//get the number of rows in the result set; should be 1 if a match
if (mysql_num_rows($result) == 1) {
	$id = mysql_result($result, 0, 'id');
	$phone = mysql_result($result, 0, 'phone');
	$password = mysql_result($result, 0, 'password');
	$surname = mysql_result($result, 0, 'surname');
	$other_names = mysql_result($result, 0, 'other_names');
	$email = mysql_result($result, 0, 'email');
	$user_type = mysql_result($result, 0, 'user_type');
	
	session_start();
					$_SESSION['id']=$id;
					$_SESSION['phone']=$phone;
					$_SESSION['surname']=$surname;
					$_SESSION['other_names']=$other_names;
					$_SESSION['email']=$email;
					$_SESSION['user_type']=$user_type;
					
					/*
					if($_SESSION['user_type']=='3'){
						header("Location:collate.php?pg=3");
					}else{ */
						header("Location:dashboard.php");
					//}
	
} else {
	
		header("Location:index.php?msg=Invalid ID, try again");	
}
	
?>
<?php
// Connection 
include("conn.php");

if(isset($_REQUEST['wid'])){
	$stores = mysql_escape_string($_REQUEST['wid']);

	$sql = "SELECT * FROM inv_outlets WHERE id = '$stores'";
	$result = mysql_query($sql) or die(mysql_error());
	$info = mysql_fetch_array($result);
		$sid=$info['id'];
		$outlet_name=$info['outlet_name'];
}



$filename = $outlet_name.'_'.date('d-m-Y')."_Download.xls"; // File Name
// Download file
header("Content-Disposition: attachment; filename=\"$filename\"");
header("Content-Type: application/vnd.ms-excel");

//$user_query = mysql_query('SELECT * FROM inv_product');
// Write data to file

$offset = $_REQUEST['offset'];
$rowsPerPage = 1000;

$sql = "SELECT * FROM inv_product ";
$pagingQuery = "ORDER BY product_name ASC LIMIT $offset, $rowsPerPage";


$result = mysql_query($sql . $pagingQuery) or die(mysql_error());



$flag = false;
while($info = mysql_fetch_array($result)){ 
	
	$id=$info['id'];
	$product_name=$info['product_name'];
	$product_type=$info['product_type'];
	$sale_price=$info['sale_price'];
	$ean13_barcode=$info['ean13_barcode'];
	$int_ref=$info['int_ref'];
	$description=$info['description'];
	
		//Get total purchase (Stock in)
		$query2  = "SELECT SUM(quantity) AS total_stock_in, transfer_id FROM inv_transfer_create WHERE product='$id' AND destination_location='$sid'";
		$result2 = mysql_query($query2) or die(mysql_error());
		$info2 = mysql_fetch_array($result2);
		$total_stock_in=$info2['total_stock_in'];
		$transfer_id=$info2['transfer_id'];
		
		
		
			if(!$total_stock_in){
				$total_stock_in=0;
			}
			
		//Get total Sales (Stock out)
		/*
		$query5  = "SELECT * FROM  inv_quotation_outlet WHERE outlet_id ='$sid'";
		$result5 = mysql_query($query5) or die(mysql_error());
			$info5 = mysql_fetch_array($result5);
				$q_id=$info5['id'];
		*/
		
		$query3  = "SELECT SUM(quantity) AS total_stock_out FROM  inv_order_line_outlet WHERE product_id='$id' AND outlet_id='$sid'";
		$result3 = mysql_query($query3) or die(mysql_error());
		$info3 = mysql_fetch_array($result3);
		$total_stock_out=$info3['total_stock_out'];
		
			if(!$total_stock_out){
				$total_stock_out=0;
			}
		
			
	if (!$flag) {		
		echo 'Product';
		echo "\t".'Price';
		echo "\t".'B/F';
		echo "\t".'Supply';
		echo "\t".'Sales';
		echo "\t".'Out of Stock';		
		echo "\t".'Balance';
		echo "\t".'Physical Stock';
		echo "\t".'Variance' . "\r\n";
		 $flag = true;
    }		
			
			
	
if(($total_stock_in!='0')||($total_stock_out!='0')){
	
		//Out of Stock
	$query5  = "SELECT quantity FROM inv_outlet_extra_entry_adjustment WHERE entry_type='1' AND outlet_id='$sid' AND product_id='$id' ORDER BY id DESC";
	$result5 = mysql_query($query5) or die(mysql_error());
	$info5 = mysql_fetch_array($result5);
	$quantity_out_of_stock=$info5['quantity'];
	if(isset($quantity_out_of_stock)){
		$oos = "$quantity_out_of_stock";
	}else{
		$oos = "0";
	}
	

	
	//Physical Stock
	$query6  = "SELECT quantity FROM inv_outlet_extra_entry_adjustment WHERE entry_type='2' AND outlet_id='$sid' AND product_id='$id' ORDER BY id DESC";
	$result6 = mysql_query($query6) or die(mysql_error());
	$info6 = mysql_fetch_array($result6);
	$quantity_physical_stock=$info6['quantity'];
	
	if(isset($quantity_physical_stock)){
		$ps = "$quantity_physical_stock";
	}else{
		$ps = "0";
	}
	
	//Balance = [BF]+[Supply]-[Sale]-[Out of Stock]
	//$stock_balance = ($total_stock_in - ($total_stock_out-$quantity_out_of_stock));
	
	//((([BF]+[Supply])+[Out of Stock])-[Sale])
	$stock_balance = (($total_stock_in - $quantity_out_of_stock) - $total_stock_out);
			
			
	//Varient = [Balance]-[Physical Stock]	
	$variant = ($stock_balance-$quantity_physical_stock);
	
			
	
                                    echo $product_name;
									echo "\t".$sale_price;                                    	
											
											
											
											$query4  = "SELECT source_doc FROM inv_transfer WHERE id ='$transfer_id'";
											$result4 = mysql_query($query4) or die(mysql_error());
												$info4 = mysql_fetch_array($result4);
													$source_doc=$info4['source_doc'];
											
		
											if($source_doc=="B/F"){
												echo "\t".$total_stock_in;
												echo "\t".'-';
												
												
											}else{
												echo "\t".'-';
												echo "\t".$total_stock_in;
												
											}
											
									
									echo "\t".$total_stock_out;
									echo "\t".$oos;
									echo "\t".$stock_balance;
									echo "\t".$ps;
									echo "\t".$variant. "\r\n";
											
  
	}
	//echo $product_name;
	//echo "\t".$product_type. "\r\n";
}

?>
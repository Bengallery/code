<footer class="footer">
            <div class="container-fluid">
               
                <div class="copyright pull-right">
                    &copy; <script>document.write(new Date().getFullYear())</script> BOLTOP Inventory System
                </div>
            </div>
        </footer>
		
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="select2.min.js"></script>
<script>
$("#country").select2( {
	placeholder: "Select Product",
	allowClear: true
	} );
</script>
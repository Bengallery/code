<hr/>
<footer class="footer">
            <div class="container-fluid">
               <p align="right">
                    <b>Phone:</b> 08020539741  <b>Email:</b> boltop@boltopng.com 
					<br/>
					 <b>Bank Account:</b> FCMB: 3222357010
                </p>
                <div class="copyright pull-right">
                    &copy; <script>document.write(new Date().getFullYear())</script> BOLTOP Inventory System
                </div>
            </div>
        </footer>
		
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="select2.min.js"></script>
<script>
$("#country").select2( {
	placeholder: "Select Product",
	allowClear: true
	} );
</script>
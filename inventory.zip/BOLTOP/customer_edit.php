<?php
include('header.php');
	if(isset($_REQUEST['post'])){
	  
		$pid = mysql_escape_string($_REQUEST['pid']);
		$name = mysql_escape_string($_REQUEST['name']);
		$company = mysql_escape_string($_REQUEST['company']);
		$email = mysql_escape_string($_REQUEST['email']);
		$phone = mysql_escape_string($_REQUEST['phone']);		
		$position = mysql_escape_string($_REQUEST['position']);
		$web = mysql_escape_string($_REQUEST['web']);
		$address = mysql_escape_string($_REQUEST['address']);
		
		
		
		$sql = "UPDATE inv_customer SET		
			name='$name',
			company='$company',
			address='$address',
			job_position='$position',
			phone='$phone',
			email='$email',
			website='$web',
			created_by='$_SESSION[id]',
			date_created=now()	
		WHERE id ='$pid'";
		mysql_query($sql,$dbc) or die(mysql_error());
		
		$msg="Record updated";
	 
	}	



if(isset($_REQUEST['pid'])){
	
	$pid = mysql_escape_string($_REQUEST['pid']);
	
	$sql = "SELECT * FROM inv_customer WHERE id='$pid'";
	$result = mysql_query($sql) or die(mysql_error());

	$info = mysql_fetch_array($result);
		$id=$info['id'];
		$name=$info['name'];
		$company=$info['company'];
		$address=$info['address'];
		$job_position=$info['job_position'];
		$phone=$info['phone'];
		$email=$info['email'];
		$website=$info['website'];
		$date_created=$info['date_created'];
		$status=$info['status'];
		$type=$info['type'];
	
}	
?>


        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="header">
							<h4 class="title">
								Edit Customer
							</h4>
                               <a href="customer.php?pg=2">
								Back to View
							   </a>	
                            </div>
                            
<div class="content">		

							<?php
								if(isset($msg)){
									print "<font color='blue'>".$msg."</font>";
									
								}
							?>					
<form method="POST" action="customer_edit.php">							
								
                                
                                   

                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Name</label>
                                                <input type="text" class="form-control border-input" name="name" value="<?php print $name; ?>">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Company</label>
                                                <input type="text" class="form-control border-input" name="company" value="<?php print $company; ?>">
                                            </div>
                                        </div>
                                    </div>
									
									
									<div class="row">
                                        <div class="col-md-6">
											<div class="form-group">
                                                <label>Email</label>
                                                <input type="text" class="form-control border-input" name="email" value="<?php print $email; ?>">
                                            </div>                                           
                                        </div>
                                        <div class="col-md-6">
											 <div class="form-group">
                                                <label>Phone</label>
                                                <input type="text" class="form-control border-input" name="phone" value="<?php print $phone; ?>">
                                            </div>
                                            
                                        </div>
                                    </div>

                                    <div class="row">
										<div class="col-md-6">
                                            <div class="form-group">
                                                <label>Job Position</label>
                                                <input type="text" class="form-control border-input" name="position" value="<?php print $job_position; ?>">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Website</label>
                                                <input type="text" class="form-control border-input" name="web" value="<?php print $website; ?>">
                                            </div>
                                        </div>
										
                                    </div>
									
									
                                  
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Address</label>
                                                <textarea rows="5" class="form-control border-input" name="address"><?php print $address; ?></textarea>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="text-center">
										<input type="hidden" name="pg" value="2">
										<input type="hidden" name="post" value="1">
										<input type="hidden" name="pid" value="<?php print $pid; ?>">
												
										<button type="submit" class="btn btn-info btn-fill btn-wd">Update</button>
										
                                    </div>
                                    <div class="clearfix"></div>
</div>                                </form>
									
                        </div>
                    </div>



                </div>
            </div>
        </div>

        <?php include('footer.php') ?>


    </div>
</div>


</body>

    <!--   Core JS Files   -->
    <script src="assets/js/jquery.min.js" type="text/javascript"></script>
	<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>

	<!--  Checkbox, Radio & Switch Plugins -->
	<script src="assets/js/bootstrap-checkbox-radio.js"></script>

	<!--  Charts Plugin -->
	<script src="assets/js/chartist.min.js"></script>

    <!--  Notifications Plugin    -->
    <script src="assets/js/bootstrap-notify.js"></script>

    <!--  Google Maps Plugin    -->
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js"></script>

    <!-- Paper Dashboard Core javascript and methods for Demo purpose -->
	<script src="assets/js/paper-dashboard.js"></script>

	<!-- Paper Dashboard DEMO methods, don't include it in your project! -->
	<script src="assets/js/demo.js"></script>


</html>

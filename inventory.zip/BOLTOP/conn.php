<?php
$dbc = mysql_connect ('localhost', 'root', '') or die('Failure: ' . mysql_error() );
mysql_select_db('boltop_nov_2019') or die ('Could not select database: ' . mysql_error() );
?>
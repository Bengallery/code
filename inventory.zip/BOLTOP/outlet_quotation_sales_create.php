<?php
include('header.php');


if(isset($_REQUEST['wid'])){
	$stores = mysql_escape_string($_REQUEST['wid']);

	$sql = "SELECT * FROM inv_outlets WHERE id = '$stores'";
	$result = mysql_query($sql) or die(mysql_error());
	$info = mysql_fetch_array($result);
		$sid=$info['id'];
		$outlet_name=$info['outlet_name'];
}
?>


        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="header">
							<h4 class="title">
								New Sales
							</h4>
                               
										<a href="outlet_product_new.php?wid=<?php print $sid; ?>&pg=6">
										<button class="btn btn-success btn-fill btn-wd">Go Back</button>
										</a>
										
                            </div>
                            
<div class="content">		

							<?php
								if(isset($msg)){
									print "<font color='blue'>".$msg."</font>";
									
								}
							?>					
<form method="POST" action="outlet_quotation_sales_create_order_line.php">							
									<div class="text-left">
										<input type="hidden" name="pg" value="6">
										<input type="hidden" name="post" value="1">
										<input type="hidden" name="wid" value="<?php print $sid; ?>">
												
										<button type="submit" class="btn btn-info btn-fill btn-wd">Save / Add Item</button>
                                    </div>								
                                
                                   

                                    <div class="row">
									
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Customer</label>
                                                <select name="customer" class="form-control border-input">
												<option></option>
												<?php
												
												$query1  = "SELECT * FROM inv_customer WHERE status <> 'D' AND type='C' ORDER BY id ASC";
												$result1 = mysql_query($query1) or die(mysql_error());
												while($info1 = mysql_fetch_array($result1))
												{
														 $cus_id=$info1['id'];
														 $cus_name=$info1['name'];
														
																print "<option value='$cus_id'>$cus_name</option>";
																
														
												}
												?>
													
												</select>    
                                            </div>
                                        </div>
										
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Reference/Description</label>
                                                <input type="text" class="form-control border-input" name="ref_desc">
                                            </div>  
                                        </div>
                                    </div>
									
									
									<div class="row">
                                        <div class="col-md-6">
											   <div class="form-group">
                                                <label>Outlet/Shop</label>
                                                <input type="text" class="form-control border-input" name="" value="<?php print $outlet_name; ?>" readonly="readonly">
												<input type="hidden" name="outlet" value="<?php print $sid; ?>">
                                            </div>                                       
                                        </div>
                               </div>
							   
							   
							   
							   
							   
							  <?php
							  $cur_day = date('d');
							  $cur_month = date('m');
							  $cur_year = date('Y');
							  ?>
							  
							 <div class="row">  
							    <div class="col-md-1">
							   <label>Day:</label>
							   </div>
							   
							   <div class="col-md-2">							  
							    <select name="day" class="form-control border-input">
									<?php 
									
									for($d=1;$d<=32;$d++){
										if($d == $cur_day){
											print "<option selected=\"selected\">$d</option>";
										}else{
											print "<option>$d</option>";
										}

									}
									?>
								</select>
							   </div>
							   
							   
							   
							    <div class="col-md-1">
							   <label>Month:</label>
							   </div>
							   <div class="col-md-2">							  
							    <select name="month" class="form-control border-input">
									<?php 
									
									for($m=1;$m<=12;$m++){
										//print "<option>$m</option>";
										if($m == $cur_month){
											print("<option selected=\"selected\">".date('M',strtotime('01.'.$m.'.2001'))."</option>");
										}else{
											print("<option>".date('M',strtotime('01.'.$m.'.2001'))."</option>");
										}
									}
									?>
								</select>
							   </div>
							   
							   
							   
							   
							   <div class="col-md-1">
							   <label>Year:</label>
							   </div>	
							   
							   <div class="col-md-2">
							    <select name="year" class="form-control border-input">
									<?php 
									$curr_year = date('Y');
									for($y=2018;$y<=$curr_year;$y++){
										if($y==$cur_year){
											print "<option selected=\"selected\">$y</option>";
										}else{
											print "<option>$y</option>";
										}
									}
									?>
									
								</select>
							   </div>
							   
							  
							   
							   
							   
							   
							   
							   
							   
							   
							   
                                    </div>
									
									
									

                                    
                                  
                                    <div class="clearfix"></div>
</div>                                </form>


									
                        </div>
                    </div>



                </div>
            </div>
        </div>

        <?php include('footer.php') ?>


    </div>
</div>


</body>

    <!--   Core JS Files   -->
    <script src="assets/js/jquery.min.js" type="text/javascript"></script>
	<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>

	<!--  Checkbox, Radio & Switch Plugins -->
	<script src="assets/js/bootstrap-checkbox-radio.js"></script>

	<!--  Charts Plugin -->
	<script src="assets/js/chartist.min.js"></script>

    <!--  Notifications Plugin    -->
    <script src="assets/js/bootstrap-notify.js"></script>

    <!--  Google Maps Plugin    -->
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js"></script>

    <!-- Paper Dashboard Core javascript and methods for Demo purpose -->
	<script src="assets/js/paper-dashboard.js"></script>

	<!-- Paper Dashboard DEMO methods, don't include it in your project! -->
	<script src="assets/js/demo.js"></script>


</html>

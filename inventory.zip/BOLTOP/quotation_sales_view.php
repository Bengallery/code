<?php
include('header.php');

if(isset($_REQUEST['qt'])){

$qt = mysql_escape_string($_REQUEST['qt']);
$sql = "SELECT * FROM inv_quotation WHERE id='$qt'";
$result = mysql_query($sql) or die(mysql_error());


$info = mysql_fetch_array($result);
	$id=$info['id'];
	$customer_id=$info['customer_id'];
	$date_order=$info['date_order'];
	$reference=$info['reference'];
	$warehouse_id=$info['warehouse_id'];
	$salesperson_id=$info['salesperson_id'];
	$total=$info['total'];
	$status=$info['status'];
	
	$quotation_id='QUOT'.$id;
}
?>


        <div class="content">
		
<?php
if(isset($_REQUEST['msg'])){
	print "<font color='blue'>".$_REQUEST['msg']."</font>";
}
?>	
		
		
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
						
								
                            <div class="header">
										<div class="text-left">
										<input type="hidden" name="pg" value="3">
										<input type="hidden" name="post" value="1">
										<!--		
										<button type="submit" class="btn btn-info btn-fill btn-wd">Send by Email</button>
										<button type="submit" class="btn btn-danger btn-fill btn-wd">Confirm Sale</button>
										-->
										<a href="quotation_sales.php?pg=3">
										<button class="btn btn-info btn-fill btn-wd">Go Back</button>
										</a>
										
										<a href="quotation_cancel.php?pg=3&pid=<?php print $qt; ?>"><button class="btn btn-danger btn-fill btn-wd">Cancel Quotation</button></a>										
										
										<a href="print_quotation_sales_view.php?pg=3&qt=<?php print $qt; ?>">
										<button class="btn btn-success btn-fill btn-wd">Print / Mail</button>
										</a>
                                    </div>
									
								
							<h3 class="title">
								<b><?php print $quotation_id; ?></b>
							</h3>
                               
                            </div>
                            
<div class="content">		

										
<form method="POST" action="quotation_sales_create_order_line.php">							
									
                                   

                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Customer</label>
                                                
												<?php
												
												$query1  = "SELECT * FROM inv_customer WHERE status <> 'D' AND id = '$customer_id'";
												$result1 = mysql_query($query1) or die(mysql_error());
												$info1 = mysql_fetch_array($result1);
														 $cus_id=$info1['id'];
														 $cus_name=$info1['name'];
												
												?>
												
												<?php print $cus_name;?>	  
                                          
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Reference/Description</label>
                                                <?php
														 print $reference;
												?>
                                            </div>  
                                        </div>
                                    </div>
									
									
									
									<div class="row">
                                        <div class="col-md-6">
											   <div class="form-group">
                                                <label>Warehouse</label>
                                               
												<?php
												
												$query1  = "SELECT * FROM inv_warehouse WHERE status <> 'D' AND id='$warehouse_id'";
												$result1 = mysql_query($query1) or die(mysql_error());
												$info1 = mysql_fetch_array($result1);
														 $warehouse_id=$info1['id'];
														 $warehouse_name=$info1['warehouse_name'];
														 print $warehouse_name;
																
																
												
												?>
                                            </div>                                       
                                        </div>
                                        <div class="col-md-6">
											<div class="form-group">
                                                <label>Date</label>
												 <?php print $date_order; ?>
                                            </div> 
                                        </div>
                                    </div>
									
									
									

                                    
                                  
                                    <div class="clearfix"></div>
</div>                                </form>


									
                        </div>
                    </div>
					
					
					<div class="card">
					
					
                           
                            <div class="content table-responsive table-full-width">
							
					<p align="center">
						<a href="quotation_sales_create_order_line.php?pg=3&qt=<?php print $qt; ?>"><button class="btn btn-info btn-fill btn-wd">Add Another Item</button></a>
					</p>
							
							
                                <table class="table table-striped">
                                    <thead>
										<th>Product</th>
                                        <th>Description</th>
										<th>Quantity</th>
										<th>Unit Price</th>
										<th>Taxes</th>
										<th>Discount (%)</th>
										<th>Subtotal</th>
										<th>Delete</th>
										<th>Edit</th>
                                    </thead>
									
									
                                    <tbody>
									
									
<?php
/*
$rowsPerPage = 10;

// by default we show first page
$pageNum = 1;

// if $_GET['page'] defined, use it as page number
if(isset($_GET['page']))
{
	$pageNum = $_GET['page'];
}

// counting the offset
$offset = ($pageNum - 1) * $rowsPerPage;
*/

$sql = "SELECT * FROM inv_order_line WHERE order_id='$id' ";
$pagingQuery = "ORDER BY id DESC";

$result = mysql_query($sql . $pagingQuery) or die(mysql_error());


while($info = mysql_fetch_array($result)){ 
	$id=$info['id'];
	$product_id=$info['product_id'];
	$quantity=$info['quantity'];
	$unit_price=$info['unit_price'];
	$tax=$info['tax'];
	$discount=$info['discount'];
	$description=$info['description'];
	$input_by=$info['input_by'];
	$order_id=$info['order_id'];
	$date_time=$info['date_time'];
	
	$sub_total = $quantity*$unit_price;
	
	
	//Calculating the discount
	$discount_ ='0.'.$discount;
	$see_discount =  $sub_total * $discount_;	
	$sub_total_minus_discount=$sub_total - $see_discount;
	
	
	
		//Get product name
		$query1  = "SELECT * FROM  inv_product WHERE id='$product_id' ORDER BY id DESC";
		$result1 = mysql_query($query1) or die(mysql_error());
		
		$info1 = mysql_fetch_array($result1);
			$product_id=$info1['id'];
			$product_name=$info1['product_name'];	
			
			
			$main_total=$main_total+$sub_total_minus_discount;
			$taxes_total=$main_total-$tax;
			
			$sub_total_minus_discount=$sub_total_minus_discount-$tax;
		
	
	print "
	<tr>
                                        	<td>$product_name</td>
											<td>$description</td>
											<td>$quantity</td>
                                        	<td>$unit_price</td>
											<td>$tax</td>
											<td>$discount</td>
											<td>$sub_total_minus_discount</td>
											<td><a href=\"quotation_cancel.php?oid=$id&qt=$qt&pg=3\">Delete</a></td>
											<td><a href=\"quotation_sales_create_order_line.php?pg=3&quotation_id=$qt&oid=$id\">Edit</a></td>
											
    </tr>
	";
	
}

print '

										<tr>
                                        	<td></td>
											<td></td>
											<td></td>                                        	
											<td align="right" colspan="3">
											Untaxed Amount: 
											<br/>
											Taxes:
											</td>
											<td><b>'.$main_total.'<br/>'.$taxes_total.'</b>
											
											</td>
											<td></td> 
											<td></td> 
											
										</tr>

      
                                    </tbody>
                                </table>
';


?>										
                                        
                                  

                            </div>
                        </div>



                </div>
            </div>
        </div>

        <?php include('footer.php') ?>


    </div>
</div>


</body>

    <!--   Core JS Files   -->
    <script src="assets/js/jquery.min.js" type="text/javascript"></script>
	<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>

	<!--  Checkbox, Radio & Switch Plugins -->
	<script src="assets/js/bootstrap-checkbox-radio.js"></script>

	<!--  Charts Plugin -->
	<script src="assets/js/chartist.min.js"></script>

    <!--  Notifications Plugin    -->
    <script src="assets/js/bootstrap-notify.js"></script>

    <!--  Google Maps Plugin    -->
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js"></script>

    <!-- Paper Dashboard Core javascript and methods for Demo purpose -->
	<script src="assets/js/paper-dashboard.js"></script>

	<!-- Paper Dashboard DEMO methods, don't include it in your project! -->
	<script src="assets/js/demo.js"></script>


</html>

<?php
	session_start();
	if (!$_SESSION['id']){
		header("Location:index.php?msg=Please login");	
		exit;
	}
	
include("conn.php");


if(isset($_REQUEST['pid'])){
	
	$pid = mysql_escape_string($_REQUEST['pid']);
	
	
	$del  = "DELETE FROM inv_product WHERE id='$pid'";
	mysql_query($del, $dbc) or die(mysql_error());	

	header("Location:product.php?pg=5&msg=Record Deleted");	
}
	
								
?>
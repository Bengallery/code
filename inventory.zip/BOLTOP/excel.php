<?php
// Connection 
include("conn.php");

$filename = "Webinfopen.xls"; // File Name
// Download file
header("Content-Disposition: attachment; filename=\"$filename\"");
header("Content-Type: application/vnd.ms-excel");

$user_query = mysql_query('SELECT * FROM inv_product');
// Write data to file



$flag = false;
while($info = mysql_fetch_array($user_query)){ 
	
	$product_name=$info['product_name'];
	$product_type=$info['product_type'];
	$sale_price=$info['sale_price'];
	
	if (!$flag) {		
		echo 'Product Name';
		echo "\t".'Product Type';
		echo "\t".'Product Price' . "\r\n";
		 $flag = true;
    }

	echo $product_name;
	echo "\t".$product_type;
	echo "\t".$sale_price. "\r\n";
}

?>
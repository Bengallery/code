<?php
	session_start();
	if (!$_SESSION['id']){
		header("Location:index.php?msg=Please login");	
		exit;
	}
	
include("conn.php");
?>
<table width="100%">
<tr>
	<td>
	<img src="img/company_logo.png" width="80">
	</td>
	<td>
	<br/>
	<h1>Boltop Enterprises Limited</h1>
	5 Alade Shonubi Street
	<br/>
	Off Agboyin, Aguda, Surulere, Lagos, Nigeria
	</td>

	<?php
	function curPageName() {
 return substr($_SERVER["SCRIPT_NAME"],strrpos($_SERVER["SCRIPT_NAME"],"/")+1);
}

$current_page_mail = 'mail_'.curPageName();
$current_page = curPageName();

if($current_page=='print_quotation_sales_view_outlets.php'){
	$back = "<a href=\"outlet_quotation_sales_view.php?pg=$_REQUEST[pg]&qt=$_REQUEST[qt]\">Go Back</a>";
}elseif($current_page=='print_quotation_sales_view.php'){
	$back = "<a href=\"quotation_sales_view.php?pg=$_REQUEST[pg]&qt=$_REQUEST[qt]\">Go Back</a>";
}
//$new_str1 = strstr(curPageName(),"_");
//$new_str2 = ltrim($new_str1, '_');
//print $new_str2;

	?>
	<td align="right">
		<?php print $back; ?>
		[<a href="javascript:window.print();">Print</a>]
		<!--[<a href="<?php print $current_page_mail; ?>?pg=<?php print $_REQUEST['pg']; ?>&qt=<?php print $_REQUEST['qt']; ?>">E-Mail</a>]-->
	</td>
<tr>
</table>
<hr/>

<?php
if(isset($_REQUEST['msg'])){
	print '<p align="center">'.$_REQUEST['msg'].'</p>';
}

?>

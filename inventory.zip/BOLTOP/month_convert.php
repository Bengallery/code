<?php
										if($m==1){
											$month_word = 'Jan';
										}elseif($m==2){
											$month_word = 'Feb';
										}elseif($m==3){
											$month_word = 'Mar';
										}elseif($m==4){
											$month_word = 'Apr';
										}elseif($m==5){
											$month_word = 'May';
										}elseif($m==6){
											$month_word = 'Jun';
										}elseif($m==7){
											$month_word = 'Jul';
										}elseif($m==8){
											$month_word = 'Aug';
										}elseif($m==9){
											$month_word = 'Sep';
										}elseif($m==10){
											$month_word = 'Oct';
										}elseif($m==11){
											$month_word = 'Nov';
										}elseif($m==12){
											$month_word = 'Dec';
										}
	
?>
<?php

										if($sel_month=='Jan'){
											$last_month = 'Dec';
										}elseif($sel_month=='Feb'){
											$last_month = 'Jan';
										}elseif($sel_month=='Mar'){
											$last_month = 'Feb';
										}elseif($sel_month=='Apr'){
											$last_month = 'Mar';
										}elseif($sel_month=='May'){
											$last_month = 'Apr';
										}elseif($sel_month=='Jun'){
											$last_month = 'May';
										}elseif($sel_month=='Jul'){
											$last_month = 'Jun';
										}elseif($sel_month=='Aug'){
											$last_month = 'Jul';
										}elseif($sel_month=='Sep'){
											$last_month = 'Aug';
										}elseif($sel_month=='Oct'){
											$last_month = 'Sep';
										}elseif($sel_month=='Nov'){
											$last_month = 'Oct';
										}elseif($sel_month=='Dec'){
											$last_month = 'Nov';
											
										}
	
?>
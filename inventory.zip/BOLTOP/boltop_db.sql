-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 13, 2019 at 07:42 AM
-- Server version: 5.6.20
-- PHP Version: 5.5.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `boltop_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `inv_customer`
--

CREATE TABLE IF NOT EXISTS `inv_customer` (
`id` int(10) NOT NULL,
  `name` varchar(255) NOT NULL,
  `company` varchar(255) NOT NULL,
  `address` text NOT NULL,
  `job_position` varchar(255) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `email` varchar(255) NOT NULL,
  `website` varchar(255) NOT NULL,
  `date_created` varchar(50) NOT NULL,
  `status` varchar(20) NOT NULL,
  `created_by` varchar(10) NOT NULL,
  `type` varchar(5) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `inv_customer`
--

INSERT INTO `inv_customer` (`id`, `name`, `company`, `address`, `job_position`, `phone`, `email`, `website`, `date_created`, `status`, `created_by`, `type`) VALUES
(1, 'Friday Olamide', 'Ola Stores', '', 'CEO', '08037490533', 'benjamin.onuorah@gmail.com', '', '2019-01-31 13:24:12', 'A', '1', 'C'),
(2, 'Daniel Kayode', 'DK Wears Ltd.', '34 Olarotimi street, Lagos, Island', 'MD', '09099999888', 'daniel@gmail.com', '', '2019-01-31 13:25:30', 'A', '1', 'C'),
(3, 'Ebele Blessing', 'Ebby Stores Lagos', '12 Address here', 'MD/CEO', '0803749053311', 'ebby12@ymail.com', 'www.ebbystore.com', '2019-03-12 21:32:11', 'A', '1', 'C'),
(5, 'Jackel Inernational Limited', '', '', '', '', '', '', '2019-03-11 11:04:37', 'A', '1', 'S'),
(6, 'UK Company', '', '', '', '', '', '', '2019-03-11 21:26:04', 'A', '1', 'S');

-- --------------------------------------------------------

--
-- Table structure for table `inv_order_line`
--

CREATE TABLE IF NOT EXISTS `inv_order_line` (
`id` int(10) NOT NULL,
  `product_id` varchar(10) NOT NULL,
  `quantity` varchar(20) NOT NULL,
  `unit_price` varchar(20) NOT NULL,
  `discount` varchar(20) NOT NULL,
  `tax` varchar(10) NOT NULL,
  `description` text NOT NULL,
  `input_by` varchar(10) NOT NULL,
  `order_id` varchar(10) NOT NULL,
  `date_time` varchar(20) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `inv_order_line`
--

INSERT INTO `inv_order_line` (`id`, `product_id`, `quantity`, `unit_price`, `discount`, `tax`, `description`, `input_by`, `order_id`, `date_time`) VALUES
(1, '2', '2', '30000', '', '', '', '1', '2', '2019-03-13 07:11:36'),
(2, '1', '1', '28000', '', '', '', '1', '2', '2019-03-13 07:12:07'),
(4, '2', '1', '30', '', '', '', '1', '8', '2019-03-13 07:26:27'),
(5, '3', '4', '30', '', '', '', '1', '8', '2019-03-13 07:26:35');

-- --------------------------------------------------------

--
-- Table structure for table `inv_product`
--

CREATE TABLE IF NOT EXISTS `inv_product` (
`id` int(10) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `product_type` varchar(200) NOT NULL,
  `sale_price` varchar(50) NOT NULL,
  `ean13_barcode` varchar(50) NOT NULL,
  `int_ref` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `date_created` varchar(50) NOT NULL,
  `status` varchar(10) NOT NULL,
  `created` varchar(10) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `inv_product`
--

INSERT INTO `inv_product` (`id`, `product_name`, `product_type`, `sale_price`, `ean13_barcode`, `int_ref`, `description`, `date_created`, `status`, `created`) VALUES
(1, '3 IN 1 BODYSUIT 1200', 'Stockable Product', '1,200.00', '', '', '', '2019-01-31 19:34:25', 'A', '1'),
(2, 'BABY SHOES', 'Consumable', '20000', '3334445', 'none', '2 Pairs of baby shows', '2019-02-02 14:43:44', 'A', '1'),
(3, 'KIKI BABY BAG', 'Consumable', '150000', '5555655', 'none', 'KIKI BABY BAG from UK', '2019-02-02 14:44:32', 'A', '1'),
(4, 'SHEEPY TOYS 1', 'Stockable Product', '60000', '0888332', 'int ref', 'description here', '2019-03-12 20:59:45', 'A', '1');

-- --------------------------------------------------------

--
-- Table structure for table `inv_purchase`
--

CREATE TABLE IF NOT EXISTS `inv_purchase` (
`id` int(10) NOT NULL,
  `order_date` varchar(20) NOT NULL,
  `supplier_id` varchar(10) NOT NULL,
  `deliver_to` varchar(10) NOT NULL,
  `post_by` varchar(10) NOT NULL,
  `date_posted` varchar(20) NOT NULL,
  `status` varchar(10) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `inv_purchase`
--

INSERT INTO `inv_purchase` (`id`, `order_date`, `supplier_id`, `deliver_to`, `post_by`, `date_posted`, `status`) VALUES
(1, '12-Mar-2019', '5', '1', '1', '2019-03-12 22:48:37', 'A');

-- --------------------------------------------------------

--
-- Table structure for table `inv_purchase_line`
--

CREATE TABLE IF NOT EXISTS `inv_purchase_line` (
`id` int(10) NOT NULL,
  `product_id` varchar(10) NOT NULL,
  `quantity` varchar(20) NOT NULL,
  `unit_price` varchar(20) NOT NULL,
  `discount` varchar(20) NOT NULL,
  `tax` varchar(10) NOT NULL,
  `description` text NOT NULL,
  `input_by` varchar(10) NOT NULL,
  `order_id` varchar(10) NOT NULL,
  `date_time` varchar(20) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `inv_purchase_line`
--

INSERT INTO `inv_purchase_line` (`id`, `product_id`, `quantity`, `unit_price`, `discount`, `tax`, `description`, `input_by`, `order_id`, `date_time`) VALUES
(1, '1', '4', '400', '', '', '', '1', '1', '2019-03-12 22:48:50'),
(2, '2', '6', '30000', '', '', '', '1', '1', '2019-03-12 22:49:07');

-- --------------------------------------------------------

--
-- Table structure for table `inv_quotation`
--

CREATE TABLE IF NOT EXISTS `inv_quotation` (
`id` int(10) NOT NULL,
  `customer_id` varchar(10) NOT NULL,
  `date_order` varchar(100) NOT NULL,
  `reference` varchar(255) NOT NULL,
  `warehouse_id` varchar(10) NOT NULL,
  `salesperson_id` varchar(10) NOT NULL,
  `process_step` varchar(20) NOT NULL,
  `status` varchar(100) NOT NULL,
  `date_created` varchar(20) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `inv_quotation`
--

INSERT INTO `inv_quotation` (`id`, `customer_id`, `date_order`, `reference`, `warehouse_id`, `salesperson_id`, `process_step`, `status`, `date_created`) VALUES
(2, '2', '13-Mar-2019', '33344', '1', '1', '1', '', '2019-03-13 07:09:34'),
(8, '2', '13-Mar-2019', '33344', '1', '1', '1', '', '2019-03-13 07:26:13');

-- --------------------------------------------------------

--
-- Table structure for table `inv_stock`
--

CREATE TABLE IF NOT EXISTS `inv_stock` (
`id` int(10) NOT NULL,
  `product` varchar(10) NOT NULL,
  `day` varchar(10) NOT NULL,
  `month` varchar(10) NOT NULL,
  `year` varchar(10) NOT NULL,
  `supply_by` varchar(50) NOT NULL,
  `warehouse` varchar(10) NOT NULL,
  `x_day` varchar(10) NOT NULL,
  `x_month` varchar(10) NOT NULL,
  `x_year` varchar(50) NOT NULL,
  `quantity` varchar(20) NOT NULL,
  `adjustment` varchar(10) NOT NULL,
  `description` text NOT NULL,
  `after_adjustment` varchar(20) NOT NULL,
  `stock_on_hand` varchar(20) NOT NULL,
  `posted_by` varchar(10) NOT NULL,
  `date_posted` varchar(20) NOT NULL,
  `status` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `inv_supplier`
--

CREATE TABLE IF NOT EXISTS `inv_supplier` (
  `supply_product_id` int(15) NOT NULL,
  `supplier_name` varchar(255) NOT NULL DEFAULT '',
  `date_post` date DEFAULT NULL,
  `address` text,
  `phone` varchar(150) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `com_id` varchar(30) NOT NULL
) ENGINE=MyISAM  DEFAULT CHARSET=latin1;

--
-- Dumping data for table `inv_supplier`
--

INSERT INTO `inv_supplier` (`supply_product_id`, `supplier_name`, `date_post`, `address`, `phone`, `email`, `com_id`) VALUES
(1, 'UK Supplier', '2007-04-26', '', '', '', '1'),
(2, 'Nigeria Supplier', '2007-04-26', '', '', '', '1');

-- --------------------------------------------------------

--
-- Table structure for table `inv_user`
--

CREATE TABLE IF NOT EXISTS `inv_user` (
`id` int(10) NOT NULL,
  `surname` varchar(255) NOT NULL,
  `other_names` varchar(255) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `password` varchar(200) NOT NULL,
  `email` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `about` text NOT NULL,
  `user_type` varchar(50) NOT NULL,
  `date_reg` varchar(10) NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `inv_user`
--

INSERT INTO `inv_user` (`id`, `surname`, `other_names`, `phone`, `password`, `email`, `address`, `about`, `user_type`, `date_reg`, `status`) VALUES
(1, 'Onuorah', 'Benjamin', '08037490533', 'admin', 'boltop', '', '', 'admin', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `inv_warehouse`
--

CREATE TABLE IF NOT EXISTS `inv_warehouse` (
`id` int(10) NOT NULL,
  `warehouse_name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `status` varchar(10) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `inv_warehouse`
--

INSERT INTO `inv_warehouse` (`id`, `warehouse_name`, `description`, `status`) VALUES
(1, 'BOLTOP HEAD OFFICE', '', 'A'),
(2, 'MOSALASI OUTLET 1', '', 'A'),
(3, 'MOSALASI OUTLET 2', '', 'A'),
(4, 'OROYINYIN OUTLET 3', '', 'A');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `inv_customer`
--
ALTER TABLE `inv_customer`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `inv_order_line`
--
ALTER TABLE `inv_order_line`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `inv_product`
--
ALTER TABLE `inv_product`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `inv_purchase`
--
ALTER TABLE `inv_purchase`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `inv_purchase_line`
--
ALTER TABLE `inv_purchase_line`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `inv_quotation`
--
ALTER TABLE `inv_quotation`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `inv_stock`
--
ALTER TABLE `inv_stock`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `inv_supplier`
--
ALTER TABLE `inv_supplier`
 ADD PRIMARY KEY (`supply_product_id`);

--
-- Indexes for table `inv_user`
--
ALTER TABLE `inv_user`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `inv_warehouse`
--
ALTER TABLE `inv_warehouse`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `inv_customer`
--
ALTER TABLE `inv_customer`
MODIFY `id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `inv_order_line`
--
ALTER TABLE `inv_order_line`
MODIFY `id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `inv_product`
--
ALTER TABLE `inv_product`
MODIFY `id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `inv_purchase`
--
ALTER TABLE `inv_purchase`
MODIFY `id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `inv_purchase_line`
--
ALTER TABLE `inv_purchase_line`
MODIFY `id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `inv_quotation`
--
ALTER TABLE `inv_quotation`
MODIFY `id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `inv_stock`
--
ALTER TABLE `inv_stock`
MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `inv_supplier`
--
ALTER TABLE `inv_supplier`
AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `inv_user`
--
ALTER TABLE `inv_user`
MODIFY `id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `inv_warehouse`
--
ALTER TABLE `inv_warehouse`
MODIFY `id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

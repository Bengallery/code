<?php

include("conn.php");


							$query8  = "SELECT * FROM inv_transfer";		
							$result8 = mysql_query($query8) or die(mysql_error());
							
							while($info8 = mysql_fetch_array($result8)){
								$date=$info8['created_date'];
								$tran_id=$info8['id'];
								
									
									$sql = "UPDATE inv_transfer_create SET date='$date', expected_date='$date' WHERE transfer_id='$tran_id'";
									mysql_query($sql) or die(mysql_error());
						
							}
							
							
							print "Done";
						
						
						
?>
<?php
include('header.php');


if(isset($_REQUEST['wid'])){
	$wid = mysql_escape_string($_REQUEST['wid']);

	$sql = "SELECT * FROM  inv_warehouse WHERE id = '$wid'";
	$result = mysql_query($sql) or die(mysql_error());
	$info = mysql_fetch_array($result);
		$id=$info['id'];
		$warehouse_name=$info['warehouse_name'];
		$description=$info['description'];
}
	
?>


        <div class="content">
		
<?php
if(isset($_REQUEST['msg'])){
	print "<font color='blue'>".$_REQUEST['msg']."</font>";
}
?>			
		
		
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="header">
							
							<h4 class="title">
								Transfer/<?php print $warehouse_name; ?>
							</h4>
							
							<a href="warehouse.php?pg=12">Back to View</a><br/><br/> 
							
                               <a href="warehouse_view_transfer.php?pg=12&wid=<?php print $id; ?>">
								<button class="btn btn-info btn-fill btn-wd">Create</button>
							   </a>	
							   
							   
							   
                            </div>
                            <div class="content table-responsive table-full-width">
							
					


 

 


							
							
                                <table class="table table-striped">
                                    <thead>
										<th>Id</th>
                                        <th>Destination Location </th>
										<th>Creation Date </th>
										<th>Source Document</th>
										<th>Invoice Control </th>	
										<th></th>
										<th></th>
                                    </thead>
									
									
                                    <tbody>
									
									
<?php
$rowsPerPage = 50;

// by default we show first page
$pageNum = 1;

// if $_GET['page'] defined, use it as page number
if(isset($_GET['page']))
{
	$pageNum = $_GET['page'];
}

// counting the offset
$offset = ($pageNum - 1) * $rowsPerPage;


$sql = "SELECT * FROM  inv_transfer ";
$pagingQuery = "ORDER BY id DESC LIMIT $offset, $rowsPerPage";

$result = mysql_query($sql . $pagingQuery) or die(mysql_error());


while($info = mysql_fetch_array($result)){ 
	$id=$info['id'];
	$warehouse=$info['warehouse'];
	$destination=$info['destination'];
	$parner=$info['parner'];
	$created_date=$info['created_date'];
	$source_doc=$info['source_doc'];	
	$back_order=$info['back_order'];
	$invoice=$info['invoice'];
	$status=$info['status'];
	
	
	//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

			$sql_ = "SELECT * FROM  inv_transfer_create WHERE transfer_id = '$id'";
			$result_ = mysql_query($sql_) or die(mysql_error());
			$info_ = mysql_fetch_array($result_);
			$destination_location=$info_['destination_location'];

				//Get Location
				$query1  = "SELECT * FROM  inv_outlets WHERE id='$destination_location' ORDER BY id DESC";
				$result1 = mysql_query($query1) or die(mysql_error());
				$info1 = mysql_fetch_array($result1);
					$outlet_name=$info1['outlet_name'];	
	//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
			
	
	print "
	<tr>
                                        	<td><a href=\"warehouse_view_detail.php?qt=$id&wid=$wid&pg=12\">$id</a></td>
											<td><a href=\"warehouse_view_detail.php?qt=$id&wid=$wid&pg=12\">$outlet_name</a></td>
										
                                        	<td>$created_date</td>
											<td>$source_doc</td>
											<td>$invoice</td>
											<td></td>
											<td></td>
											
    </tr>
	";
	
}

print '
      
                                    </tbody>
                                </table>
';


// how many rows we have in database
$result  = mysql_query($sql) or die('Error, query failed');
$numrows = mysql_num_rows($result);

// how many pages we have when using paging?
$maxPage = ceil($numrows/$rowsPerPage);

$self = $_SERVER['PHP_SELF'];

// creating 'previous' and 'next' link
// plus 'first page' and 'last page' link

// print 'previous' link only if we're not
// on page one
if ($pageNum > 1)
{
	$page = $pageNum - 1;
	$prev = " <a href=\"$self?page=$page&id=$_GET[id]\">[Prev]</a> ";

	$first = " <a href=\"$self?page=1&id=$_GET[id]\">[First Page]</a> ";
}
else
{
	$prev  = ' [Prev] ';       // we're on page one, don't enable 'previous' link
	$first = ' [First Page] '; // nor 'first page' link
}

// print 'next' link only if we're not
// on the last page
if ($pageNum < $maxPage)
{
	$page = $pageNum + 1;
	$next = " <a href=\"$self?page=$page&id=$_GET[id]\">[Next]</a> ";

	$last = " <a href=\"$self?page=$maxPage&id =$_GET[id]\">[Last Page]</a> ";
}
else
{
	$next = ' [Next] ';      // we're on the last page, don't enable 'next' link
	$last = ' [Last Page] '; // nor 'last page' link
}

// print the page navigation link
echo $first . $prev . " Showing page <strong>$pageNum</strong> of <strong>$maxPage</strong> pages " . $next . $last;

if ($maxPage == 0) {
print "<p>no record found</p>";
}
?>										
                                        
                                  

                            </div>
                        </div>
                    </div>



                </div>
            </div>
        </div>

        <?php include('footer.php') ?>


    </div>
</div>


</body>

    <!--   Core JS Files   -->
    <script src="assets/js/jquery.min.js" type="text/javascript"></script>
	<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>

	<!--  Checkbox, Radio & Switch Plugins -->
	<script src="assets/js/bootstrap-checkbox-radio.js"></script>

	<!--  Charts Plugin -->
	<script src="assets/js/chartist.min.js"></script>

    <!--  Notifications Plugin    -->
    <script src="assets/js/bootstrap-notify.js"></script>

    <!--  Google Maps Plugin    -->
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js"></script>

    <!-- Paper Dashboard Core javascript and methods for Demo purpose -->
	<script src="assets/js/paper-dashboard.js"></script>

	<!-- Paper Dashboard DEMO methods, don't include it in your project! -->
	<script src="assets/js/demo.js"></script>


</html>

<?php
include('print_header.php');

if(isset($_REQUEST['wid'])){
	$stores = mysql_escape_string($_REQUEST['wid']);

	$sql = "SELECT * FROM inv_outlets WHERE id = '$stores'";
	$result = mysql_query($sql) or die(mysql_error());
	$info = mysql_fetch_array($result);
		$sid=$info['id'];
		$outlet_name=$info['outlet_name'];
}
?>


        <div class="content">
		

		
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        
					
					
					<div class="card">
					
					
                           
                            <div class="content table-responsive table-full-width">
							
				
<?php
print "<h3>$outlet_name</h3>";
?>							
							
                                <table class="table table-striped" width="100%" border="0" cellpadding="4" cellspacing="4">
                                    <thead>
										<td><b>Id</b></td>
										<td><b>Product</b></td>
										<td><b>Price</b></td>										
										<td><b>B/F</b></td>
										<td><b>Supply</b></td>
										<td><b>Sales</b></td>										
										<td><b>Out of Stock</b></td>
										
										<td><b>Balance</b></td>
										<td><b>Physical Stock</b></td>
										<td><b>Variance</b></td>
                                    </thead>
									
									
                                    <tbody>
									
									
<?php
$rowsPerPage = 1000;

// by default we show first page
$pageNum = 1;

// if $_GET['page'] defined, use it as page number
if(isset($_GET['page']))
{
	$pageNum = $_GET['page'];
}

// counting the offset
$offset = ($pageNum - 1) * $rowsPerPage;


$sql = "SELECT * FROM inv_product ";
$pagingQuery = "ORDER BY product_name ASC LIMIT $offset, $rowsPerPage";

$result = mysql_query($sql . $pagingQuery) or die(mysql_error());


while($info = mysql_fetch_array($result)){ 
	$id=$info['id'];
	$product_name=$info['product_name'];
	$product_type=$info['product_type'];
	$sale_price=$info['sale_price'];
	$ean13_barcode=$info['ean13_barcode'];
	$int_ref=$info['int_ref'];
	$description=$info['description'];
	
		//Get total purchase (Stock in)
		$query2  = "SELECT SUM(quantity) AS total_stock_in, transfer_id FROM inv_transfer_create WHERE product='$id' AND destination_location='$sid'";
		$result2 = mysql_query($query2) or die(mysql_error());
		$info2 = mysql_fetch_array($result2);
		$total_stock_in=$info2['total_stock_in'];
		$transfer_id=$info2['transfer_id'];
		
		
		
			if(!$total_stock_in){
				$total_stock_in=0;
			}
			
		//Get total Sales (Stock out)
		/*
		$query5  = "SELECT * FROM  inv_quotation_outlet WHERE outlet_id ='$sid'";
		$result5 = mysql_query($query5) or die(mysql_error());
			$info5 = mysql_fetch_array($result5);
				$q_id=$info5['id'];
		*/
		
		$query3  = "SELECT SUM(quantity) AS total_stock_out FROM  inv_order_line_outlet WHERE product_id='$id' AND outlet_id='$sid'";
		$result3 = mysql_query($query3) or die(mysql_error());
		$info3 = mysql_fetch_array($result3);
		$total_stock_out=$info3['total_stock_out'];
		
			if(!$total_stock_out){
				$total_stock_out=0;
			}
		
			
			
			
			
	
if(($total_stock_in!='0')||($total_stock_out!='0')){
	
	//Out of Stock
	$query5  = "SELECT quantity FROM inv_outlet_extra_entry_adjustment WHERE entry_type='1' AND outlet_id='$sid' AND product_id='$id' ORDER BY id DESC";
	$result5 = mysql_query($query5) or die(mysql_error());
	$info5 = mysql_fetch_array($result5);
	$quantity_out_of_stock=$info5['quantity'];
	if(isset($quantity_out_of_stock)){
		$oos = "$quantity_out_of_stock";
	}else{
		$oos = "0";
	}
	

	
	//Physical Stock
	$query6  = "SELECT quantity FROM inv_outlet_extra_entry_adjustment WHERE entry_type='2' AND outlet_id='$sid' AND product_id='$id' ORDER BY id DESC";
	$result6 = mysql_query($query6) or die(mysql_error());
	$info6 = mysql_fetch_array($result6);
	$quantity_physical_stock=$info6['quantity'];
	
	if(isset($quantity_physical_stock)){
		$ps = "$quantity_physical_stock";
	}else{
		$ps = "0";
	}
	
	//Balance = [BF]+[Supply]-[Sale]-[Out of Stock]
	//$stock_balance = ($total_stock_in - ($total_stock_out-$quantity_out_of_stock));
	
	//((([BF]+[Supply])+[Out of Stock])-[Sale])
	$stock_balance = (($total_stock_in - $quantity_out_of_stock) - $total_stock_out);
			
			
	//Varient = [Balance]-[Physical Stock]	
	$variant = ($stock_balance-$quantity_physical_stock);
	
			
	print "
	<tr>
											<td>$id</td>
                                        	<td>$product_name</td>
											<td>$sale_price</td>
                                        	
											";
											
											
											$query4  = "SELECT source_doc FROM inv_transfer WHERE id ='$transfer_id'";
											$result4 = mysql_query($query4) or die(mysql_error());
												$info4 = mysql_fetch_array($result4);
													$source_doc=$info4['source_doc'];
											
		
											if($source_doc=="B/F"){
												print "
													<td><font color='blue'>$total_stock_in</font></td>
													<td><font color='blue'>-</font></td>
												";
												
											}else{
												print "
													<td><font color='blue'>-</font></td>
													<td><font color='blue'>$total_stock_in</font></td>													
												";
											}
											print "
											
											<td><font color='red'>$total_stock_out</font></td>
											<td>$oos</td>
											<td><font color='green'><b>$stock_balance</b></font></td>
											<td>$ps</td>
											<td><b>$variant</b></td>
											<td></td>
    </tr>
	";
}
	
}

print '
      
                                    </tbody>
                                </table>
';


// how many rows we have in database
$result  = mysql_query($sql) or die('Error, query failed');
$numrows = mysql_num_rows($result);

// how many pages we have when using paging?
$maxPage = ceil($numrows/$rowsPerPage);

$self = $_SERVER['PHP_SELF'];

// creating 'previous' and 'next' link
// plus 'first page' and 'last page' link

// print 'previous' link only if we're not
// on page one
if ($pageNum > 1)
{
	$page = $pageNum - 1;
	$prev = " <a href=\"$self?page=$page&id=$_GET[id]\">[Prev]</a> ";

	$first = " <a href=\"$self?page=1&id=$_GET[id]\">[First Page]</a> ";
}
else
{
	$prev  = ' [Prev] ';       // we're on page one, don't enable 'previous' link
	$first = ' [First Page] '; // nor 'first page' link
}

// print 'next' link only if we're not
// on the last page
if ($pageNum < $maxPage)
{
	$page = $pageNum + 1;
	$next = " <a href=\"$self?page=$page&id=$_GET[id]\">[Next]</a> ";

	$last = " <a href=\"$self?page=$maxPage&id =$_GET[id]\">[Last Page]</a> ";
}
else
{
	$next = ' [Next] ';      // we're on the last page, don't enable 'next' link
	$last = ' [Last Page] '; // nor 'last page' link
}

// print the page navigation link
echo $first . $prev . " Showing page <strong>$pageNum</strong> of <strong>$maxPage</strong> pages " . $next . $last;

if ($maxPage == 0) {
print "<p>no record found</p>";
}
?>												
                                        
                                  

                            </div>
                        </div>



                </div>
            </div>
        </div>

        <?php include('print_footer.php') ?>


    </div>
</div>


</body>

    <!--   Core JS Files   -->
    <script src="assets/js/jquery.min.js" type="text/javascript"></script>
	<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>

	<!--  Checkbox, Radio & Switch Plugins -->
	<script src="assets/js/bootstrap-checkbox-radio.js"></script>

	<!--  Charts Plugin -->
	<script src="assets/js/chartist.min.js"></script>

    <!--  Notifications Plugin    -->
    <script src="assets/js/bootstrap-notify.js"></script>

    <!--  Google Maps Plugin    -->
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js"></script>

    <!-- Paper Dashboard Core javascript and methods for Demo purpose -->
	<script src="assets/js/paper-dashboard.js"></script>

	<!-- Paper Dashboard DEMO methods, don't include it in your project! -->
	<script src="assets/js/demo.js"></script>


</html>

<?php
	session_start();
	if (!$_SESSION['id']){
		header("Location:index.php?msg=Please login");	
		exit;
	}
	
include("conn.php");

if(isset($_REQUEST['pid'])){
	//print 'test';
	$pid = mysql_escape_string($_REQUEST['pid']);
	$wid = mysql_escape_string($_REQUEST['wid']);
	
	
	
	
	
	//Delete Orderline
	$sql = "SELECT * FROM  inv_transfer_create WHERE transfer_id='$pid' ORDER BY id DESC";
	$result = mysql_query($sql, $dbc) or die(mysql_error());
	while($info = mysql_fetch_array($result)){ 
		$id=$info['id'];
		
			//Delete order line, user the order_id
			$del  = "DELETE FROM inv_transfer_create WHERE id='$id'";
			mysql_query($del, $dbc) or die(mysql_error());	
	}

	//Delete Quotaion
	$del  = "DELETE FROM inv_transfer WHERE id='$pid'";
	mysql_query($del, $dbc) or die(mysql_error());	

	header("Location:warehouse_view.php?msg=Record deleted&wid=$wid&pg=12");	
}

if(isset($_REQUEST['oid'])){
	
	$oid = mysql_escape_string($_REQUEST['oid']);
	$qt = mysql_escape_string($_REQUEST['qt']);
	
	//Delete Quotaion
	$del  = "DELETE FROM inv_transfer_create WHERE id='$oid'";
	mysql_query($del, $dbc) or die(mysql_error());	

	
	///warehouse_view_detail.php?qt=3&wid=1&pg=12
	header("Location:warehouse_view_detail.php?msg=Record deleted&qt=$qt&wid=$oid&pg=12");	
}

?>
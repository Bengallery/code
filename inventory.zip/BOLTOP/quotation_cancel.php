<?php
	session_start();
	if (!$_SESSION['id']){
		header("Location:index.php?msg=Please login");	
		exit;
	}
	
include("conn.php");

if(isset($_REQUEST['pid'])){
	
	$pid = mysql_escape_string($_REQUEST['pid']);
	
	
	
	//Delete Orderline
	$sql = "SELECT * FROM inv_order_line WHERE order_id='$pid' ORDER BY id DESC";
	$result = mysql_query($sql, $dbc) or die(mysql_error());
	while($info = mysql_fetch_array($result)){ 
		$id=$info['id'];
		$product_id=$info['product_id'];
		$quantity=$info['quantity'];
		
			//Delete order line, user the order_id
			$del  = "DELETE FROM inv_order_line WHERE id='$id'";
			mysql_query($del, $dbc) or die(mysql_error());	
	}

	//Delete Quotaion
	$del  = "DELETE FROM inv_quotation WHERE id='$pid'";
	mysql_query($del, $dbc) or die(mysql_error());	

	header("Location:quotation_sales.php?msg=Record deleted&pg=3");	
}

if(isset($_REQUEST['oid'])){
	
	$oid = mysql_escape_string($_REQUEST['oid']);
	$qt = mysql_escape_string($_REQUEST['qt']);
	
	//Delete Quotaion
	$del  = "DELETE FROM inv_order_line WHERE id='$oid'";
	mysql_query($del, $dbc) or die(mysql_error());	

	header("Location:quotation_sales_view.php?msg=Record deleted&qt=$qt&pg=3");	
}

?>
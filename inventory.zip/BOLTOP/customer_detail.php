<?php
include('header.php');

if(isset($_REQUEST['cust_id'])){

$cust_id = mysql_escape_string($_REQUEST['cust_id']);
$sql = "SELECT * FROM inv_customer WHERE id='$cust_id'";
$result = mysql_query($sql) or die(mysql_error());


$info = mysql_fetch_array($result);
	$id=$info['id'];
	$name=$info['name'];
	$company=$info['company'];
	$address=$info['address'];
	$website=$info['website'];
	$job_position=$info['job_position'];
	$phone=$info['phone'];
	$email=$info['email'];
	
	if($company != ""){
		$comp_text = "($company)";
	}
	
	
	//Get total sales (inv_order_line)
	
	$sql1 = "SELECT * FROM inv_quotation WHERE customer_id='$cust_id'";
	$result1 = mysql_query($sql1) or die(mysql_error());
		while($info1 = mysql_fetch_array($result1)){ 
			$order_id=$info1['id'];		
		
			$sql2 = "SELECT * FROM inv_order_line WHERE order_id ='$order_id'";
			$result2 = mysql_query($sql2) or die(mysql_error());
				while($info2 = mysql_fetch_array($result2)){ 	
					$quantity=$info2['quantity'];	
					
						$sum_quantity=$sum_quantity+$quantity;
						
						$sum_unit_price=$sum_unit_price+$unit_price;
						
						$total = $total + ($quantity*$unit_price);
						
						$sum_total = $sum_total+$total;
				
				}
		}
	
}
?>


        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
						
								
                            <div class="header">
										<div class="text-left">
                                    </div>
									
								<a href="customer.php?pg=2">
								Back to View
							   </a>	
							<h3 class="title">
								<b><?php print $quotation_id; ?></b>
							</h3>
                               
                            </div>
                            
<div class="content">		

										
<form method="POST" action="quotation_sales_create_order_line.php">							
								
                                   

                                    <div class="row">
                                        <div class="col-md-2">                                            
                                                <label>Customer</label>
                                         </div> 
										 <div class="col-md-4">
                                            
												<b>												
												<?php print $name.' '.$comp_text;?>	
												</b>
										</div>

										<div class="col-md-2">                                            
                                                <label>Job Position</label>
                                         </div> 
										 <div class="col-md-4">
                                            
												<b>												
												<?php print $job_position;?>	
												</b>
										</div>                                        
                                    </div>
									
									
									
									
									<div class="row">
                                        <div class="col-md-2">                                            
                                                <label>Phone</label>
                                         </div> 
										 <div class="col-md-4">
                                            
												<b>												
												<?php print $phone;?>	
												</b>
										</div>

										<div class="col-md-2">                                            
                                                <label>Email</label>
                                         </div> 
										 <div class="col-md-4">
                                            
												<b>												
												<?php print $email;?>	
												</b>
										</div>			
                                        
                                    </div>
									
									
									
									<div class="row">
                                        <div class="col-md-2">                                            
                                                <label>Address</label>
                                         </div> 
										 <div class="col-md-4">
                                            
												<b>												
												<?php print $address;?>	
												</b>
										</div>

										<div class="col-md-2">                                            
                                                <label>Website</label>
                                         </div> 
										 <div class="col-md-4">
                                            
												<b>												
												<?php print $website;?>	
												</b>
										</div>			
                                        
                                    </div>
									
									
									
									
									
									
									

                                    
                                  
                                    <div class="clearfix"></div>
                             
</form>

									
                        </div>
                    </div>
					
					
					
					<div class="content">
                           
                            <div class="container-fluid">
								 <div class="row">
									 <div class="col-lg-3 col-sm-6">
											<div class="card">
												<div class="content">
													<a href="#">
													<div class="row">
														<div class="col-xs-4">
															<div class="icon-big icon-warning text-center">
																<i class="ti-shopping-cart-full"></i>
															</div>
														</div>
														<div class="col-xs-8">
															<div class="numbers">
																<p>Sales</p>
																<?php print $sum_quantity; ?>
															</div>
														</div>
													</div>
													</a>
													
												</div>
											</div>
										</div>
										
										
										 <div class="col-lg-3 col-sm-6">
											<div class="card">
												<div class="content">
													<a href="#">
													<div class="row">
														<div class="col-xs-4">
															<div class="icon-big icon-success text-center">
																<i class="ti-shopping-cart-full"></i>
															</div>
														</div>
														<div class="col-xs-8">
															<div class="numbers">
																<p>Cost</p>
																<?php print "=N=".$total; ?>
															</div>
														</div>
													</div>
													</a>
													
												</div>
											</div>
										</div>
										
										
										
										
								 </div>
									
                            </div>
                        </div>




                </div>
            </div>
        </div>

        <?php include('footer.php') ?>


    </div>
</div>


</body>

    <!--   Core JS Files   -->
    <script src="assets/js/jquery.min.js" type="text/javascript"></script>
	<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>

	<!--  Checkbox, Radio & Switch Plugins -->
	<script src="assets/js/bootstrap-checkbox-radio.js"></script>

	<!--  Charts Plugin -->
	<script src="assets/js/chartist.min.js"></script>

    <!--  Notifications Plugin    -->
    <script src="assets/js/bootstrap-notify.js"></script>

    <!--  Google Maps Plugin    -->
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js"></script>

    <!-- Paper Dashboard Core javascript and methods for Demo purpose -->
	<script src="assets/js/paper-dashboard.js"></script>

	<!-- Paper Dashboard DEMO methods, don't include it in your project! -->
	<script src="assets/js/demo.js"></script>


</html>

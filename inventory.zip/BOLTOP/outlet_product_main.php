<?php
include('header.php');


if(isset($_REQUEST['wid'])){
	$stores = mysql_escape_string($_REQUEST['wid']);

	$sql = "SELECT * FROM inv_outlets WHERE id = '$stores'";
	$result = mysql_query($sql) or die(mysql_error());
	$info = mysql_fetch_array($result);
		$sid=$info['id'];
		$outlet_name=$info['outlet_name'];
}

?>


        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="header">
							   <h3>	
							   <?php print $outlet_name; ?>
							   </h3>
							  							   
							   <a href="outlets.php?pg=6">
										<button class="btn btn-info btn-fill btn-wd">Go Back</button>
							   </a>
										
										
							   <a href="outlet_product.php?wid=<?php print $sid; ?>&pg=6">
							   <button type="submit" class="btn btn-danger btn-fill btn-wd">Old Record (Mar 2019)</button>
							   </a>
							   
							   <a href="outlet_product_new.php?wid=<?php print $sid; ?>&pg=6">
							   <button type="submit" class="btn btn-success btn-fill btn-wd">New Record</button>
							   </a>
							   
							 
							   <p>
							   
						<br/><br/>

                            </div>
                        </div>
                    </div>



        </div>

        <?php include('footer.php') ?>


    </div>
</div>


</body>

    <!--   Core JS Files   -->
    <script src="assets/js/jquery.min.js" type="text/javascript"></script>
	<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>

	<!--  Checkbox, Radio & Switch Plugins -->
	<script src="assets/js/bootstrap-checkbox-radio.js"></script>

	<!--  Charts Plugin -->
	<script src="assets/js/chartist.min.js"></script>

    <!--  Notifications Plugin    -->
    <script src="assets/js/bootstrap-notify.js"></script>

    <!--  Google Maps Plugin    -->
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js"></script>

    <!-- Paper Dashboard Core javascript and methods for Demo purpose -->
	<script src="assets/js/paper-dashboard.js"></script>

	<!-- Paper Dashboard DEMO methods, don't include it in your project! -->
	<script src="assets/js/demo.js"></script>


</html>

<?php
include('print_header.php');

if(isset($_REQUEST['qt'])){

$qt = mysql_escape_string($_REQUEST['qt']);
$sql = "SELECT * FROM inv_quotation WHERE id='$qt'";
$result = mysql_query($sql) or die(mysql_error());


$info = mysql_fetch_array($result);
	$id=$info['id'];
	$customer_id=$info['customer_id'];
	$date_order=$info['date_order'];
	$reference=$info['reference'];
	$warehouse_id=$info['warehouse_id'];
	$salesperson_id=$info['salesperson_id'];
	$total=$info['total'];
	$status=$info['status'];
	
	$quotation_id='QUOT'.$id;
}
?>


        <div class="content">
		

		
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
						
								
                           
                            
<div class="content">		




<table width="50%">
<tr>
	<td>
	Quotation Number
	</td>
	
	<td>
		<b><?php print $quotation_id ?></b>
	</td>
<tr>

<tr>
	<td>
	Customer
	</td>
	
	<td>
		
		<?php
												
												$query1  = "SELECT * FROM inv_customer WHERE status <> 'D' AND id = '$customer_id'";
												$result1 = mysql_query($query1) or die(mysql_error());
												$info1 = mysql_fetch_array($result1);
														 $cus_id=$info1['id'];
														 $cus_name=$info1['name'];
												
												?>
												
												<?php print $cus_name;?>	
		
	</td>
<tr>


<tr>
	<td>
	Quotation Date
	</td>
	
	<td>
		<?php print $date_order ?>
	</td>
<tr>

<tr>
	<td>
	Salesperson
	</td>
	
	<td>
		
	
												<?php
												
												$query1  = "SELECT * FROM  inv_user WHERE status <> 'D' AND id = '$salesperson_id'";
												$result1 = mysql_query($query1) or die(mysql_error());
												$info1 = mysql_fetch_array($result1);
														 $cus_id=$info1['id'];
														 $surname=$info1['surname'];
														 $other_names=$info1['other_names'];
												
												?>
												
												<?php print "$surname $other_names" ;?>	
												
		
		
	</td>
<tr>

<tr>


</table>

									
                        </div>
                    </div>
					
					
					<div class="card">
					
					
                           
                            <div class="content table-responsive table-full-width">
							
				
<hr/>							
							
                                <table class="table table-striped" width="100%" border="0" cellpadding="4" cellspacing="4">
                                    <thead>
										<td><b>Product</b></td>
										<td><b>Quantity</b></td>
										<td><b>Unit Price</b></td>
										<td><b>Taxes</b></td>
										<td><b>Discount (%)</b></td>
										<td><b>Subtotal</b></td>
                                    </thead>
									
									
                                    <tbody>
									
									
<?php
/*
$rowsPerPage = 10;

// by default we show first page
$pageNum = 1;

// if $_GET['page'] defined, use it as page number
if(isset($_GET['page']))
{
	$pageNum = $_GET['page'];
}

// counting the offset
$offset = ($pageNum - 1) * $rowsPerPage;
*/

$sql = "SELECT * FROM inv_order_line WHERE order_id='$id' ";
$pagingQuery = "ORDER BY id DESC";

$result = mysql_query($sql . $pagingQuery) or die(mysql_error());


while($info = mysql_fetch_array($result)){ 
	$id=$info['id'];
	$product_id=$info['product_id'];
	$quantity=$info['quantity'];
	$unit_price=$info['unit_price'];
	$tax=$info['tax'];
	$discount=$info['discount'];
	$description=$info['description'];
	$input_by=$info['input_by'];
	$order_id=$info['order_id'];
	$date_time=$info['date_time'];
	
	$sub_total = $quantity*$unit_price;
	
	
	//Calculating the discount
	$discount_ ='0.'.$discount;
	$see_discount =  $sub_total * $discount_;	
	$sub_total_minus_discount=$sub_total - $see_discount;
	
	
	
		//Get product name
		$query1  = "SELECT * FROM  inv_product WHERE id='$product_id' ORDER BY id DESC";
		$result1 = mysql_query($query1) or die(mysql_error());
		
		$info1 = mysql_fetch_array($result1);
			$product_id=$info1['id'];
			$product_name=$info1['product_name'];	
			
			
			$main_total=$main_total+$sub_total_minus_discount;
			$taxes_total=$main_total-$tax;
			
			$sub_total_minus_discount=$sub_total_minus_discount-$tax;
		
	
	print "
	<tr>
                                        	<td>$product_name</td>
											<td>$quantity</td>
                                        	<td>$unit_price</td>
											<td>$tax</td>
											<td>$discount</td>
											<td>$sub_total_minus_discount</td>
    </tr>
	";
	
}

print '

										<tr>
                                        	<td></td>
											<td></td>                                        	
											<td align="right" colspan="3">
											Untaxed Amount: 
											<br/>
											Taxes:
											</td>
											<td><b>'.$main_total.'<br/>'.$taxes_total.'</b>
											
											</td>
											
										</tr>

      
                                    </tbody>
                                </table>
';


?>										
                                        
                                  

                            </div>
                        </div>



                </div>
            </div>
        </div>

        <?php include('print_footer.php') ?>


    </div>
</div>


</body>

    <!--   Core JS Files   -->
    <script src="assets/js/jquery.min.js" type="text/javascript"></script>
	<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>

	<!--  Checkbox, Radio & Switch Plugins -->
	<script src="assets/js/bootstrap-checkbox-radio.js"></script>

	<!--  Charts Plugin -->
	<script src="assets/js/chartist.min.js"></script>

    <!--  Notifications Plugin    -->
    <script src="assets/js/bootstrap-notify.js"></script>

    <!--  Google Maps Plugin    -->
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js"></script>

    <!-- Paper Dashboard Core javascript and methods for Demo purpose -->
	<script src="assets/js/paper-dashboard.js"></script>

	<!-- Paper Dashboard DEMO methods, don't include it in your project! -->
	<script src="assets/js/demo.js"></script>


</html>

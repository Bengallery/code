<?php
include('header.php');

	$product_id = mysql_escape_string($_POST['product']);
	$day = mysql_escape_string($_POST['day']);
	$month = mysql_escape_string($_POST['month']);
	$year = mysql_escape_string($_POST['year']);
	$supply_by = mysql_escape_string($_POST['supply_by']);
	$warehouse = mysql_escape_string($_POST['warehouse']);
	$x_day = mysql_escape_string($_POST['x_day']);
	$x_month = mysql_escape_string($_POST['x_month']);
	$x_year = mysql_escape_string($_POST['x_year']);
	$quantity = mysql_escape_string($_POST['quantity']);
	$adjustment = mysql_escape_string($_POST['adjustment']);
	$description = mysql_escape_string($_POST['description']);
	$exp_not_applicable = mysql_escape_string($_POST['exp_not_applicable']);
	

	//stock after adjustment			
	$after_adjustment = $quantity-$adjustment;
if($_REQUEST['post']=='2'){	
		$sql="INSERT INTO inv_stock values 
		('', '$product_id','$day','$month','$year','$supply_by', '$warehouse', '$x_day',
		'$x_month', '$x_year','$quantity','$adjustment', '$description', '$after_adjustment','$after_adjustment','$_SESSION[id]',now(),'')"; 
		
		mysql_query($sql) or die(mysql_error());
}		
?>


        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="header">
							<h4 class="title">
								Create Stock
							</h4>
                               <a href="stock_create.php?pg=7">
								Go Back
							   </a>	
                            </div>
                            
<div class="content">		

<?php
if($_REQUEST['post']=='1'){
	
	$query1  = "SELECT * FROM inv_product WHERE id = '$product_id'";
	$result1 = mysql_query($query1) or die(mysql_error());
	$info1 = mysql_fetch_array($result1);
	$product_id=$info1['id'];
	$product_name=$info1['product_name'];

	//Supplierier
	$query1  = "SELECT * FROM inv_supplier WHERE supply_product_id = '$supply_by'";
	$result1 = mysql_query($query1) or die(mysql_error());
	$info1 = mysql_fetch_array($result1);
	$supply_product_id=$info1['supply_product_id'];
	$supplier_name=$info1['supplier_name'];
															 
		print "
			<p><strong>DATE SUPPLY:</strong> $day-$month-$year </p>
			<p><strong>PRODUCT NAME:</strong> $product_name </p>
			<p><strong>SUPPLY BY:</strong> $supplier_name</p>
			<p><strong>QUANTITY SUPPLY:</strong> $quantity</p>          
			<p><strong>ADJUSTMENT:</strong> $adjustment</p>		
			";
		
		//if applicable
		if(isset($exp_not_applicable)){
			print "<p><strong>EXPIRY DATE:</strong> not applicable</p>";	
			$x_day='';
			$x_month='';
			$x_year='';
		}else{
			print "<p><strong>EXPIRY DATE:</strong> $x_day-$x_month-$x_year</p>";	
		}
		
		//if applicable
		print "<p><strong>AFTER ADJUSTMENT BALANCE:</strong> ".$after_adjustment."</p>" ;
            
}			

?>							
                                
<form method="POST" action="stock_create2.php">	                                  
				  <input name="product" type="hidden" value="<?php print $product_id; ?>" />
                  <input name="day" type="hidden" value="<?php print  $day; ?>" />
                  <input name="month" type="hidden" value="<?php print  $month; ?>" />                 
                  <input name="year" type="hidden" value="<?php print $year; ?>" />
                  <input name="supply_by" type="hidden" value="<?php print $supply_by;  ?>" />
                  <input name="warehouse" type="hidden" value="<?php print $warehouse; ?>" />
                  
				  <input name="x_day" type="hidden" value="<?php print $x_day; ?>" />
                  <input name="x_month" type="hidden" value="<?php print $x_month; ?>" />
                  <input name="x_year" type="hidden" value="<?php print $x_year; ?>" />
                  <input name="quantity" type="hidden" value="<?php print $quantity; ?>" />
                  <input name="adjustment" type="hidden" value="<?php print $adjustment; ?>" />
                  <input name="description" type="hidden" value="<?php print $description; ?>" />
    
					
                                    <div class="text-center">
										<input type="hidden" name="pg" value="3">
										<input type="hidden" name="post" value="2">
										
										<?php
										if($_REQUEST['post']=='2'){
											print '<b>Posting was successful.</b>';
										}else{										
											print '<button type="submit" class="btn btn-info btn-fill btn-wd">COMPLETE</button>';
										}
                                        ?>
										
										
                                    </div>
                                    <div class="clearfix"></div>
</div>                                </form>
									
                        </div>
                    </div>



                </div>
            </div>
        </div>

        <?php include('footer.php') ?>


    </div>
</div>


</body>

    <!--   Core JS Files   -->
    <script src="assets/js/jquery.min.js" type="text/javascript"></script>
	<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>

	<!--  Checkbox, Radio & Switch Plugins -->
	<script src="assets/js/bootstrap-checkbox-radio.js"></script>

	<!--  Charts Plugin -->
	<script src="assets/js/chartist.min.js"></script>

    <!--  Notifications Plugin    -->
    <script src="assets/js/bootstrap-notify.js"></script>

    <!--  Google Maps Plugin    -->
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js"></script>

    <!-- Paper Dashboard Core javascript and methods for Demo purpose -->
	<script src="assets/js/paper-dashboard.js"></script>

	<!-- Paper Dashboard DEMO methods, don't include it in your project! -->
	<script src="assets/js/demo.js"></script>


</html>

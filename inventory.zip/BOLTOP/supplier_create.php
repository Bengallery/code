<?php
include('header.php');
	if(isset($_REQUEST['post'])){
	  if(isset($_REQUEST['name'])){
		$name = mysql_escape_string($_REQUEST['name']);
		$company = mysql_escape_string($_REQUEST['company']);
		$email = mysql_escape_string($_REQUEST['email']);
		$phone = mysql_escape_string($_REQUEST['phone']);		
		$position = mysql_escape_string($_REQUEST['position']);
		$web = mysql_escape_string($_REQUEST['web']);
		$address = mysql_escape_string($_REQUEST['address']);
		
		$sql="INSERT INTO inv_customer values ('','$name','$company','$address','$position','$phone','$email','$web',now(),'A','$_SESSION[id]','S')"; 
		mysql_query($sql,$dbc) or die(mysql_error());	
		$msg="Record created";
	  }else{
		  $msg="Sorry, please enter value for name field";
	  }
	}								
?>


        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="header">
							<h4 class="title">
								Create Supplier
							</h4>
                               <a href="supplier.php?pg=10">
								Back to View
							   </a>	
                            </div>
                            
<div class="content">		

							<?php
								if(isset($msg)){
									print "<font color='blue'>".$msg."</font>";
									
								}
							?>					
<form method="POST" action="supplier_create.php">							
								
                                
                                   

                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Name</label>
                                                <input type="text" class="form-control border-input" name="name">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Company</label>
                                                <input type="text" class="form-control border-input" name="company">
                                            </div>
                                        </div>
                                    </div>
									
									
									<div class="row">
                                        <div class="col-md-6">
											<div class="form-group">
                                                <label>Email</label>
                                                <input type="text" class="form-control border-input" name="email">
                                            </div>                                           
                                        </div>
                                        <div class="col-md-6">
											 <div class="form-group">
                                                <label>Phone</label>
                                                <input type="text" class="form-control border-input" name="phone">
                                            </div>
                                            
                                        </div>
                                    </div>

                                    <div class="row">
										<div class="col-md-6">
                                            <div class="form-group">
                                                <label>Job Position</label>
                                                <input type="text" class="form-control border-input" name="position">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Website</label>
                                                <input type="text" class="form-control border-input" name="web">
                                            </div>
                                        </div>
										
                                    </div>
									
									
                                  
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Address</label>
                                                <textarea rows="5" class="form-control border-input" name="address"></textarea>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="text-center">
										<input type="hidden" name="pg" value="10">
										<input type="hidden" name="post" value="1">
												
										<?php
										if(isset($_REQUEST['edit'])){
											print '<button type="submit" class="btn btn-info btn-fill btn-wd">Update</button>';
										}else{
											print '<button type="submit" class="btn btn-info btn-fill btn-wd">Create</button>';
										}
										?>
								
                                        
										
										
                                    </div>
                                    <div class="clearfix"></div>
</div>                                </form>
									
                        </div>
                    </div>



                </div>
            </div>
        </div>

        <?php include('footer.php') ?>


    </div>
</div>


</body>

    <!--   Core JS Files   -->
    <script src="assets/js/jquery.min.js" type="text/javascript"></script>
	<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>

	<!--  Checkbox, Radio & Switch Plugins -->
	<script src="assets/js/bootstrap-checkbox-radio.js"></script>

	<!--  Charts Plugin -->
	<script src="assets/js/chartist.min.js"></script>

    <!--  Notifications Plugin    -->
    <script src="assets/js/bootstrap-notify.js"></script>

    <!--  Google Maps Plugin    -->
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js"></script>

    <!-- Paper Dashboard Core javascript and methods for Demo purpose -->
	<script src="assets/js/paper-dashboard.js"></script>

	<!-- Paper Dashboard DEMO methods, don't include it in your project! -->
	<script src="assets/js/demo.js"></script>


</html>

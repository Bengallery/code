<?php
include('header.php');
?>


        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="header">
							<h4 class="title">
								Request for Quotation
							</h4>
                               <a href="purchase_order.php?pg=11">
								Back to View
							   </a>	
                            </div>
                            
<div class="content">		

							<?php
								if(isset($msg)){
									print "<font color='blue'>".$msg."</font>";
									
								}
							?>					
<form method="POST" action="purchase_create_order_line.php">							
									<div class="text-left">
										<input type="hidden" name="pg" value="11">
										<input type="hidden" name="post" value="1">
												
										<button type="submit" class="btn btn-info btn-fill btn-wd">Save / Add Item</button>
                                    </div>								
                                
                                   

                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Supplier</label>
                                                <select name="supplier" class="form-control border-input">
												<option></option>
												<?php
												
												$query1  = "SELECT * FROM inv_customer WHERE status <> 'D' AND type='S' ORDER BY id ASC";
												$result1 = mysql_query($query1) or die(mysql_error());
												while($info1 = mysql_fetch_array($result1))
												{
														 $cus_id=$info1['id'];
														 $cus_name=$info1['name'];
														
																print "<option value='$cus_id'>$cus_name</option>";
																
														
												}
												?>
													
												</select>    
                                            </div>
                                        </div>                                       
                                    </div>
									
									
									 <div class="row">
                                        <div class="col-md-6">
											<div class="form-group">
                                                <label>Deliver To</label>
												<select name="deliver_to" class="form-control border-input">
												<option></option>
												<?php
												
												$query1  = "SELECT * FROM inv_warehouse WHERE status <> 'D' ORDER BY id ASC";
												$result1 = mysql_query($query1) or die(mysql_error());
												while($info1 = mysql_fetch_array($result1))
												{
														 $warehouse_id=$info1['id'];
														 $warehouse_name=$info1['warehouse_name'];
														
																print "<option value='$warehouse_id'>$warehouse_name</option>";
																
														
												}
												?>
													
												</select> 
                                            </div> 
                                        </div>
									</div>
										
									
									<div class="row">
										 <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Order Date</label>
                                                <input id="order_date" name="order_date" size="8" class="datepicker" value="<?php print date('d-M-Y')?>" />
                                            </div>  
                                        </div>
									</div>	
										
                                    </div>
									
                                    
                                  
                                    <div class="clearfix"></div>
</div>                                </form>


									
                        </div>
                    </div>



                </div>
            </div>
        </div>

        <?php include('footer.php') ?>


    </div>
</div>


</body>

    <!--   Core JS Files   -->
    <script src="assets/js/jquery.min.js" type="text/javascript"></script>
	<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>

	<!--  Checkbox, Radio & Switch Plugins -->
	<script src="assets/js/bootstrap-checkbox-radio.js"></script>

	<!--  Charts Plugin -->
	<script src="assets/js/chartist.min.js"></script>

    <!--  Notifications Plugin    -->
    <script src="assets/js/bootstrap-notify.js"></script>

    <!--  Google Maps Plugin    -->
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js"></script>

    <!-- Paper Dashboard Core javascript and methods for Demo purpose -->
	<script src="assets/js/paper-dashboard.js"></script>

	<!-- Paper Dashboard DEMO methods, don't include it in your project! -->
	<script src="assets/js/demo.js"></script>


</html>

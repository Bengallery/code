<?php
	session_start();
	if (!$_SESSION['id']){
		header("Location:index.php?msg=Please login");	
		exit;
	}
	
include("conn.php");
?>
<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<link rel="apple-touch-icon" sizes="76x76" href="assets/img/apple-icon.png">
	<link rel="icon" type="image/png" sizes="96x96" href="assets/img/favicon.png">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

	<title>BOLTOP Inventory System</title>

	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />


	<link rel="stylesheet" type="text/css" href="datepicker.css" /> 
	<script type="text/javascript" src="datepicker.js"></script>


    <!-- Bootstrap core CSS     -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" />

    <!-- Animation library for notifications   -->
    <link href="assets/css/animate.min.css" rel="stylesheet"/>

    <!--  Paper Dashboard core CSS    -->
    <link href="assets/css/paper-dashboard.css" rel="stylesheet"/>


    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="assets/css/demo.css" rel="stylesheet" />


    <!--  Fonts and icons     -->
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <link href='https://fonts.googleapis.com/css?family=Muli:400,300' rel='stylesheet' type='text/css'>
    <link href="assets/css/themify-icons.css" rel="stylesheet">

	
	<link rel="stylesheet" href="select2.min.css" />
</head>
<body>

<div class="wrapper">
    <div class="sidebar" data-background-color="white" data-active-color="danger">

    <!--
		Tip 1: you can change the color of the sidebar's background using: data-background-color="white | black"
		Tip 2: you can change the color of the active button using the data-active-color="primary | info | success | warning | danger"
	-->

	
	
    	<div class="sidebar-wrapper">
            <div class="logo">
                <a href="dashboard.php" class="simple-text">
                   <img src="img/company_logo.png" width="100">
                </a>
            </div>

			






            <ul class="nav">
			
<?php
//user_type=1 Senior Supervisor
if($_SESSION['user_type']=='admin'){
?>
                <li <?php if($_REQUEST['pg']=='1') { print 'class="active"'; } ?> >
                    <a href="dashboard.php?pg=1">
                        <i class="ti-home"></i>
                        <p>Dashboard</p>
                    </a>
                </li>
				
				
				<li>
				<a href="#">
                        <p>Sales</p>
                 </a> 
                </li>
				<li <?php if($_REQUEST['pg']=='2') { print 'class="active"'; }?> >
                    <a href="customer.php?pg=2">
                        <i class="ti-user"></i>
                        <p>Customers</p>
                    </a>
                </li>
				
				
				
				<li <?php if($_REQUEST['pg']=='4') { print 'class="active"'; }?> >
                    <a href="quotation_sales.php?pg=4">
                        <i class="ti-shopping-cart-full"></i>
                        <p>Sales Order</p>
                    </a>
                </li>
				
				<li>
				<a href="#">
                        <p>Products</p>
                 </a> 
                </li>
				
				
				<li <?php if($_REQUEST['pg']=='5') { print 'class="active"'; }?> >
                    <a href="product.php?pg=5">
                        <i class="ti-gift"></i>
                        <p>Products</p>
                    </a>
                </li>
				
				
				
				
				<li>
				<a href="#">
                        <p>Purchase </p>
                 </a> 
                </li>
				
                <li <?php if($_REQUEST['pg']=='11') { print 'class="active"'; }?> >
                            <a href="purchase_order.php?pg=11">
								<i class="ti-settings"></i>
								<p>Purchase Orders</p>
                            </a>
                        </li>
				
				<!--
				<li <?php //if($_REQUEST['pg']=='7') { print 'class="active"'; }?> >
                    <a href="stock.php?pg=7">
                        <i class="ti-save"></i>
                        <p>Stock Balance</p>
                    </a>
                </li>
				-->
						
				<li <?php if($_REQUEST['pg']=='10') { print 'class="active"'; }?> >
                    <a href="supplier.php?pg=10">
                        <i class="ti-user"></i>
                        <p>Suppliers</p>
                    </a>
                </li>
				
							
				<li>
				<a href="#">
                        <p>Warehouse</p>
                 </a> 
                </li>
				
                <li <?php if($_REQUEST['pg']=='12') { print 'class="active"'; }?> >
                            <a href="warehouse.php?pg=12">
								<i class="ti-settings"></i>
								<p>Head Office</p>
                            </a>
                        </li>
						
						
				<li <?php if($_REQUEST['pg']=='6') { print 'class="active"'; }?> >
                    <a href="outlets.php?pg=6">
                        <i class="ti-gift"></i>
                        <p>Stores/Outlets</p>
                    </a>
                </li>
				
						
					
				
<?php
}
?>                       
   


 
				
            </ul>
    	</div>
    </div>

    <div class="main-panel">
        <nav class="navbar navbar-default">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar bar1"></span>
                        <span class="icon-bar bar2"></span>
                        <span class="icon-bar bar3"></span>
                    </button>
					
<?php
if((isset($_REQUEST['pg']))&&($_REQUEST['pg']=='1')){
	print '<a class="navbar-brand" href="#">Dashboard</a>';
}elseif((isset($_REQUEST['pg']))&&($_REQUEST['pg']=='2')){
	print '<a class="navbar-brand" href="#">CUSTOMERS</a>';
}elseif((isset($_REQUEST['pg']))&&($_REQUEST['pg']=='3')){
	print '<a class="navbar-brand" href="#">QUOTATIONS</a>';
}elseif((isset($_REQUEST['pg']))&&($_REQUEST['pg']=='4')){
	print '<a class="navbar-brand" href="#">SALES ORDER</a>';
}elseif((isset($_REQUEST['pg']))&&($_REQUEST['pg']=='5')){
	print '<a class="navbar-brand" href="#">CREATE PRODUCTS</a>';
}elseif((isset($_REQUEST['pg']))&&($_REQUEST['pg']=='6')){
	print '<a class="navbar-brand" href="#">STORE/OUTLETS</a>';
}elseif((isset($_REQUEST['pg']))&&($_REQUEST['pg']=='8')){
	print '<a class="navbar-brand" href="#">BY CATEGORY</a>';
}/*elseif((isset($_REQUEST['pg']))&&($_REQUEST['pg']=='7')){
	print '<a class="navbar-brand" href="#">STOCK BALANCE</a>';
}*/elseif((isset($_REQUEST['pg']))&&($_REQUEST['pg']=='10')){
	print '<a class="navbar-brand" href="#">SUPPLIERS</a>';
}elseif((isset($_REQUEST['pg']))&&($_REQUEST['pg']=='11')){
	print '<a class="navbar-brand" href="#">PURCHASE ORDER</a>';
}elseif((isset($_REQUEST['pg']))&&($_REQUEST['pg']=='12')){
	print '<a class="navbar-brand" href="#">WAREHOUSE</a>';
}
?>
                    
					
                </div>
                <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav navbar-right">
                       
						
                        <!--
                         <li class="dropdown">
                              <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                    <i class="ti-bell"></i>
                                    <p class="notification">5</p>
									<p>Notifications</p>
									<b class="caret"></b>
                              </a>
                              <ul class="dropdown-menu">
                                <li><a href="#">Notification 1</a></li>
                                <li><a href="#">Notification 2</a></li>
                                <li><a href="#">Notification 3</a></li>
                                <li><a href="#">Notification 4</a></li>
                                <li><a href="#">Another notification</a></li>
                              </ul>
                        </li>
						-->
                        
                         <li>
                            <a href="logout.php">
                                <i class="ti-power-off"></i>
								<p>Logout</p>
                            </a>
                        </li>
						
						
						<li>
                            <a href="profile.php" class="dropdown-toggle" data-toggle="dropdown">
                                <i class="ti-user"></i>
								<p>
								<?php
									print $_SESSION['surname'].' '.$_SESSION['other_names'];
								?>
								</p>
                            </a>
                        </li>
                       
                       
                    </ul>

                </div>
            </div>
        </nav>
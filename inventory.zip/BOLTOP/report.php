<?php
include('header.php');
?>

	<div class="content">
            <div class="container-fluid">
                <div class="card">
       <div class="content">
                        				
						
						
                        <div class="places-buttons">
                            <div class="row">
                                <div class="col-md-9">
                                    <h5>Reports
                                        <p class="category">Click to access each report
                                    </h5>
                                </div>
                            </div>
                            <div class="row">
							
							
							
							
                                <div class="col-md-3">
                                    <a href="report_presidential.php?pg=5"><button class="btn btn-default btn-block">PRESIDENTIAL</button></a>
                                </div>
                                <div class="col-md-3">
                                    <a href="report_gubernatorial.php?pg=5"><button class="btn btn-default btn-block">GUBERNATORIAL</button></a>
                                </div>
                                <div class="col-md-3">
                                    <a href="report_senate.php?pg=5"><button class="btn btn-default btn-block">SENATOR</button></a>
                                </div>
								
								<div class="col-md-3">
                                    <a href="report_house_of_rep.php?pg=5"><button class="btn btn-default btn-block">HOUSE OF REP.
</button></a>
                                </div>
                           
                                <div class="col-md-3">
                                    <a href="report_house_of_assembly.php?pg=5"><button class="btn btn-default btn-block">HOUSE OF ASSEMBLY</button></a>
                                </div>
								
								

                                
								
                            </div>
							
							
                        </div>
                    </div>
					
					
		 
		 
                </div>
            </div>
        </div>

        <?php include('footer.php') ?>


    </div>
</div>


</body>

    <!--   Core JS Files   -->
    <script src="assets/js/jquery.min.js" type="text/javascript"></script>
	<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>

	<!--  Checkbox, Radio & Switch Plugins -->
	<script src="assets/js/bootstrap-checkbox-radio.js"></script>

	<!--  Charts Plugin -->
	<script src="assets/js/chartist.min.js"></script>

    <!--  Notifications Plugin    -->
    <script src="assets/js/bootstrap-notify.js"></script>

    <!--  Google Maps Plugin    -->
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js"></script>

    <!-- Paper Dashboard Core javascript and methods for Demo purpose -->
	<script src="assets/js/paper-dashboard.js"></script>

	<!-- Paper Dashboard DEMO methods, don't include it in your project! -->
	<script src="assets/js/demo.js"></script>


</html>

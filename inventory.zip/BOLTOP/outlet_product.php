<?php
include('header.php');



if(isset($_REQUEST['wid'])){
	$stores = mysql_escape_string($_REQUEST['wid']);

	$sql = "SELECT * FROM inv_outlets WHERE id = '$stores'";
	$result = mysql_query($sql) or die(mysql_error());
	$info = mysql_fetch_array($result);
		$sid=$info['id'];
		$outlet_name=$info['outlet_name'];
}


$rowsPerPage = 1000;

// by default we show first page
$pageNum = 1;

// if $_GET['page'] defined, use it as page number
if(isset($_GET['page']))
{
	$pageNum = $_GET['page'];
}

// counting the offset
$offset = ($pageNum - 1) * $rowsPerPage;

?>


        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="header">
							   Old Record
							   <h3>	
							   <?php print $outlet_name; ?>
							   </h3>
							  							   
							   <a href="outlets.php?pg=6">
										<button class="btn btn-info btn-fill btn-wd">Go Back</button>
							   </a>
										
								<!--		
							   <a href="outlet_quotation_sales_create.php?wid=<?php print $sid; ?>&pg=6">
							   <button type="submit" class="btn btn-danger btn-fill btn-wd">New Sales</button>
							   </a>
							   -->
							   
							   <a href="outlet_quotation_sales.php?wid=<?php print $sid; ?>&pg=6&t=0">
							   <button type="submit" class="btn btn-success btn-fill btn-wd">Sales Reciepts</button>
							   </a>
							   
							   <a href="print_outlet_product.php?wid=<?php print $sid; ?>&pg=6&t=0">
							   <button type="submit" class="btn btn-info btn-fill btn-wd">Print</button>
							   </a>
							   
							   <!--
							    <a href="excel_outlet_product.php?wid=<?php print $sid; ?>&offset=<?php print $offset; ?>&t=0">
							   <button type="submit" class="btn btn-success btn-fill btn-wd">Download</button>
							   </a>
							    -->
							   
							   <p>
							   
						
							
						
                            <div class="content table-responsive table-full-width">
							
								
										
                                    	
					
							
							
                                <table class="table table-striped">
                                    <thead>
										<th>Id</th>
										<th>Date</th>
										<th>Product</th>
										<th>Price</th>
										
										<th>B/F</th>
										<th>Supply</th>
										
										<th>Sales</th>
										<th>Out of Stock</th>
										
										<th>Balance</th>
										<th>Physical Stock</th>
										<th>Variance</th>
										
                                    </thead>
									
									
                                    <tbody>
									
									
<?php

$sel_month = $_REQUEST['month'];
$sel_year = $_REQUEST['year'];

$sql = "SELECT * FROM inv_product ";
$pagingQuery = "ORDER BY product_name ASC LIMIT $offset, $rowsPerPage";

$result = mysql_query($sql . $pagingQuery) or die(mysql_error());


while($info = mysql_fetch_array($result)){ 
	$id=$info['id'];
	$product_name=$info['product_name'];
	$product_type=$info['product_type'];
	$sale_price=$info['sale_price'];
	$ean13_barcode=$info['ean13_barcode'];
	$int_ref=$info['int_ref'];
	$description=$info['description'];
	
	/*
	$day=$info['day'];
	$month=$info['month'];
	$year=$info['year'];
	
	$phpdate = strtotime( $date_created );
		$format_date = "$day/$month/$year";
	*/

	
		//Get total purchase (Stock in)  YEAR(Date) = 2011 AND MONTH(Date) = 5
		
		//
		
		//$query2  = "SELECT SUM(quantity) AS total_stock_in, transfer_id FROM inv_transfer_create WHERE date LIKE \'%\_'.$sel_month.'\_%\' AND product='$id' AND destination_location='$sid'";
		
		//$query2  = "SELECT SUM(quantity) AS total_stock_in, transfer_id FROM inv_transfer_create WHERE date = '$sel_year' AND MONTH(date) = '$sel_month' AND product='$id' AND destination_location='$sid'";
		
		$query2  = "SELECT SUM(quantity) AS total_stock_in, transfer_id, date FROM inv_transfer_create WHERE product='$id' AND destination_location='$sid' AND date <= '09-May-2019' ";
		
		$result2 = mysql_query($query2) or die(mysql_error());
		$info2 = mysql_fetch_array($result2);
		$total_stock_in=$info2['total_stock_in'];
		$transfer_id=$info2['transfer_id'];
		$date=$info2['date'];
		
		
						list($date_day, $date_month, $date_year) = split('[-.-]', $date);
					
						//if((($date_month=='Mar') || ($date_month=='Apr') || (($date_month=='May') && ($date_day < 8)) &&($date_year=='2019')){
							
							if(!$total_stock_in){
								$total_stock_in=0;
							}
		
						//}
		
			
		
		
		$query3  = "SELECT SUM(quantity) AS total_stock_out FROM  inv_order_line_outlet WHERE product_id='$id' AND outlet_id='$sid' AND month='' AND year='2019'";
		
		$result3 = mysql_query($query3) or die(mysql_error());
		$info3 = mysql_fetch_array($result3);
		$total_stock_out=$info3['total_stock_out'];
		
			if(!$total_stock_out){
				$total_stock_out=0;
			}
		
			
			
			
			
	
if(($total_stock_in!='0')||($total_stock_out!='0')){
	
	//Out of Stock
	$query5  = "SELECT quantity FROM inv_outlet_extra_entry_adjustment WHERE entry_type='1' AND outlet_id='$sid' AND product_id='$id' AND date_year = '' ORDER BY id DESC";
	$result5 = mysql_query($query5) or die(mysql_error());
	$info5 = mysql_fetch_array($result5);
	$quantity_out_of_stock=$info5['quantity'];
	if(isset($quantity_out_of_stock)){
		$oos = "<a href=\"outlet_extra_entries.php?wid=$stores&pg=6&type=1&prod=$id\">$quantity_out_of_stock</a>";
	}else{
		$oos = "<a href=\"outlet_extra_entries.php?wid=$stores&pg=6&type=1&prod=$id\">0</a>";
	}
	

	
	//Physical Stock
	$query6  = "SELECT quantity FROM inv_outlet_extra_entry_adjustment WHERE entry_type='2' AND outlet_id='$sid' AND product_id='$id' AND date_year = '' ORDER BY id DESC";
	$result6 = mysql_query($query6) or die(mysql_error());
	$info6 = mysql_fetch_array($result6);
	$quantity_physical_stock=$info6['quantity'];
	if(isset($quantity_physical_stock)){
		$ps = "<a href=\"outlet_extra_entries.php?wid=$stores&pg=6&type=2&prod=$id\">$quantity_physical_stock</a>";
	}else{
		$ps = "<a href=\"outlet_extra_entries.php?wid=$stores&pg=6&type=2&prod=$id\">0</a>";
	}
	
	//Balance = [BF]+[Supply]-[Sale]-[Out of Stock]
	//$stock_balance = ($total_stock_in - ($total_stock_out-$quantity_out_of_stock));
	
	//((([BF]+[Supply])+[Out of Stock])-[Sale])
	$stock_balance = (($total_stock_in - $quantity_out_of_stock) - $total_stock_out);
			
			
	//Varient = [Balance]-[Physical Stock]	
	$variant = ($stock_balance-$quantity_physical_stock);
	
			
	print "
	<tr>
											<td>$id</td>
											<td>$format_date</td>
                                        	<td>$product_name</td>
											<td>$sale_price</td>
                                        	
											";
											
											
											$query4  = "SELECT source_doc FROM inv_transfer WHERE id ='$transfer_id'";
											$result4 = mysql_query($query4) or die(mysql_error());
												$info4 = mysql_fetch_array($result4);
													$source_doc=$info4['source_doc'];
											
		
											if($source_doc=="B/F"){
												print "
													<td><font color='blue'>$total_stock_in</font></td>
													<td><font color='blue'>-</font></td>
												";
												
											}else{
												print "
													<td><font color='blue'>-</font></td>
													<td><font color='blue'>$total_stock_in</font></td>													
												";
											}
											print "
											<td><font color='red'>$total_stock_out</font></td>
											<td>$oos</td>
											
											<td><font color='green'><b>$stock_balance</b></font></td>
											<td>$ps</td>
											<td><b>$variant</b></td>
											
    </tr>
	";
	
	// ----------------------------------- INSERT RECORD TO BEGIN NEW STOCK ----------------------------------
/*
	//$day
	$month_1 = $month+1;	
	$product_id = $id;
	$store_id = $sid;
	//$year 
	
	
	$sql_new="INSERT INTO inv_outlet_product VALUES ('','$store_id','$day','$month_1','$year','$product_id','$quantity_physical_stock','','','','','',now())"; 
	mysql_query($sql_new,$dbc) or die(mysql_error());	

*/

	
}
	
}

print '
      
                                    </tbody>
                                </table>
';


// how many rows we have in database
$result  = mysql_query($sql) or die('Error, query failed');
$numrows = mysql_num_rows($result);

// how many pages we have when using paging?
$maxPage = ceil($numrows/$rowsPerPage);

$self = $_SERVER['PHP_SELF'];

// creating 'previous' and 'next' link
// plus 'first page' and 'last page' link

// print 'previous' link only if we're not
// on page one
if ($pageNum > 1)
{
	$page = $pageNum - 1;
	$prev = " <a href=\"$self?page=$page&id=$_GET[id]\">[Prev]</a> ";

	$first = " <a href=\"$self?page=1&id=$_GET[id]\">[First Page]</a> ";
}
else
{
	$prev  = ' [Prev] ';       // we're on page one, don't enable 'previous' link
	$first = ' [First Page] '; // nor 'first page' link
}

// print 'next' link only if we're not
// on the last page
if ($pageNum < $maxPage)
{
	$page = $pageNum + 1;
	$next = " <a href=\"$self?page=$page&id=$_GET[id]\">[Next]</a> ";

	$last = " <a href=\"$self?page=$maxPage&id =$_GET[id]\">[Last Page]</a> ";
}
else
{
	$next = ' [Next] ';      // we're on the last page, don't enable 'next' link
	$last = ' [Last Page] '; // nor 'last page' link
}

// print the page navigation link
echo $first . $prev . " Showing page <strong>$pageNum</strong> of <strong>$maxPage</strong> pages " . $next . $last;

if ($maxPage == 0) {
print "<p>no record found</p>";
}
?>										
                                        
                                  

                            </div>
                        </div>
                    </div>



                </div>
            </div>
        </div>

        <?php include('footer.php') ?>


    </div>
</div>


</body>

    <!--   Core JS Files   -->
    <script src="assets/js/jquery.min.js" type="text/javascript"></script>
	<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>

	<!--  Checkbox, Radio & Switch Plugins -->
	<script src="assets/js/bootstrap-checkbox-radio.js"></script>

	<!--  Charts Plugin -->
	<script src="assets/js/chartist.min.js"></script>

    <!--  Notifications Plugin    -->
    <script src="assets/js/bootstrap-notify.js"></script>

    <!--  Google Maps Plugin    -->
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js"></script>

    <!-- Paper Dashboard Core javascript and methods for Demo purpose -->
	<script src="assets/js/paper-dashboard.js"></script>

	<!-- Paper Dashboard DEMO methods, don't include it in your project! -->
	<script src="assets/js/demo.js"></script>


</html>

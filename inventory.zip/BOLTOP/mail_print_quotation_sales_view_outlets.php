<?php
	session_start();
	if (!$_SESSION['id']){
		header("Location:index.php?msg=Please login");	
		exit;
	}
	
include("conn.php");


$qt = mysql_escape_string($_REQUEST['qt']);
$sql = "SELECT * FROM  inv_quotation_outlet WHERE id='$qt'";
$result = mysql_query($sql) or die(mysql_error());


$info = mysql_fetch_array($result);
	$id=$info['id'];
	$customer_id=$info['customer_id'];
	$date_order=$info['date_order'];
	$reference=$info['reference'];
	$outlet_id=$info['outlet_id'];
	$salesperson_id=$info['salesperson_id'];
	$total=$info['total'];
	$status=$info['status'];
	
	//$quotation_id='QUOT'.$id;
	
	
	$sql = "SELECT * FROM inv_outlets WHERE id = '$outlet_id'";
	$result = mysql_query($sql) or die(mysql_error());
	$info = mysql_fetch_array($result);
		$sid=$info['id'];
		$outlet_name=$info['outlet_name'];



$msg_body .= '

<table width="100%">
<tr>
	<td>
	<img src="http://nemsacademy.com/_boltop/img/company_logo.png" width="80">
	</td>
	<td>
	<br/>
	<h1>Boltop Enterprises Limited</h1>
	5 Alade Shonubi Street
	<br/>
	Off Agboyin, Aguda, Surulere, Lagos, Nigeria
	</td>

	<td align="right">
		
	</td>
<tr>
</table>
<hr/>

        <div class="content">
		

		
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
						
								
                           
                            
<div class="content">		




<table width="50%">
<tr>
	<td>
	Outlet Name
	</td>
	
	<td>
		<b>'. $outlet_name .' </b>
	</td>
<tr>

<tr>
	<td>
	Customer
	</td>
	
	<td>
		
';
												
												$query1  = "SELECT * FROM inv_customer WHERE status <> 'D' AND id = '$customer_id'";
												$result1 = mysql_query($query1) or die(mysql_error());
												$info1 = mysql_fetch_array($result1);
														 $cus_id=$info1['id'];
														 $cus_name=$info1['name'];
														 $cus_email=$info1['email'];
												
$msg_body .= $cus_name .'	
		
	</td>
<tr>


<tr>
	<td>
	Quotation Date
	</td>
	
	<td>
		'. $date_order .'
	</td>
<tr>

<tr>
	<td>
	Salesperson
	</td>
	
	<td>
		
';	
												
												
												$query1  = "SELECT * FROM  inv_user WHERE status <> 'D' AND id = '$salesperson_id'";
												$result1 = mysql_query($query1) or die(mysql_error());
												$info1 = mysql_fetch_array($result1);
														 $cus_id=$info1['id'];
														 $surname=$info1['surname'];
														 $other_names=$info1['other_names'];
												
												
												
												 $msg_body .= "$surname $other_names";	
												
		
$msg_body .= '		
	</td>
<tr>

<tr>


</table>

									
                        </div>
                    </div>
					
					
					<div class="card">
					
					
                           
                            <div class="content table-responsive table-full-width">
							
				
<hr/>							
							
                                <table class="table table-striped" width="100%" border="0" cellpadding="4" cellspacing="4">
                                    <thead>
										<td><b>Product</b></td>
										<td><b>Quantity</b></td>
										<td><b>Unit Price</b></td>
										<td><b>Taxes</b></td>
										<td><b>Discount (%)</b></td>
										<td><b>Subtotal</b></td>
                                    </thead>
									
									
                                    <tbody>
									
';
									

$sql = "SELECT * FROM inv_order_line_outlet WHERE order_id='$id' ";
$pagingQuery = "ORDER BY id DESC";

$result = mysql_query($sql . $pagingQuery) or die(mysql_error());


while($info = mysql_fetch_array($result)){ 
	$id=$info['id'];
	$product_id=$info['product_id'];
	$quantity=$info['quantity'];
	$unit_price=$info['unit_price'];
	$tax=$info['tax'];
	$discount=$info['discount'];
	$description=$info['description'];
	$input_by=$info['input_by'];
	$order_id=$info['order_id'];
	$date_time=$info['date_time'];
	
	$sub_total = $quantity*$unit_price;
	
	
	//Calculating the discount
	$discount_ ='0.'.$discount;
	$see_discount =  $sub_total * $discount_;	
	$sub_total_minus_discount=$sub_total - $see_discount;
	
	
	
		//Get product name
		$query1  = "SELECT * FROM  inv_product WHERE id='$product_id' ORDER BY id DESC";
		$result1 = mysql_query($query1) or die(mysql_error());
		
		$info1 = mysql_fetch_array($result1);
			$product_id=$info1['id'];
			$product_name=$info1['product_name'];	
			
			
			$main_total=$main_total+$sub_total_minus_discount;
			$taxes_total=$main_total-$tax;
			
			$sub_total_minus_discount=$sub_total_minus_discount-$tax;
		
	
	$msg_body .= "
	<tr>
                                        	<td>$product_name</td>
											<td>$quantity</td>
                                        	<td>$unit_price</td>
											<td>$tax</td>
											<td>$discount</td>
											<td>$sub_total_minus_discount</td>
    </tr>
	";
	
}

$msg_body .= '

										<tr>
                                        	<td></td>
											<td></td>                                        	
											<td align="right" colspan="3">
											Untaxed Amount: 
											<br/>
											Taxes:
											</td>
											<td><b>'.$main_total.'<br/>'.$taxes_total.'</b>
											
											</td>
											
										</tr>

      
                                    </tbody>
                                </table>
';

$msg_body .= '
<hr/>
Phone: 08020539741 Email: boltop@boltopng.com 
Bank Account: FCMB: 3222357010';

//print $msg_body;	
		
	

	
	if($cus_email == ""){
		header("Location:print_quotation_sales_view_outlets.php?pg=$_REQUEST[pg]&qt=$_REQUEST[qt]&msg=<font color='red'>Sorry this customer does not have email address</font>");
	}else{ 
	
					$to = $cus_email;
					$title =  'Boltop Receipt';
					$from = 'boltop@boltopng.com';					
					$headers = "From: ". $from ."\r\n";
					$headers .= "Reply-To: ". strip_tags($from) . "\r\n";
					$headers .= "MIME-Version: 1.0\r\n";
					$headers .= "Content-type:text/html;charset=UTF-8\r\n";
					mail($to,$title,$msg_body,$headers);
					
					$msg = "<font color='blue'><b>Mail sent to: ".$cus_email."</b></font>";
					header("Location:print_quotation_sales_view.php?pg=$_REQUEST[pg]&qt=$_REQUEST[qt]&msg=$msg");
					
	}
	

?>
<?php
include('header.php');

//Total Customer
$sql = "SELECT * FROM  inv_customer WHERE type='C'";
$result = mysql_query($sql, $dbc) or die(mysql_error());
$total_customer = mysql_num_rows($result);
	
//Total Products
$sql1 = "SELECT * FROM  inv_product";
$result1 = mysql_query($sql1, $dbc) or die(mysql_error());
$total_product = mysql_num_rows($result1);

//$current_month = date('m');
//Total Direct Sales
$query3  = "SELECT * FROM  inv_order_line";
$result3 = mysql_query($query3) or die(mysql_error());

while($info3 = mysql_fetch_array($result3)){ 

		$quantity=$info3['quantity'];
		$unit_price=$info3['unit_price'];
		$date_time=$info3['date_time'];
		
		$total_sales=($quantity*$unit_price);
}	


//Total Purchase
$query4  = "SELECT * FROM  inv_purchase_line";
$result4 = mysql_query($query4) or die(mysql_error());

while($info4 = mysql_fetch_array($result4)){ 

		$quantity4=$info4['quantity'];
		$unit_price4=$info4['unit_price'];
		
		$total_purchase=($quantity4*$unit_price4);
}	

					
/*
//Monthly Sales
//Get total Sales (Stock out)
		$query3  = "SELECT SUM(quantity) AS total_stock_out FROM  inv_order_line WHERE product_id='$id'";
		$result3 = mysql_query($query3) or die(mysql_error());
		$info3 = mysql_fetch_array($result3);
		$total_stock_out=$info3['total_stock_out'];
		
			if(!$total_stock_out){
				$total_stock_out=0;
			}
		
			//Stock Balance	
			//$stock_balance = ($total_stock_in - $total_stock_out);
			
		//Get Transfer (Stock out)
		$query3  = "SELECT SUM(quantity) AS total_stock_out2 FROM  inv_transfer_create WHERE product='$id'";
		$result3 = mysql_query($query3) or die(mysql_error());
		$info3 = mysql_fetch_array($result3);
		$total_stock_out2=$info3['total_stock_out2'];
		
			if(!$total_stock_out2){
				$total_stock_out2=0;
			}
			*/
?>


        <div class="content">
            <div class="container-fluid">
                <div class="row">
				
				
				
				<div class="col-lg-3 col-sm-6">
                        <div class="card">
                            <div class="content">
                                <div class="row">
                                    <div class="col-xs-5">
                                        <div class="icon-big icon-info text-center">
                                            <i class="ti-gift"></i>
                                        </div>
                                    </div>
                                    <div class="col-xs-7">
                                        <div class="numbers">
                                            <p>Products</p>
                                           <?php print $total_product; ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="footer">
                                    <hr />
                                    <div class="stats">
                                        <i class="ti-reload"></i> Total
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
					
					
					 <div class="col-lg-3 col-sm-6">
                        <div class="card">
                            <div class="content">
                                <div class="row">
                                    <div class="col-xs-5">
                                        <div class="icon-big icon-success text-center">
                                            <i class="ti-user"></i>
                                        </div>
                                    </div>
                                    <div class="col-xs-7">
                                        <div class="numbers">
                                            <p>Customers</p>
                                            <?php print number_format($total_customer); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="footer">
                                    <hr />
                                    <div class="stats">
                                        <i class="ti-calendar"></i>Total
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
					
					
                    <div class="col-lg-3 col-sm-6">
                        <div class="card">
                            <div class="content">
                                <div class="row">
                                    <div class="col-xs-3">
                                        <div class="icon-big icon-warning text-center">
                                            <i class="ti-shopping-cart-full"></i>
                                        </div>
                                    </div>
                                    <div class="col-xs-9">
                                        <div class="numbers">
                                            <p>Direct Sales</p>
                                            <?php print number_format($total_sales); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="footer">
                                    <hr />
                                    <div class="stats">
                                        <i class="ti-reload"></i>Total
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                   
                    <div class="col-lg-3 col-sm-6">
                        <div class="card">
                            <div class="content">
                                <div class="row">
                                    <div class="col-xs-3">
                                        <div class="icon-big icon-danger text-center">
                                            <i class="ti-shopping-cart-full"></i>
                                        </div>
                                    </div>
                                    <div class="col-xs-9">
                                        <div class="numbers">
                                            <p>Purchase</p>
                                            <?php print number_format($total_purchase); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="footer">
                                    <hr />
                                    <div class="stats">
                                        <i class="ti-timer"></i>Total
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                </div>
                
				
				
				
				
				
				
				
				
                <div class="row">
                    <div class="col-md-6">
                        <div class="card">
                            <div class="header">
                                <h4 class="title">OUTLETS STOCK</h4>
                                <p class="category">Performance</p>
                            </div>
							
                                    <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
						<!--
                            <div class="header">
                               <a href="stock_create.php?pg=7">
								<button class="btn btn-info btn-fill btn-wd">Create New</button>
							   </a>	
                            </div>
						-->
                            <div class="content table-responsive table-full-width">
							
					
							
							
                                <table class="table table-striped">
                                    <thead>
										<th>Id</th>
										<th>Outlets/Stores</th>
                                    </thead>
									
									
                                    <tbody>
									
									
<?php
$rowsPerPage = 5;

// by default we show first page
$pageNum = 1;

// if $_GET['page'] defined, use it as page number
if(isset($_GET['page']))
{
	$pageNum = $_GET['page'];
}

// counting the offset
$offset = ($pageNum - 1) * $rowsPerPage;


$sql = "SELECT * FROM   inv_outlets ";
$pagingQuery = "LIMIT $offset, $rowsPerPage";

$result = mysql_query($sql . $pagingQuery) or die(mysql_error());


while($info = mysql_fetch_array($result)){ 
	$id=$info['id'];
	$outlet_name=$info['outlet_name'];
	$description=$info['description'];
	
	
	
	print "
	<tr>
											<td>$id</td>
                                        	<td><a href=\"outlet_product_main.php?wid=$id&pg=6\">$outlet_name</a></td>
											
    </tr>
	";
	
}

print '
      
                                    </tbody>
                                </table>
';


?>										
                                        
                                  

                            </div>
                        </div>
                    </div>



                </div>
            </div>
        </div>
							
							
                        </div>
                    </div>
					
					
					
					
					
					<div class="row">
                    <div class="col-md-6">
                        <div class="card">
                            <div class="header">
                                <h4 class="title">SALES ORDER</h4>
                                <p class="category">5 Recent record</p>
								<a href="quotation_sales_create.php?pg=3">
								<button class="btn btn-info btn-fill btn-wd">Create</button>
							   </a>
                            </div>
							
							
							
							
							<div class="content">
		
	
		
		
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                           
                            <div class="content table-responsive table-full-width">
							
					
							
							
                                <table class="table table-striped">
                                    <thead>
										<th>Qutation Number</th>
                                        <th>Date</th>
										<th>Customer</th>
										<th>Sales Person</th>
										<th>Total</th>
										
                                    </thead>
									
									
                                    <tbody>
									
									
<?php
$rowsPerPage = 5;

// by default we show first page
$pageNum = 1;

// if $_GET['page'] defined, use it as page number
if(isset($_GET['page']))
{
	$pageNum = $_GET['page'];
}

// counting the offset
$offset = ($pageNum - 1) * $rowsPerPage;


$sql = "SELECT * FROM inv_quotation ";
$pagingQuery = "ORDER BY id DESC LIMIT $offset, $rowsPerPage";

$result = mysql_query($sql . $pagingQuery) or die(mysql_error());


while($info = mysql_fetch_array($result)){ 
	$id=$info['id'];
	$customer_id=$info['customer_id'];
	$date_order=$info['date_order'];
	$reference=$info['reference'];
	$warehouse_id=$info['warehouse_id'];
	$salesperson_id=$info['salesperson_id'];	
	$status=$info['status'];
	
		//Customer
		$query2  = "SELECT * FROM  inv_customer WHERE id='$customer_id' ORDER BY id DESC";
		$result2 = mysql_query($query2) or die(mysql_error());
		$info2 = mysql_fetch_array($result2);
			$customer_id=$info2['id'];
			$customer_name=$info2['name'];	
			
		//Sales person
		$query1  = "SELECT * FROM  inv_user WHERE id='$salesperson_id' ORDER BY id DESC";
		$result1 = mysql_query($query1) or die(mysql_error());
		$info1 = mysql_fetch_array($result1);
			$user_id=$info1['id'];
			$surname=$info1['surname'];
			$other_names=$info1['other_names'];	


		//Get the total
		
		$sql_sum = "SELECT * FROM inv_order_line WHERE order_id='$id' ";
		$result_sum = mysql_query($sql_sum) or die(mysql_error());
			$total=0;
			
			while($info_sum = mysql_fetch_array($result_sum)){
				$quantity=$info_sum['quantity'];
				$unit_price=$info_sum['unit_price'];
				$tax=$info_sum['tax'];
				$discount=$info_sum['discount'];
		
				$sub_total=$quantity*$unit_price;
				//$total=$total+$sub_total;
				
				//Calculating the discount
				$discount_ ='0.'.$discount;
				$see_discount =  $sub_total * $discount_;	
				$total_minus_discount=$sub_total - $see_discount;
				
				
				//Subtract taxes
				$total_=$total_minus_discount-$tax;
				
				$total=$total+$total_;
				
			}
	
	print "
	<tr>
                                        	<td><a href=\"quotation_sales_view.php?qt=$id&pg=3\">QUOT$id</a></td>
											<td>$date_order</td>
											<td>$customer_name</td>
                                        	<td>$surname $other_names</td>
											<td>$total</td>
											
    </tr>
	";
	
}

print '
      
                                    </tbody>
                                </table>
';



?>										
                                        
                                  

                            </div>
                        </div>
                    </div>



                </div>
            </div>
        </div>
		
		
		
						</div>
                        </div>
                    </div>
							
							
							
                  
                </div>
            </div>
        </div>


        <?php include('footer.php') ?>

    </div>
</div>


</body>

    <!--   Core JS Files   -->
    <script src="assets/js/jquery.min.js" type="text/javascript"></script>
	<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>

	<!--  Checkbox, Radio & Switch Plugins -->
	<script src="assets/js/bootstrap-checkbox-radio.js"></script>

	<!--  Charts Plugin -->
	<script src="assets/js/chartist.min.js"></script>

    <!--  Notifications Plugin    -->
    <script src="assets/js/bootstrap-notify.js"></script>

    <!--  Google Maps Plugin    -->
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js"></script>

    <!-- Paper Dashboard Core javascript and methods for Demo purpose -->
	<script src="assets/js/paper-dashboard.js"></script>

	<!-- Paper Dashboard DEMO methods, don't include it in your project! -->
	<script src="assets/js/demo.js"></script>

	<script type="text/javascript">
    	$(document).ready(function(){

        	demo.initChartist();

        	

    	});
	</script>

</html>

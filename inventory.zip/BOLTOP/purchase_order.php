<?php
include('header.php');
?>


        <div class="content">
		
		
<?php
if(isset($_REQUEST['msg'])){
	print "<font color='blue'>".$_REQUEST['msg']."</font>";
}
?>			
		
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="header">
                               <a href="purchase_order_create.php?pg=11">
								<button class="btn btn-info btn-fill btn-wd">Create</button>
							   </a>	
                            </div>
                            <div class="content table-responsive table-full-width">
							
					
							
							
                                <table class="table table-striped">
                                    <thead>
										<th>Reference</th>
                                        <th>Order Date</th>
										<th>Supplier</th>
										<th>Num of Item(s)</th>
										<th>Total</th>
										<th>Status</th>
										<th></th>
										<th></th>
                                    </thead>
									
									
                                    <tbody>
									
									
<?php
$rowsPerPage = 10;

// by default we show first page
$pageNum = 1;

// if $_GET['page'] defined, use it as page number
if(isset($_GET['page']))
{
	$pageNum = $_GET['page'];
}

// counting the offset
$offset = ($pageNum - 1) * $rowsPerPage;


$sql = "SELECT * FROM inv_purchase ";
$pagingQuery = "ORDER BY id DESC LIMIT $offset, $rowsPerPage";

$result = mysql_query($sql . $pagingQuery) or die(mysql_error());


while($info = mysql_fetch_array($result)){ 
	$id=$info['id'];
	$order_date=$info['order_date'];
	$supplier_id=$info['supplier_id'];
	$deliver_to=$info['deliver_to'];
	$post_by=$info['post_by'];	
	$status=$info['status'];
	
		//Supplier
		$query2  = "SELECT * FROM  inv_customer WHERE id='$supplier_id' AND type='S' ORDER BY id DESC";
		$result2 = mysql_query($query2) or die(mysql_error());
		$info2 = mysql_fetch_array($result2);
			$supplier_id=$info2['id'];
			$supplier_name=$info2['name'];	
			
		

		//Get the total
		
		$sql_sum = "SELECT * FROM inv_purchase_line WHERE order_id='$id' ";
		$result_sum = mysql_query($sql_sum) or die(mysql_error());
			$total=0;
			$count=0;
			
			while($info_sum = mysql_fetch_array($result_sum)){
				$quantity=$info_sum['quantity'];
				$unit_price=$info_sum['unit_price'];
				$tax=$info_sum['tax'];
				$discount=$info_sum['discount'];
		
				$sub_total=$quantity*$unit_price;
				//$total=$total+$sub_total;
				
				//Calculating the discount
				$discount_ ='0.'.$discount;
				$see_discount =  $sub_total * $discount_;	
				$total_minus_discount=$sub_total - $see_discount;
				
				
				//Subtract taxes
				$total_=$total_minus_discount-$tax;
				
				$total=$total+$total_;
				$count++;
				
			}
	
	print "
	<tr>
                                        	<td><a href=\"purchase_view.php?qt=$id&pg=11\">PO$id</a></td>
											<td>$order_date</td>
											<td>$supplier_name</td>
                                        	<td>$count</td>
											<td>$total</td>
											<td>$status</td>
											<td></td>
											<td></td>
											
    </tr>
	";
	
}

print '
      
                                    </tbody>
                                </table>
';


// how many rows we have in database
$result  = mysql_query($sql) or die('Error, query failed');
$numrows = mysql_num_rows($result);

// how many pages we have when using paging?
$maxPage = ceil($numrows/$rowsPerPage);

$self = $_SERVER['PHP_SELF'];

// creating 'previous' and 'next' link
// plus 'first page' and 'last page' link

// print 'previous' link only if we're not
// on page one
if ($pageNum > 1)
{
	$page = $pageNum - 1;
	$prev = " <a href=\"$self?page=$page&id=$_GET[id]\">[Prev]</a> ";

	$first = " <a href=\"$self?page=1&id=$_GET[id]\">[First Page]</a> ";
}
else
{
	$prev  = ' [Prev] ';       // we're on page one, don't enable 'previous' link
	$first = ' [First Page] '; // nor 'first page' link
}

// print 'next' link only if we're not
// on the last page
if ($pageNum < $maxPage)
{
	$page = $pageNum + 1;
	$next = " <a href=\"$self?page=$page&id=$_GET[id]\">[Next]</a> ";

	$last = " <a href=\"$self?page=$maxPage&id =$_GET[id]\">[Last Page]</a> ";
}
else
{
	$next = ' [Next] ';      // we're on the last page, don't enable 'next' link
	$last = ' [Last Page] '; // nor 'last page' link
}

// print the page navigation link
echo $first . $prev . " Showing page <strong>$pageNum</strong> of <strong>$maxPage</strong> pages " . $next . $last;

if ($maxPage == 0) {
print "<p>no record found</p>";
}
?>										
                                        
                                  

                            </div>
                        </div>
                    </div>



                </div>
            </div>
        </div>

        <?php include('footer.php') ?>


    </div>
</div>


</body>

    <!--   Core JS Files   -->
    <script src="assets/js/jquery.min.js" type="text/javascript"></script>
	<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>

	<!--  Checkbox, Radio & Switch Plugins -->
	<script src="assets/js/bootstrap-checkbox-radio.js"></script>

	<!--  Charts Plugin -->
	<script src="assets/js/chartist.min.js"></script>

    <!--  Notifications Plugin    -->
    <script src="assets/js/bootstrap-notify.js"></script>

    <!--  Google Maps Plugin    -->
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js"></script>

    <!-- Paper Dashboard Core javascript and methods for Demo purpose -->
	<script src="assets/js/paper-dashboard.js"></script>

	<!-- Paper Dashboard DEMO methods, don't include it in your project! -->
	<script src="assets/js/demo.js"></script>


</html>

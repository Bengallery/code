<?php
// Connection 
include("conn.php");

if(isset($_REQUEST['wid'])){
	$stores = mysql_escape_string($_REQUEST['wid']);

	$sql = "SELECT * FROM inv_outlets WHERE id = '$stores'";
	$result = mysql_query($sql) or die(mysql_error());
	$info = mysql_fetch_array($result);
		$sid=$info['id'];
		$outlet_name=$info['outlet_name'];
}



$filename = $outlet_name.'_'.date('d-m-Y')."_Download.xls"; // File Name
// Download file
header("Content-Disposition: attachment; filename=\"$filename\"");
header("Content-Type: application/vnd.ms-excel");

//$user_query = mysql_query('SELECT * FROM inv_product');
// Write data to file

$sel_month = $_REQUEST['month'];
$sel_year = $_REQUEST['year'];

$sql = "SELECT * FROM inv_product ORDER BY product_name ASC";

$result = mysql_query($sql) or die(mysql_error());

$counter = 1;
$flag = false;

while($info = mysql_fetch_array($result)){ 
	$id=$info['id'];
	$product_name=$info['product_name'];
	$product_type=$info['product_type'];
	$sale_price=$info['sale_price'];
	$ean13_barcode=$info['ean13_barcode'];
	$int_ref=$info['int_ref'];
	$description=$info['description'];
	$date_created=$info['date_created'];
	
	// Get the pulled data from the NEW Table [inv_outlet_product] (New Record Only)
		$sql2 = "SELECT * FROM inv_outlet_product WHERE product='$id' AND store_id='$sid'";
		$result2 = mysql_query($sql2) or die(mysql_error());
		if (mysql_num_rows($result2) > 0) {
			
		  $data = mysql_fetch_array($result2);
			$o_id=$data['id'];
			$day=$data['day'];
			$month=$data['month'];
			$year=$data['year'];
			$product=$data['product'];
			//$bf=$data['bf'];
			
			$supply=$data['supply'];
			$sales=$data['sales'];
			$out_of_stock=$data['out_of_stock'];
			$balance=$data['balance'];
			$physical_stock=$data['physical_stock'];
		}		
			
			
			//Getting the BF/From the last month physical stock entry
			//Physical Stock
			
			//$query9  = "SELECT quantity FROM inv_outlet_extra_entry_adjustment WHERE entry_type='2' AND outlet_id='$sid' AND product_id='$id'";	


		$arr_month_concern = array('Jan', 'Feb', 'Mar', 'Apr','May');
		if((in_array($sel_month, $arr_month_concern, true))&&($sel_year=='2019')){
			$query9  = "SELECT quantity FROM inv_outlet_extra_entry_adjustment WHERE entry_type='2' AND outlet_id='$sid' AND product_id='$id' AND date_year='' ORDER BY id DESC";
		}else{
			
			include('month_return_last.php');
			$query9  = "SELECT quantity FROM inv_outlet_extra_entry_adjustment WHERE entry_type='2' AND outlet_id='$sid' AND product_id='$id' AND (date_month='$last_month' AND date_year='$sel_year') ORDER BY id DESC";
		}
		
		

		
			$result9 = mysql_query($query9) or die(mysql_error());
				
				//while($info9 = mysql_fetch_array($result9)){
				$info9 = mysql_fetch_array($result9);			
					$retrieved_ps=$info9['quantity'];
					
					if($retrieved_ps > 0){
						$bf = $retrieved_ps;
					}else{
						$bf = 0;
					}
			
			// --------------------------------- Getting data for Supply -------------------------
			
			//$quantity_supply = '0';
			// --------------------------------- Getting data for Supply -------------------------
			
			$query2  = "SELECT * FROM inv_transfer_create WHERE product='$id' AND destination_location='$sid'";		
				$result2 = mysql_query($query2) or die(mysql_error());
				
				$total_supply_for_product =0;
				while($info2 = mysql_fetch_array($result2)){
					    
					
						$quantity_supply=$info2['quantity'];
						$transfer_id=$info2['transfer_id'];
						
						$date=$info2['date'];
						
						
						
						//$date = "04/30/1973";
						list($date_day, $date_month, $date_year) = split('[-.-]', $date);
						
						
						if((strtolower($date_month)==strtolower($sel_month))&&($date_year==$sel_year)){
							$total_supply_for_product = $total_supply_for_product+$quantity_supply;
							
							//$total_supply_for_product = $quantity_supply;
						}/*else{
							$total_supply_for_product = 0;
							
						}*/
						
			
			    }
			//--------------------------------- Getting data for Sales ---------------------------- SUM(quantity) AS total_stock_in
					$sql3 = "SELECT SUM(quantity) AS total_sales_total FROM  inv_order_line_outlet WHERE product_id='$id' AND outlet_id='$sid' AND month='$sel_month' AND year='$sel_year'";
					$result3 = mysql_query($sql3) or die(mysql_error());
						
							  $data3 = mysql_fetch_array($result3);
								$sales=$data3['total_sales_total'];
								if($sales == ""){
									$sale_value = 0;
								}else{
									$sale_value = $sales;
								}
	

			$selected_month = $_REQUEST['month'];
			$selected_year =$_REQUEST['year'];
			
			//Physical Stock
			$query6  = "SELECT quantity FROM inv_outlet_extra_entry_adjustment WHERE entry_type='2' AND outlet_id='$sid' AND product_id='$id' AND date_month = '$selected_month' AND date_year = '$selected_year' ORDER BY id DESC";
			$result6 = mysql_query($query6) or die(mysql_error());
			$info6 = mysql_fetch_array($result6);
			$quantity_physical_stock=$info6['quantity'];
			if(isset($quantity_physical_stock)){
				$ps = $quantity_physical_stock;
			}else{
				$ps = 0;
			}
			
			
			
			//Out of Stock
			$query5  = "SELECT quantity FROM inv_outlet_extra_entry_adjustment WHERE entry_type='1' AND outlet_id='$sid' AND product_id='$id' AND date_month = '$selected_month' AND date_year = '$selected_year' ORDER BY id DESC";
			$result5 = mysql_query($query5) or die(mysql_error());
			$info5 = mysql_fetch_array($result5);
			$quantity_out_of_stock=$info5['quantity'];
			if($quantity_out_of_stock != ""){
				$oos = $quantity_out_of_stock;
			}else{
				$oos = 0;
			}
			
			
			//-------------------- Balance & Varient -------------------------------------
				//Balance
				$stock_balance = (($bf + $total_supply_for_product) - ($sales + $quantity_out_of_stock));	
				//$stock_balance = (($bf + $total_supply_for_product) - ($sales));	
				
				//Varient = [Balance]-[Physical Stock]	
				$variant = ($stock_balance-$quantity_physical_stock);
	
				if (!$flag) {	
					echo '#';
					echo "\t".'Id';
					echo "\t".'Date';
					echo "\t".'Product';
					echo "\t".'Price';
					echo "\t".'B/F';
					echo "\t".'Supply';
					echo "\t".'Sales';
					echo "\t".'Out of Stock';		
					echo "\t".'Balance';
					echo "\t".'Physical Stock';
					echo "\t".'Variance' . "\r\n";
					 $flag = true;
				}	
	
	
				if(($bf != 0)||($total_supply_for_product != 0)||($sale_value != 0)){
					//OUTPUT HERE --------------------------------------------------------------------------------->
					echo $counter;
					echo "\t".$id; 
					echo "\t"."$month-$year"; 
					echo "\t".$product_name; 
					echo "\t".$sale_price; 
					echo "\t".$bf;
					echo "\t".$total_supply_for_product;
					echo "\t".$sale_value;
					echo "\t".$oos;
					echo "\t".$stock_balance;
					echo "\t".$ps;
					echo "\t".$variant. "\r\n";
					
				$counter++;
				}
	
		//  } //end of if --------------- with a BIG problem
	
	
	
}
					
					



//--------------------------------- OLD CODE IS BELOW ----------------------------


/*

while($info = mysql_fetch_array($result)){ 
	
	$id=$info['id'];
	$product_name=$info['product_name'];
	$product_type=$info['product_type'];
	$sale_price=$info['sale_price'];
	$ean13_barcode=$info['ean13_barcode'];
	$int_ref=$info['int_ref'];
	$description=$info['description'];
	
		//Get total purchase (Stock in)
		$query2  = "SELECT SUM(quantity) AS total_stock_in, transfer_id FROM inv_transfer_create WHERE product='$id' AND destination_location='$sid'";
		$result2 = mysql_query($query2) or die(mysql_error());
		$info2 = mysql_fetch_array($result2);
		$total_stock_in=$info2['total_stock_in'];
		$transfer_id=$info2['transfer_id'];
		
		
		
			if(!$total_stock_in){
				$total_stock_in=0;
			}
			
		//Get total Sales (Stock out)
		
		
		$query3  = "SELECT SUM(quantity) AS total_stock_out FROM  inv_order_line_outlet WHERE product_id='$id' AND outlet_id='$sid'";
		$result3 = mysql_query($query3) or die(mysql_error());
		$info3 = mysql_fetch_array($result3);
		$total_stock_out=$info3['total_stock_out'];
		
			if(!$total_stock_out){
				$total_stock_out=0;
			}
		
			
	if (!$flag) {		
		echo 'Product';
		echo "\t".'Price';
		echo "\t".'B/F';
		echo "\t".'Supply';
		echo "\t".'Sales';
		echo "\t".'Out of Stock';		
		echo "\t".'Balance';
		echo "\t".'Physical Stock';
		echo "\t".'Variance' . "\r\n";
		 $flag = true;
    }		
			
			
	
if(($total_stock_in!='0')||($total_stock_out!='0')){
	
		//Out of Stock
	$query5  = "SELECT quantity FROM inv_outlet_extra_entry_adjustment WHERE entry_type='1' AND outlet_id='$sid' AND product_id='$id' ORDER BY id DESC";
	$result5 = mysql_query($query5) or die(mysql_error());
	$info5 = mysql_fetch_array($result5);
	$quantity_out_of_stock=$info5['quantity'];
	if(isset($quantity_out_of_stock)){
		$oos = "$quantity_out_of_stock";
	}else{
		$oos = "0";
	}
	

	
	//Physical Stock
	$query6  = "SELECT quantity FROM inv_outlet_extra_entry_adjustment WHERE entry_type='2' AND outlet_id='$sid' AND product_id='$id' ORDER BY id DESC";
	$result6 = mysql_query($query6) or die(mysql_error());
	$info6 = mysql_fetch_array($result6);
	$quantity_physical_stock=$info6['quantity'];
	
	if(isset($quantity_physical_stock)){
		$ps = "$quantity_physical_stock";
	}else{
		$ps = "0";
	}
	
	//Balance = [BF]+[Supply]-[Sale]-[Out of Stock]
	//$stock_balance = ($total_stock_in - ($total_stock_out-$quantity_out_of_stock));
	
	//((([BF]+[Supply])+[Out of Stock])-[Sale])
	$stock_balance = (($total_stock_in - $quantity_out_of_stock) - $total_stock_out);
			
			
	//Varient = [Balance]-[Physical Stock]	
	$variant = ($stock_balance-$quantity_physical_stock);
	
			
	
                                    echo $product_name;
									echo "\t".$sale_price;                                    	
											
											
											
											$query4  = "SELECT source_doc FROM inv_transfer WHERE id ='$transfer_id'";
											$result4 = mysql_query($query4) or die(mysql_error());
												$info4 = mysql_fetch_array($result4);
													$source_doc=$info4['source_doc'];
											
		
											if($source_doc=="B/F"){
												echo "\t".$total_stock_in;
												echo "\t".'-';
												
												
											}else{
												echo "\t".'-';
												echo "\t".$total_stock_in;
												
											}
											
									
									echo "\t".$total_stock_out;
									echo "\t".$oos;
									echo "\t".$stock_balance;
									echo "\t".$ps;
									echo "\t".$variant. "\r\n";
											
  
	}
	//echo $product_name;
	//echo "\t".$product_type. "\r\n";
}
*/
?>
<?php
	session_start();
	if (!$_SESSION['id']){
		header("Location:index.php?msg=Please login");	
		exit;
	}
	
include("conn.php");

if(isset($_REQUEST['pid'])){
	//print 'test';
	$pid = mysql_escape_string($_REQUEST['pid']);
	
	
	
	//Delete Orderline
	$sql = "SELECT * FROM inv_purchase_line WHERE order_id='$pid' ORDER BY id DESC";
	$result = mysql_query($sql, $dbc) or die(mysql_error());
	while($info = mysql_fetch_array($result)){ 
		$id=$info['id'];
		
			//Delete order line, user the order_id
			$del  = "DELETE FROM inv_purchase_line WHERE id='$id'";
			mysql_query($del, $dbc) or die(mysql_error());	
	}

	//Delete Quotaion
	$del  = "DELETE FROM inv_purchase WHERE id='$pid'";
	mysql_query($del, $dbc) or die(mysql_error());	

	header("Location:purchase_order.php?msg=Record deleted&pg=11");	
}

if(isset($_REQUEST['oid'])){
	
	$oid = mysql_escape_string($_REQUEST['oid']);
	$qt = mysql_escape_string($_REQUEST['qt']);
	
	//Delete Quotaion
	$del  = "DELETE FROM inv_purchase_line WHERE id='$oid'";
	mysql_query($del, $dbc) or die(mysql_error());	

	header("Location:purchase_view.php?msg=Record deleted&qt=$qt&pg=11");	
}
?>
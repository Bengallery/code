<?php
include('header.php');
?>


        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="header">
                               <a href="product_create.php?pg=5">
								<button class="btn btn-info btn-fill btn-wd">Create</button>
							   </a>	
                            </div>
                            <div class="content table-responsive table-full-width">
							
					
							
							
                                <table class="table table-striped">
                                    <thead>
										<th>Name</th>
                                        <th>Product Type</th>
										<th>Sales Price</th>
										<th>Quantity on Hand</th>
										<th></th>
										<th></th>
                                    </thead>
									
									
                                    <tbody>
									
									
<?php
$rowsPerPage = 10;

// by default we show first page
$pageNum = 1;

// if $_GET['page'] defined, use it as page number
if(isset($_GET['page']))
{
	$pageNum = $_GET['page'];
}

// counting the offset
$offset = ($pageNum - 1) * $rowsPerPage;


$sql = "SELECT * FROM inv_product ";
$pagingQuery = "ORDER BY id DESC LIMIT $offset, $rowsPerPage";

$result = mysql_query($sql . $pagingQuery) or die(mysql_error());


while($info = mysql_fetch_array($result)){ 
	$id=$info['id'];
	$product_name=$info['product_name'];
	$product_type=$info['product_type'];
	$sale_price=$info['sale_price'];
	$ean13_barcode=$info['ean13_barcode'];
	$int_ref=$info['int_ref'];
	$description=$info['description'];
		
	
	
	print "
	<tr>
                                        	<td>$product_name</td>
											<td>$product_type</td>
											<td>$sale_price</td>
                                        	<td>0</td>
											<td></td>
											<td></td>
											
    </tr>
	";
	
}

print '
      
                                    </tbody>
                                </table>
';


// how many rows we have in database
$result  = mysql_query($sql) or die('Error, query failed');
$numrows = mysql_num_rows($result);

// how many pages we have when using paging?
$maxPage = ceil($numrows/$rowsPerPage);

$self = $_SERVER['PHP_SELF'];

// creating 'previous' and 'next' link
// plus 'first page' and 'last page' link

// print 'previous' link only if we're not
// on page one
if ($pageNum > 1)
{
	$page = $pageNum - 1;
	$prev = " <a href=\"$self?page=$page&id=$_GET[id]\">[Prev]</a> ";

	$first = " <a href=\"$self?page=1&id=$_GET[id]\">[First Page]</a> ";
}
else
{
	$prev  = ' [Prev] ';       // we're on page one, don't enable 'previous' link
	$first = ' [First Page] '; // nor 'first page' link
}

// print 'next' link only if we're not
// on the last page
if ($pageNum < $maxPage)
{
	$page = $pageNum + 1;
	$next = " <a href=\"$self?page=$page&id=$_GET[id]\">[Next]</a> ";

	$last = " <a href=\"$self?page=$maxPage&id =$_GET[id]\">[Last Page]</a> ";
}
else
{
	$next = ' [Next] ';      // we're on the last page, don't enable 'next' link
	$last = ' [Last Page] '; // nor 'last page' link
}

// print the page navigation link
echo $first . $prev . " Showing page <strong>$pageNum</strong> of <strong>$maxPage</strong> pages " . $next . $last;

if ($maxPage == 0) {
print "<p>no record found</p>";
}
?>										
                                        
                                  

                            </div>
                        </div>
                    </div>



                </div>
            </div>
        </div>

        <?php include('footer.php') ?>


    </div>
</div>


</body>

    <!--   Core JS Files   -->
    <script src="assets/js/jquery.min.js" type="text/javascript"></script>
	<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>

	<!--  Checkbox, Radio & Switch Plugins -->
	<script src="assets/js/bootstrap-checkbox-radio.js"></script>

	<!--  Charts Plugin -->
	<script src="assets/js/chartist.min.js"></script>

    <!--  Notifications Plugin    -->
    <script src="assets/js/bootstrap-notify.js"></script>

    <!--  Google Maps Plugin    -->
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js"></script>

    <!-- Paper Dashboard Core javascript and methods for Demo purpose -->
	<script src="assets/js/paper-dashboard.js"></script>

	<!-- Paper Dashboard DEMO methods, don't include it in your project! -->
	<script src="assets/js/demo.js"></script>


</html>

<?php 
session_start();

include("conn.php");

		$surname = mysql_escape_string($_REQUEST['surname']);
		$other_names = mysql_escape_string($_REQUEST['other_names']);
		$phone = mysql_escape_string($_REQUEST['phone']);
		$password = mysql_escape_string($_REQUEST['password']);		
		$email = mysql_escape_string($_REQUEST['email']);
		$address = mysql_escape_string($_REQUEST['address']);
		$user_type = mysql_escape_string($_REQUEST['user_type']);		
		$detail = mysql_escape_string($_REQUEST['detail']);
		$pg = mysql_escape_string($_REQUEST['pg']);
		
		
		$post_vote_type_id = mysql_escape_string($_REQUEST['post_vote_type_id']);
		$post_state_id = mysql_escape_string($_REQUEST['post_state_id']);
		$post_lga_id = mysql_escape_string($_REQUEST['post_lga_id']);
		$post_ward_id = mysql_escape_string($_REQUEST['post_ward_id']);
		$post_party_id = mysql_escape_string($_REQUEST['post_party_id']);
		
		// -------------------------------------------------------- user phone number already existing
		$sql = "SELECT * FROM voting_user WHERE (phone = '$phone' OR email='$email') OR password = '$password'";
		$sql_query = mysql_query($sql, $dbc) or die(mysql_error());
		
				if (mysql_num_rows($sql_query) >= 1) {
					
					header("Location:user.php?msg=Sorry the Phone number or Password already use, try again&pg=$pg");	
					
				}else{
						
										
						$sql="INSERT INTO voting_user values ('','$surname','$other_names','$phone', '$password','$email','$address','$detail','$user_type','$post_vote_type_id','$post_state_id','$post_lga_id','$post_ward_id','$post_party_id',now(),'')"; 
											
										mysql_query($sql,$dbc) or die(mysql_error());	
																
					header("Location:user.php?msg=User Account was successfuly created&pg=$pg");	
		
			  }


?>                  
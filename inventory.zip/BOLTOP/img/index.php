<?php
header("Location:/app");					
?>
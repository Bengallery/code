<?php
include('header.php');
	if(isset($_REQUEST['post'])){
	  if(isset($_REQUEST['product_name'])){
		$product_name = mysql_escape_string($_REQUEST['product_name']);
		$product_type = mysql_escape_string($_REQUEST['product_type']);
		$price = mysql_escape_string($_REQUEST['price']);
		$active = mysql_escape_string($_REQUEST['active']);		
		$barcode = mysql_escape_string($_REQUEST['barcode']);
		$ref = mysql_escape_string($_REQUEST['ref']);
		$description = mysql_escape_string($_REQUEST['description']);
		
		$sql="INSERT INTO inv_product values ('','$product_name','$product_type','$price','$barcode','$ref','$description',now(),'$active','$_SESSION[id]')"; 
		mysql_query($sql,$dbc) or die(mysql_error());	
		$msg="Record created";
	  }else{
		  $msg="Sorry, please enter value for Product Name field";
	  }
	}								
?>


        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="header">
							<h4 class="title">
								Create Product
							</h4>
                               <a href="product.php?pg=5">
								Back to View
							   </a>	
                            </div>
                            
<div class="content">		

							<?php
								if(isset($msg)){
									print "<font color='blue'>".$msg."</font>";
									
								}
							?>					
<form method="POST" action="product_create.php">							
								
                                
                                   

                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Product Name</label>
                                                <input type="text" class="form-control border-input" name="product_name">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Product Type</label>
												<select name="product_type" class="form-control border-input">
													<option></option>
													<option>Consumable</option>
													<option>Stockable Product</option>
													<option>Service</option>
												</select>
                                            </div>
                                        </div>
                                    </div>
									
									
									<div class="row">
                                        <div class="col-md-6">
											<div class="form-group">
                                                <label>Sale Price</label>
                                                <input type="text" class="form-control border-input" name="price">
                                            </div>                                           
                                        </div>
                                        <div class="col-md-6">
											 <div class="form-group">
                                                <label>Active</label>
                                                <input type="checkbox" name="active" value="A">
                                            </div>
                                            
                                        </div>
                                    </div>

                                    <div class="row">
										<div class="col-md-6">
                                            <div class="form-group">
                                                <label>EAN13 Barcode</label>
                                                <input type="text" class="form-control border-input" name="barcode">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Internal Reference</label>
                                                <input type="text" class="form-control border-input" name="ref">
                                            </div>
                                        </div>
										
                                    </div>
									
									
                                  
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Description</label>
                                                <textarea rows="5" class="form-control border-input" name="description"></textarea>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="text-center">
										<input type="hidden" name="pg" value="5">
										<input type="hidden" name="post" value="1">
												
										<?php
										if(isset($_REQUEST['edit'])){
											print '<button type="submit" class="btn btn-info btn-fill btn-wd">Update</button>';
										}else{
											print '<button type="submit" class="btn btn-info btn-fill btn-wd">Create</button>';
										}
										?>
								
                                        
										
										
                                    </div>
                                    <div class="clearfix"></div>
</div>                                </form>
									
                        </div>
                    </div>



                </div>
            </div>
        </div>

        <?php include('footer.php') ?>


    </div>
</div>


</body>

    <!--   Core JS Files   -->
    <script src="assets/js/jquery.min.js" type="text/javascript"></script>
	<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>

	<!--  Checkbox, Radio & Switch Plugins -->
	<script src="assets/js/bootstrap-checkbox-radio.js"></script>

	<!--  Charts Plugin -->
	<script src="assets/js/chartist.min.js"></script>

    <!--  Notifications Plugin    -->
    <script src="assets/js/bootstrap-notify.js"></script>

    <!--  Google Maps Plugin    -->
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js"></script>

    <!-- Paper Dashboard Core javascript and methods for Demo purpose -->
	<script src="assets/js/paper-dashboard.js"></script>

	<!-- Paper Dashboard DEMO methods, don't include it in your project! -->
	<script src="assets/js/demo.js"></script>


</html>

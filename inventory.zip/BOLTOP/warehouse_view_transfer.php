<?php
include('header.php');
?>


        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="header">
							<h4 class="title">
								New Transfer
							</h4>
								<br/>
                              
										 <a href="warehouse_view.php?wid=<?php print $_REQUEST['wid']; ?>&pg=12">
												<button class="btn btn-success btn-fill btn-wd">Go Back</button>
									     </a>
										 
                            </div>
                            
<div class="content">		

							<?php
								if(isset($msg)){
									print "<font color='blue'>".$msg."</font>";
									
								}
							?>					
<form method="POST" action="warehouse_sales_create_order_line.php">							
									<div class="text-left">
										<input type="hidden" name="pg" value="12">
										<input type="hidden" name="post" value="1">
										<input type="hidden" name="wid" value="<?php print $_REQUEST['wid']; ?>">
												
										<button type="submit" class="btn btn-info btn-fill btn-wd">Save / Add Item</button>
                                    </div>								
                                
									
									
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Outlets/Stores</label>
                                                <select name="stores" class="form-control border-input">
												<option></option>
												<?php
												
												$query1  = "SELECT * FROM inv_outlets WHERE status <> 'D' ORDER BY id ASC";
												$result1 = mysql_query($query1) or die(mysql_error());
												while($info1 = mysql_fetch_array($result1))
												{
														 $outlet_id=$info1['id'];
														 $outlet_name=$info1['outlet_name'];
														
																print "<option value='$outlet_id'>$outlet_name</option>";
																
														
												}
												?>
													
												</select>    
                                            </div>
                                        </div>
                                       
                                    </div>
									
									
									<div class="row">
                                        <div class="col-md-6">
											   <div class="form-group">
                                                <label>Source Document</label>
                                                <input type="text" class="form-control border-input" name="source">  
                                            </div>                                       
                                        </div>
                                      
                                    </div>
									
									
									<div class="row">
                                         <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Creation Date</label>
                                                <input id="sel_date" name="sel_date" size="8" class="datepicker" value="<?php print date('d-M-Y')?>" />
                                            </div>  
                                        </div>
                                    </div>

                                    
                                  
                                    <div class="clearfix"></div>
</div>                                </form>


									
                        </div>
                    </div>



                </div>
            </div>
        </div>

        <?php include('footer.php') ?>


    </div>
</div>


</body>

    <!--   Core JS Files   -->
    <script src="assets/js/jquery.min.js" type="text/javascript"></script>
	<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>

	<!--  Checkbox, Radio & Switch Plugins -->
	<script src="assets/js/bootstrap-checkbox-radio.js"></script>

	<!--  Charts Plugin -->
	<script src="assets/js/chartist.min.js"></script>

    <!--  Notifications Plugin    -->
    <script src="assets/js/bootstrap-notify.js"></script>

    <!--  Google Maps Plugin    -->
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js"></script>

    <!-- Paper Dashboard Core javascript and methods for Demo purpose -->
	<script src="assets/js/paper-dashboard.js"></script>

	<!-- Paper Dashboard DEMO methods, don't include it in your project! -->
	<script src="assets/js/demo.js"></script>


</html>

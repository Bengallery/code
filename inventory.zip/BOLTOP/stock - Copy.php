<?php
include('header.php');
?>


        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="header">
							<!--
                               <a href="stock_create.php?pg=7">
								<button class="btn btn-info btn-fill btn-wd">New Stock</button>
							   </a>	
							   -->
                            </div>
                            <div class="content table-responsive table-full-width">
							
					
							
							
                                <table class="table table-striped">
                                    <thead>
										<th>Name</th>
                                        <th>Stoke Date</th>
										<th>Supplier</th>
										<th>Warehouse</th>										
										<th>Quantity</th>
										<th>Stock Bal</th>
										<th></th>
                                    </thead>
									
									
                                    <tbody>
									
									
<?php
$rowsPerPage = 10;

// by default we show first page
$pageNum = 1;

// if $_GET['page'] defined, use it as page number
if(isset($_GET['page']))
{
	$pageNum = $_GET['page'];
}

// counting the offset
$offset = ($pageNum - 1) * $rowsPerPage;


$sql = "SELECT * FROM inv_stock ";
$pagingQuery = "ORDER BY id DESC LIMIT $offset, $rowsPerPage";

$result = mysql_query($sql . $pagingQuery) or die(mysql_error());


while($info = mysql_fetch_array($result)){ 
	$id=$info['id'];
	$product=$info['product'];
	$day=$info['day'];
	$month=$info['month'];
	$year=$info['year'];
	$supply_by=$info['supply_by'];
	$warehouse=$info['warehouse'];
	$x_day=$info['x_day'];
	$x_month=$info['x_month'];
	$x_year=$info['x_year'];
	$quantity=$info['quantity'];
	$adjustment=$info['adjustment'];
	$description=$info['description'];
	$after_adjustment=$info['after_adjustment'];
	$stock_on_hand=$info['stock_on_hand'];
	$posted_by=$info['posted_by'];
	$date_posted=$info['date_posted'];
	$status=$info['status'];
	
		//Product
		$query1  = "SELECT * FROM inv_product WHERE id = '$product'";
		$result1 = mysql_query($query1) or die(mysql_error());
		$info1 = mysql_fetch_array($result1);
		$product_id=$info1['id'];
		$product_name=$info1['product_name'];

		//inv_supplier
		$query1  = "SELECT * FROM inv_supplier WHERE supply_product_id = '$supply_by'";
		$result1 = mysql_query($query1) or die(mysql_error());
		$info1 = mysql_fetch_array($result1);
		$supply_product_id=$info1['supply_product_id'];
		$supplier_name=$info1['supplier_name'];
		
		//warehouse
		$query1  = "SELECT * FROM inv_warehouse WHERE id = '$warehouse'";
		$result1 = mysql_query($query1) or die(mysql_error());
		$info1 = mysql_fetch_array($result1);
		$warehouse_id=$info1['id'];
		$warehouse_name=$info1['warehouse_name'];
		
		if($x_day==''){
			$exp_date = "not applicable";
		}else{
			$exp_date = "$x_day/$x_month/$x_year";
		}
		
		
	
	
	print "
	<tr>
                                        	<td>$product_name</td>
											<td>$day/$month/$year</td>
											<td>$supplier_name</td>
                                        	<td>$warehouse_name</td>
											<td>$after_adjustment</td>
											<td>$stock_on_hand</td>
											<td></td>
											
    </tr>
	";
	
}

print '
      
                                    </tbody>
                                </table>
';


// how many rows we have in database
$result  = mysql_query($sql) or die('Error, query failed');
$numrows = mysql_num_rows($result);

// how many pages we have when using paging?
$maxPage = ceil($numrows/$rowsPerPage);

$self = $_SERVER['PHP_SELF'];

// creating 'previous' and 'next' link
// plus 'first page' and 'last page' link

// print 'previous' link only if we're not
// on page one
if ($pageNum > 1)
{
	$page = $pageNum - 1;
	$prev = " <a href=\"$self?page=$page&id=$_GET[id]\">[Prev]</a> ";

	$first = " <a href=\"$self?page=1&id=$_GET[id]\">[First Page]</a> ";
}
else
{
	$prev  = ' [Prev] ';       // we're on page one, don't enable 'previous' link
	$first = ' [First Page] '; // nor 'first page' link
}

// print 'next' link only if we're not
// on the last page
if ($pageNum < $maxPage)
{
	$page = $pageNum + 1;
	$next = " <a href=\"$self?page=$page&id=$_GET[id]\">[Next]</a> ";

	$last = " <a href=\"$self?page=$maxPage&id =$_GET[id]\">[Last Page]</a> ";
}
else
{
	$next = ' [Next] ';      // we're on the last page, don't enable 'next' link
	$last = ' [Last Page] '; // nor 'last page' link
}

// print the page navigation link
echo $first . $prev . " Showing page <strong>$pageNum</strong> of <strong>$maxPage</strong> pages " . $next . $last;

if ($maxPage == 0) {
print "<p>no record found</p>";
}
?>										
                                        
                                  

                            </div>
                        </div>
                    </div>



                </div>
            </div>
        </div>

        <?php include('footer.php') ?>


    </div>
</div>


</body>

    <!--   Core JS Files   -->
    <script src="assets/js/jquery.min.js" type="text/javascript"></script>
	<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>

	<!--  Checkbox, Radio & Switch Plugins -->
	<script src="assets/js/bootstrap-checkbox-radio.js"></script>

	<!--  Charts Plugin -->
	<script src="assets/js/chartist.min.js"></script>

    <!--  Notifications Plugin    -->
    <script src="assets/js/bootstrap-notify.js"></script>

    <!--  Google Maps Plugin    -->
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js"></script>

    <!-- Paper Dashboard Core javascript and methods for Demo purpose -->
	<script src="assets/js/paper-dashboard.js"></script>

	<!-- Paper Dashboard DEMO methods, don't include it in your project! -->
	<script src="assets/js/demo.js"></script>


</html>

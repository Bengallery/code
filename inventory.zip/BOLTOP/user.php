<?php
include('header.php');

if(isset($_REQUEST['post_vote_type_id'])){
	$set_post_vote_type_id=$_REQUEST['post_vote_type_id'];
	
}
if(isset($_REQUEST['post_state_id'])){
	$set_post_state_id=$_REQUEST['post_state_id'];
}

if(isset($_REQUEST['post_lga_id'])){
	$set_post_lga_id=$_REQUEST['post_lga_id'];
}

if(isset($_REQUEST['post_ward_id'])){
	$set_post_ward_id=$_REQUEST['post_ward_id'];;
}

if(isset($_REQUEST['post_poll_id'])){
	$set_post_poll_id=$_REQUEST['post_poll_id'];;
}

if(isset($_REQUEST['post_party_id'])){
	$set_post_party_id=$_REQUEST['post_party_id'];;
}

?>


        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    
					
					
					
					
					
                    <div class="col-lg-8 col-md-7">
                        <div class="card">
                            <div class="header">
                                <h4 class="title">
								<?php
								if(isset($_REQUEST['edit'])){
									print 'Edit User Account';
								}else{
									print 'Create User Account';
								}
								
								
								?>
								
								</h4>
								<p class="category">Voting Type, State, LGA, Polling Station/Ward and Party specify the access level of the user</p>
                            </div>
                            <div class="content">
							
							<?php
								if(isset($_REQUEST['msg'])){
									print "<font color='blue'>".$_REQUEST['msg']."</font>";
									
								}
							?>
							
							
		
					
							                                 <!--  -------------------------------- VOTING TYPE -------------------------------- -->  
								<div class="row">
									<form action="user.php?pg=2" method="post">
										<div class="col-md-6">	
                                            <div class="form-group">
                                                <label>Election Type</label>
												<select name="post_vote_type_id" class="form-control border-input" onchange="form.submit()">
												<option>ALL</option>
												<?php
												
												$query1  = "SELECT * FROM voting_type WHERE status <> 'D' ORDER BY name ASC";
												$result1 = mysql_query($query1) or die(mysql_error());
												while($info1 = mysql_fetch_array($result1))
												{
														 $voting_type_id=$info1['id'];
														 $voting_type_name=$info1['name'];
														 
														 if((isset($set_post_vote_type_id))&&($set_post_vote_type_id==$voting_type_id)){
															 print "<option value='$voting_type_id' selected='selected'>$voting_type_name</option>";
														 }else{
															print "<option value='$voting_type_id'>$voting_type_name</option>";
														}
												}
												?>
													
												</select>                                                
                                            </div>
                                       </div>
									</form>
								



							<!--  -------------------------------- STATE ----------------------------------------- -->  
								
								<?php
								//if(isset($set_post_vote_type_id)){
								?>	
										<form action="user.php?pg=2" method="post">
											<div class="col-md-6">	
												<div class="form-group">
													<label>State</label>
													<select name="post_state_id" class="form-control border-input" onchange="form.submit()">
													<option>ALL</option>
													<?php
													
													$query1  = "SELECT * FROM voting_state WHERE status <> 'D' ORDER BY state_name ASC";
													$result1 = mysql_query($query1) or die(mysql_error());
													while($info1 = mysql_fetch_array($result1))
													{
															 $state_id=$info1['state_id'];
															 $state_name=$info1['state_name'];
															 
															 if((isset($set_post_state_id))&&($set_post_state_id==$state_id)){
																 print "<option value='$state_id' selected='selected'>$state_name</option>";
															 }else{
																print "<option value='$state_id'>$state_name</option>";
															}
													}
													?>
														
													</select>   
													<input type="hidden" name="post_vote_type_id" value="<?php print $set_post_vote_type_id; ?>" >
												</div>
											</div>
										</form>	
									</div>										
								<?php
								//}
								?>
								
						<?php
						if(isset($set_post_vote_type_id)&&($set_post_vote_type_id=='3')){
							//3 Senatorial, constituency view
						?>	
								<div class="row">
										<form action="user.php?pg=2" method="post">
											<div class="col-md-12">
												<div class="form-group">
													<label>Constituency</label>
													<select name="post_lga_id" class="form-control border-input" onchange="form.submit()">
													<option>ALL</option>
													<?php
													
													$set_post_state_id_zero = "$set_post_state_id.0";
													
													//constituency filter condition
														if($set_post_vote_type_id=='3'){ //senate filter
															$con_type = " AND Post='5.0' ";
														}elseif($set_post_vote_type_id=='4'){ //house of rep filter
															$con_type = " AND Post='6.0' ";
														}elseif($set_post_vote_type_id=='5'){ //house of assembly filter
															$con_type = " AND Post='7.0' ";
														}
														
														
													$query1  = "SELECT * FROM voting_constituency WHERE State='$set_post_state_id_zero' $con_type ORDER BY Constituency ASC";
													$result1 = mysql_query($query1) or die(mysql_error());
													while($info1 = mysql_fetch_array($result1))
													{
															 $serial=$info1['serial'];
															 $Constituency=$info1['Constituency'];
															 
															 
															 if((isset($set_post_lga_id))&&($set_post_lga_id==$serial)){
																 print "<option value='$serial' selected='selected'>$Constituency</option>";
															 }else{ 
																print "<option value='$serial'>$Constituency</option>";
															}
													}
													?>
														
													</select>
													<input type="hidden" name="post_state_id" value="<?php print $set_post_state_id; ?>" >
													<input type="hidden" name="post_vote_type_id" value="<?php print $set_post_vote_type_id; ?>" >
												</div>
											</div>
										</form>		
									</div>	
					<?php
						}else{
					?>						
							<!--  -------------------------------- LGA ----------------------------------------- -->
							
								<?php
								//if(isset($set_post_state_id)){
								?>	
								 <div class="row">
										<form action="user.php?pg=2" method="post">
											<div class="col-md-6">
												<div class="form-group">
													<label>LGA</label>
													<select name="post_lga_id" class="form-control border-input" onchange="form.submit()">
													<option>ALL</option>
													<?php
													
													$query1  = "SELECT * FROM voting_lga WHERE state_id='$set_post_state_id' AND status <> 'D' ORDER BY lga_name ASC";
													$result1 = mysql_query($query1) or die(mysql_error());
													while($info1 = mysql_fetch_array($result1))
													{
															 $lga_id=$info1['lga_id'];
															 $lga_name=$info1['lga_name'];
															 
															 if((isset($set_post_lga_id))&&($set_post_lga_id==$lga_id)){
																 print "<option value='$lga_id' selected='selected'>$lga_name</option>";
															 }else{ 
																print "<option value='$lga_id'>$lga_name</option>";
															}
													}
													?>
														
													</select>
													<input type="hidden" name="post_state_id" value="<?php print $set_post_state_id; ?>" >
													<input type="hidden" name="post_vote_type_id" value="<?php print $set_post_vote_type_id; ?>" >
												</div>
											</div>
										</form>								
								<?php
								//}
								?>
								
								
							<!--  -------------------------------- WARD ----------------------------------------- -->	
								
								
								<?php
								
								//if(isset($set_post_lga_id)){
									$set_post_lga_id = mysql_escape_string($set_post_lga_id);	
										$query  = "SELECT * FROM voting_lga WHERE status <> 'D' AND lga_id='$set_post_lga_id'";
										$result = mysql_query($query) or die(mysql_error());
										$data = mysql_fetch_array($result);
										$lga_name_sel=$data['lga_name'];
								
								?>	
										<form action="user.php?pg=2" method="post">
											<div class="col-md-6">
												<div class="form-group">
													<label>POLLING STATION/WARD</label>
													
													<select name="post_ward_id" class="form-control border-input" onchange="form.submit()">
													<option>ALL</option>
													<?php
													$ward_id_change='0';
													$query1  = "SELECT * FROM voting_wards_polling_units WHERE LGA = '$lga_name_sel' ORDER BY 'RA/WARD' ASC";
													$result1 = mysql_query($query1) or die(mysql_error());
													while($info1 = mysql_fetch_array($result1))
													{
															 $ward_id=$info1['RA/ward_code'];
															 $pu_id=$info1['pu_code'];
															 $ward=$info1['RA/WARD'];
															 $pu=$info1['pu'];
															 
																														 
															 if($ward_id != $ward_id_change){
																print "<optgroup label=\"[$ward_id] $ward\">";
															 }
																
															if((isset($set_post_ward_id))&&($set_post_ward_id=="$ward_id+$pu_id")){
																 print "<option value='$ward_id+$pu_id' selected='selected'>$pu &nbsp;&nbsp;&nbsp; [$pu_id ]</option>";
															}else{ 
																	print "<option value='$ward_id+$pu_id'>$pu &nbsp;&nbsp;&nbsp; [$pu_id ]</option>";
															}
															
															 $ward_id_change = $ward_id;
														
													}
													?>
														
													</select>
													
													<input type="hidden" name="post_lga_id" value="<?php print $set_post_lga_id; ?>" >
													<input type="hidden" name="post_state_id" value="<?php print $set_post_state_id; ?>" >
													<input type="hidden" name="post_vote_type_id" value="<?php print $set_post_vote_type_id; ?>" >
												</div>
											</div>
										</form>	
									</div>		
								<?php
								//}
								
							}
								?>
								
								
							
									
						<?php
						//if(isset($set_post_ward_id)){
						?>	
							<div class="row">
									<form action="user.php?pg=2" method="post">
										<div class="col-md-6">	
                                 
                                            <div class="form-group">
                                                <label>Party</label>
												<select name="post_party_id" class="form-control border-input" onchange="form.submit()">
												<option>ALL</option>
												<?php
												
												$query1  = "SELECT * FROM voting_parties WHERE status <> 'D' ORDER BY political_party_name ASC";
												$result1 = mysql_query($query1) or die(mysql_error());
												while($info1 = mysql_fetch_array($result1))
												{
														 $political_party_id=$info1['id'];
														 $political_party_name=$info1['political_party_name'];
														 
														 
														  preg_match('#\((.*?)\)#', $political_party_name, $match);
															$political_party_name = $match[1];
														 
														 if((isset($set_post_party_id))&&($set_post_party_id==$political_party_id)){
															 print "<option value='$political_party_id' selected='selected'>$political_party_name</option>";
														 }else{
															print "<option value='$political_party_id'>$political_party_name</option>";
														}
												}
												?>
													
												</select> 

												<input type="hidden" name="post_ward_id" value="<?php print $set_post_ward_id; ?>" >
												<input type="hidden" name="post_lga_id" value="<?php print $set_post_lga_id; ?>" >
												<input type="hidden" name="post_state_id" value="<?php print $set_post_state_id; ?>" >
												<input type="hidden" name="post_vote_type_id" value="<?php print $set_post_vote_type_id; ?>" >			
                                            </div>
                                        </div>
									</form>
								
						<?php
						//}
						?>								
								
							
<form method="POST" action="user_process.php">							
								<div class="col-md-6">
                                            <div class="form-group">
                                                <label>Type</label>
												<select name="user_type" class="form-control border-input">
												<?php
												$query1  = "SELECT * FROM voting_user_type ORDER BY id DESC";
												$result1 = mysql_query($query1) or die(mysql_error());
												while($info1 = mysql_fetch_array($result1))
												{
														 $id=$info1['id'];
														 $text=$info1['text'];
														 print "<option value='$id'>$text</option>";
												}
												?>
													
												</select>
                                            </div>
                                        </div>
								
							</div>	
								
                                
                                   

                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Surname</label>
                                                <input type="text" class="form-control border-input" name="surname">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Other Names</label>
                                                <input type="text" class="form-control border-input" name="other_names">
                                            </div>
                                        </div>
                                    </div>
									
									
									<div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Phone</label>
                                                <input type="text" class="form-control border-input" name="phone">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Password</label>
                                                <input type="password" class="form-control border-input" name="password">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
										<div class="col-md-6">
                                            <div class="form-group">
                                                <label>Email</label>
                                                <input type="text" class="form-control border-input" name="email">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Address</label>
                                                <input type="text" class="form-control border-input" name="address">
                                            </div>
                                        </div>
										
                                    </div>
									
									
                                  
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Detail</label>
                                                <textarea rows="5" class="form-control border-input" name="detail"></textarea>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="text-center">
										<input type="hidden" name="pg" value="2">
										
												<input type="hidden" name="post_ward_id" value="<?php print $set_post_ward_id; ?>" >
												<input type="hidden" name="post_lga_id" value="<?php print $set_post_lga_id; ?>" >
												<input type="hidden" name="post_state_id" value="<?php print $set_post_state_id; ?>" >
												<input type="hidden" name="post_vote_type_id" value="<?php print $set_post_vote_type_id; ?>" >
												<input type="hidden" name="post_party_id" value="<?php print $set_post_party_id; ?>" >												
												
												
										<?php
										if(isset($_REQUEST['edit'])){
											print '<button type="submit" class="btn btn-info btn-fill btn-wd">Update</button>';
										}else{
											print '<button type="submit" class="btn btn-info btn-fill btn-wd">Create</button>';
										}
										?>
								
                                        
										
										
                                    </div>
                                    <div class="clearfix"></div>
                                </form>
                            </div>
                        </div>
                    </div>
					
					
					
					
					
					<div class="col-lg-4 col-md-5">
                        
						
						
                        <div class="card">
                            <div class="header">
                                <h4 class="title">Users</h4>
                            </div>
                            <div class="content">
                                <ul class="list-unstyled team-members">
								
								<?php
								$query5  = "SELECT * FROM voting_user ORDER BY id DESC";
								$result5 = mysql_query($query5) or die(mysql_error());


								while($info5 = mysql_fetch_array($result5))

								{
										 $id=$info5['id'];
										 $surname=$info5['surname'];
										 $other_names=$info5['other_names']; 
										 $phone=$info5['phone'];	
										 $user_type=$info5['user_type'];
										 $user_level=$info5['user_level'];	
										 
										 
												$query3  = "SELECT * FROM voting_user_type WHERE id='$user_type'";
												$result3 = mysql_query($query3) or die(mysql_error());
												$info3 = mysql_fetch_array($result3);
														 $id=$info3['id'];
														 $vote_user_type=$info3['text'];
														 
												$query4  = "SELECT * FROM voting_user_level WHERE id='$user_level'";
												$result4 = mysql_query($query4) or die(mysql_error());
												$info4 = mysql_fetch_array($result4);
														 $id=$info4['id'];
														 $vote_user_level=$info4['level'];
												

										print '
											<li>
                                                <div class="row">
                                                    <div class="col-xs-5">'.
                                                        $surname .' '.$other_names
                                                        .'<br />
                                                        <span class="text-success"><small>'.$vote_user_type.'</small></span>
														<br/>
														<span class="text-muted"><small>'.$vote_user_level.'</small></span>
                                                    </div>
													
													<div class="col-xs-4">'.$phone.'</div>

                                                    <div class="col-xs-3 text-right">
                                                        <btn class="btn btn-sm btn-success btn-icon"><i class="fa fa-pencil"></i></btn>
                                                    </div>
                                                </div>
                                            </li>
										';
								}
								?>
                                            
                                        </ul>
                            </div>
                        </div>
                    </div>


                </div>
            </div>
        </div>


        <?php include('footer.php') ?>

    </div>
</div>


</body>

    <!--   Core JS Files   -->
    <script src="assets/js/jquery.min.js" type="text/javascript"></script>
	<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>

	<!--  Checkbox, Radio & Switch Plugins -->
	<script src="assets/js/bootstrap-checkbox-radio.js"></script>

	<!--  Charts Plugin -->
	<script src="assets/js/chartist.min.js"></script>

    <!--  Notifications Plugin    -->
    <script src="assets/js/bootstrap-notify.js"></script>

    <!--  Google Maps Plugin    -->
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js"></script>

    <!-- Paper Dashboard Core javascript and methods for Demo purpose -->
	<script src="assets/js/paper-dashboard.js"></script>

	<!-- Paper Dashboard DEMO methods, don't include it in your project! -->
	<script src="assets/js/demo.js"></script>

</html>
